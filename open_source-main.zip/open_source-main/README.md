# LoL
- `Qasier & Syed Zada Madarchod Bap Ka Method Chorii Karna Se Pehla Soch Lena Again`
- `Enjoy Open Source Love You All`
