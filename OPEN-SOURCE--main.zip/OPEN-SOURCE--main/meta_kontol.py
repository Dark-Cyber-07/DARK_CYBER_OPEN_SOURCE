
	{( Cython Easy By Vivek Chandel)}



ussage > cython.py <filename> 'string'
Example:
        python cython.py yourscript.py '+'

