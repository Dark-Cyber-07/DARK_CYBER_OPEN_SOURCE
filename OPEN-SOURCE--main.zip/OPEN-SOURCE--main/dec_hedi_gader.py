If You Get Error Decompile, Error code saved to code.py
hedi_gader.py: <code object <module> at 0x7ab1a58db0, file "dg", line 6>
