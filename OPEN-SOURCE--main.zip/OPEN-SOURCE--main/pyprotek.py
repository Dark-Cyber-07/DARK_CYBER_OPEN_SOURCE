#Encrypted By Tegar-ID
#Github : https://github.com/Tegar-ID/
#Jangan di edit tolol nanti error
from collections import OrderedDict
exec("".join(map(chr,[int("".join(str(OrderedDict([('tegar_ID', 0), ('1', 1), ('2', 2), ('3', 3), ('4', 4), ('5', 5), ('6', 6), ('7', 7), ('8', 8), ('9', 9)])[i]) for i in x.split())) for x in
"3 5  3 3  1 1 7  1 1 5  1 1 4  4 7  9 8  1 tegar_ID 5  1 1 tegar_ID  4\
 7  1 1 2  1 2 1  1 1 6  1 tegar_ID 4  1 1 1  1 1 tegar_ID  5 tegar_ID\
  4 6  5 5  1 tegar_ID  3 5  3 2  4 5  4 2  4 5  3 2  9 9  1 1 1  1 te\
gar_ID tegar_ID  1 tegar_ID 5  1 1 tegar_ID  1 tegar_ID 3  5 8  3 2  8\
 5  8 4  7 tegar_ID  4 5  5 6  3 2  4 5  4 2  4 5  1 tegar_ID  1 tegar\
_ID 5  1 tegar_ID 9  1 1 2  1 1 1  1 1 4  1 1 6  3 2  9 7  1 1 4  1 te\
gar_ID 3  1 1 2  9 7  1 1 4  1 1 5  1 tegar_ID 1  4 4  1 1 1  1 1 5  1\
 tegar_ID  1 tegar_ID 2  1 1 4  1 1 1  1 tegar_ID 9  3 2  9 9  1 1 1  \
1 tegar_ID 8  1 tegar_ID 8  1 tegar_ID 1  9 9  1 1 6  1 tegar_ID 5  1 \
1 1  1 1 tegar_ID  1 1 5  3 2  1 tegar_ID 5  1 tegar_ID 9  1 1 2  1 1 \
1  1 1 4  1 1 6  3 2  7 9  1 1 4  1 tegar_ID tegar_ID  1 tegar_ID 1  1\
 1 4  1 tegar_ID 1  1 tegar_ID tegar_ID  6 8  1 tegar_ID 5  9 9  1 1 6\
  1 tegar_ID  1 tegar_ID 2  1 1 4  1 1 1  1 tegar_ID 9  3 2  1 1 2  1 \
1 2  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2  1 tegar_ID 5  1 te\
gar_ID 9  1 1 2  1 1 1  1 1 4  1 1 6  3 2  1 1 2  1 tegar_ID 2  1 1 1 \
 1 1 4  1 tegar_ID 9  9 7  1 1 6  1 tegar_ID  9 5  9 5  9 9  1 1 4  1 \
tegar_ID 1  9 7  1 1 6  1 tegar_ID 1  1 tegar_ID tegar_ID  9 5  9 5  3\
 2  6 1  3 2  3 9  8 4  1 tegar_ID 1  1 tegar_ID 3  9 7  1 1 4  3 2  7\
 3  6 8  3 9  1 tegar_ID  9 5  9 5  1 tegar_ID 3  1 tegar_ID 5  1 1 6 \
 1 tegar_ID 4  1 1 7  9 8  9 5  9 5  3 2  6 1  3 2  3 9  7 1  1 tegar_\
ID 5  1 1 6  1 tegar_ID 4  1 1 7  9 8  3 2  5 8  3 2  1 tegar_ID 4  1 \
1 6  1 1 6  1 1 2  1 1 5  5 8  4 7  4 7  1 tegar_ID 3  1 tegar_ID 5  1\
 1 6  1 tegar_ID 4  1 1 7  9 8  4 6  9 9  1 1 1  1 tegar_ID 9  4 7  8 \
4  1 tegar_ID 1  1 tegar_ID 3  9 7  1 1 4  4 5  7 3  6 8  3 9  1 tegar\
_ID  1 tegar_ID 5  1 tegar_ID 9  1 1 2  1 1 1  1 1 4  1 1 6  3 2  1 1 \
1  1 1 5  1 tegar_ID  3 5  1 tegar_ID 7  1 1 1  1 tegar_ID tegar_ID  1\
 tegar_ID 1  3 2  1 1 9  9 7  1 1 4  1 1 tegar_ID  9 7  1 tegar_ID  1 \
1 9  1 tegar_ID tegar_ID  3 2  6 1  3 2  3 4  9 2  4 8  5 1  5 1  9 1 \
 5 7  4 8  5 9  4 9  1 tegar_ID 9  3 4  3 2  3 5  3 2  1 tegar_ID tega\
r_ID  9 7  1 1 4  1 tegar_ID 7  1 tegar_ID  7 1  7 6  3 2  6 1  3 2  3\
 4  9 2  4 8  5 1  5 1  9 1  5 7  5 4  5 9  4 9  1 tegar_ID 9  3 4  3 \
2  3 5  3 2  6 6  1 tegar_ID 8  1 1 7  1 tegar_ID 1  3 2  9 7  1 1 3  \
1 1 7  9 7  1 tegar_ID  6 6  6 6  3 2  6 1  3 2  3 4  9 2  4 8  5 1  5\
 1  9 1  5 1  5 2  5 9  4 9  1 tegar_ID 9  3 4  3 2  3 5  3 2  6 6  1 \
tegar_ID 8  1 1 7  1 tegar_ID 1  3 2  1 tegar_ID 8  1 tegar_ID 5  1 te\
gar_ID 3  1 tegar_ID 4  1 1 6  1 tegar_ID  8 9  8 9  3 2  6 1  3 2  3 \
4  9 2  4 8  5 1  5 1  9 1  5 1  5 1  5 9  4 9  1 tegar_ID 9  3 4  3 2\
  3 5  3 2  8 9  1 tegar_ID 1  1 tegar_ID 8  1 tegar_ID 8  1 1 1  1 1 \
9  3 2  1 tegar_ID 8  1 tegar_ID 5  1 tegar_ID 3  1 tegar_ID 4  1 1 6 \
 1 tegar_ID  7 1  7 1  3 2  6 1  3 2  3 4  9 2  4 8  5 1  5 1  9 1  5 \
1  5 tegar_ID  5 9  4 9  1 tegar_ID 9  3 4  3 2  3 5  3 2  7 1  1 1 4 \
 1 tegar_ID 1  1 tegar_ID 1  1 1 tegar_ID  3 2  1 tegar_ID 8  1 tegar_\
ID 5  1 tegar_ID 3  1 tegar_ID 4  1 1 6  1 tegar_ID  8 7  8 7  3 2  6 \
1  3 2  3 4  9 2  4 8  5 1  5 1  9 1  4 8  5 9  4 9  1 tegar_ID 9  3 4\
  3 2  3 2  3 5  3 2  8 7  1 tegar_ID 4  1 tegar_ID 5  1 1 6  1 tegar_\
ID 1  3 2  1 tegar_ID 8  1 tegar_ID 5  1 tegar_ID 3  1 tegar_ID 4  1 1\
 6  1 tegar_ID  8 2  8 2  3 2  6 1  3 2  3 4  9 2  4 8  5 1  5 1  9 1 \
 5 1  4 9  5 9  4 9  1 tegar_ID 9  3 4  3 2  3 5  3 2  8 2  1 tegar_ID\
 1  1 tegar_ID tegar_ID  3 2  1 tegar_ID 8  1 tegar_ID 5  1 tegar_ID 3\
  1 tegar_ID 4  1 1 6  1 tegar_ID  6 7  6 7  3 2  6 1  3 2  3 4  9 2  \
4 8  5 1  5 1  9 1  5 1  5 4  5 9  4 9  1 tegar_ID 9  3 4  3 2  3 5  3\
 2  6 7  1 2 1  9 7  1 1 tegar_ID  3 2  1 tegar_ID 8  1 tegar_ID 5  1 \
tegar_ID 3  1 tegar_ID 4  1 1 6  1 tegar_ID  6 6  3 2  6 1  3 2  3 4  \
9 2  4 8  5 1  5 1  9 1  5 1  5 2  1 tegar_ID 9  3 4  3 2  3 2  3 2  3\
 2  3 5  3 2  6 6  1 tegar_ID 8  1 1 7  1 tegar_ID 1  1 tegar_ID  8 9 \
 3 2  6 1  3 2  3 4  9 2  4 8  5 1  5 1  9 1  5 1  5 1  5 9  4 9  1 te\
gar_ID 9  3 4  3 2  3 2  3 2  3 2  3 5  3 2  8 9  1 tegar_ID 1  1 tega\
r_ID 8  1 tegar_ID 8  1 1 1  1 1 9  1 tegar_ID  7 1  3 2  6 1  3 2  3 \
4  9 2  4 8  5 1  5 1  9 1  5 1  5 tegar_ID  1 tegar_ID 9  3 4  3 2  3\
 2  3 2  3 2  3 5  3 2  7 1  1 1 4  1 tegar_ID 1  1 tegar_ID 1  1 1 te\
gar_ID  1 tegar_ID  8 7  3 2  6 1  3 2  3 4  9 2  4 8  5 1  5 1  9 1  \
4 8  5 9  4 9  1 tegar_ID 9  3 4  3 2  3 2  3 2  3 2  3 2  3 5  3 2  8\
 7  1 tegar_ID 4  1 tegar_ID 5  1 1 6  1 tegar_ID 1  1 tegar_ID  8 2  \
3 2  6 1  3 2  3 4  9 2  4 8  5 1  5 1  9 1  5 1  4 9  1 tegar_ID 9  3\
 4  3 2  3 2  3 2  3 2  3 5  3 2  8 2  1 tegar_ID 1  1 tegar_ID tegar_\
ID  1 tegar_ID  6 7  3 2  6 1  3 2  3 4  9 2  4 8  5 1  5 1  9 1  5 1 \
 5 4  5 9  4 9  1 tegar_ID 9  3 4  3 2  3 2  3 2  3 2  3 5  3 2  6 7  \
1 2 1  9 7  1 1 tegar_ID  1 tegar_ID  1 1 1  1 1 5  4 6  1 1 5  1 2 1 \
 1 1 5  1 1 6  1 tegar_ID 1  1 tegar_ID 9  4 tegar_ID  3 4  9 9  1 teg\
ar_ID 8  1 tegar_ID 1  9 7  1 1 4  3 4  4 1  1 tegar_ID  1 tegar_ID  1\
 1 2  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2  6 7  4 3  3 4  3 \
2  3 2  9 5  9 5  9 5  9 5  9 5  9 5  9 5  9 5  9 5  9 5  9 5  9 5  3 \
4  1 tegar_ID  1 1 2  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2  6\
 7  4 3  3 4  3 2  3 2  2 2 6  1 4 9  1 4 5  3 4  4 3  7 1  4 3  3 4  \
2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 teg\
ar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  \
2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 teg\
ar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  \
3 4  4 3  6 7  4 3  3 4  2 2 6  1 4 9  1 4 5  3 4  1 tegar_ID  1 1 2  \
1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2  6 7  4 3  3 4  3 2  3 2\
  2 2 6  1 4 9  1 4 5  3 4  4 3  7 1  4 3  3 4  2 2 6  1 5 tegar_ID  1\
 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1\
 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1\
 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1\
 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  3 4  4 3  6 7  4 3  3 \
4  2 2 6  1 4 9  1 4 5  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3\
 2  3 2  3 4  4 3  6 6  4 3  3 4  2 2 6  1 4 9  1 4 8  2 2 6  1 4 9  1\
 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 5 1  2 2 6  1 4 9  1 4 8  2\
 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 5 1  2 2 6  1 4 9  1 4 8  2 2 6  1\
 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 5 1  2 2 6  1 4 9  1\
 4 8  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 5 1  2\
 2 6  1 4 9  1 4 8  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 5 1  3 2  3 2\
  3 4  4 3  8 2  4 3  3 4  2 2 6  1 4 9  1 4 8  2 2 6  1 4 9  1 4 4  2\
 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 5 1  2 2 6  1 4 9  1 4 8  2 2 6  1\
 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 5 1  3 4  1 tegar_ID\
  1 1 2  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2  6 7  4 3  3 4 \
 3 2  3 2  2 2 6  1 4 9  1 4 5  3 4  4 3  7 1  4 3  3 4  2 2 6  1 5 te\
gar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6 \
 2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 te\
gar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6 \
 2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  3 4  4 3  6 7\
  4 3  3 4  2 2 6  1 4 9  1 4 5  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 \
2  3 2  3 2  3 2  3 4  4 3  6 6  4 3  3 4  2 2 6  1 4 9  1 5 4  2 2 6 \
 1 4 9  1 5 1  2 2 6  1 4 9  1 4 8  2 2 6  1 4 9  1 5 7  2 2 6  1 4 9 \
 1 4 5  2 2 6  1 4 9  1 6 6  2 2 6  1 4 9  1 5 7  2 2 6  1 4 9  1 4 5 \
 2 2 6  1 4 9  1 4 8  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 6 3  2 2 6 \
 1 4 9  1 4 5  2 2 6  1 4 9  1 4 8  2 2 6  1 4 9  1 5 1  2 2 6  1 4 9 \
 1 4 5  2 2 6  1 4 9  1 4 5  2 2 6  1 4 9  1 7 2  2 2 6  1 4 9  1 4 5 \
 3 2  3 2  3 4  4 3  8 2  4 3  3 4  2 2 6  1 4 9  1 5 4  2 2 6  1 4 9 \
 1 4 5  2 2 6  1 4 9  1 4 5  2 2 6  1 4 9  1 5 7  2 2 6  1 4 9  1 5 4 \
 2 2 6  1 4 9  1 5 1  2 2 6  1 4 9  1 5 1  2 2 6  1 4 9  1 4 5  3 4  1\
 tegar_ID  1 1 2  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2  6 7  \
4 3  3 4  3 2  3 2  2 2 6  1 4 9  1 4 5  3 4  4 3  7 1  4 3  3 4  2 2 \
6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_I\
D  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 \
6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_I\
D  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  3 4 \
 4 3  6 7  4 3  3 4  2 2 6  1 4 9  1 4 5  3 2  3 2  3 2  3 2  3 2  3 2\
  3 2  3 2  3 2  3 2  3 2  3 4  4 3  6 6  4 3  3 4  2 2 6  1 4 8  1 2 \
8  2 2 6  1 4 9  1 4 5  2 2 6  1 4 9  1 4 5  2 2 6  1 4 8  1 2 8  2 2 \
6  1 4 9  1 4 5  2 2 6  1 4 9  1 6 9  2 2 6  1 4 9  1 5 1  2 2 6  1 4 \
9  1 4 5  2 2 6  1 4 9  1 5 4  2 2 6  1 4 9  1 5 1  2 2 6  1 4 9  1 4 \
5  2 2 6  1 4 9  1 4 5  2 2 6  1 4 9  1 6 tegar_ID  2 2 6  1 4 9  1 6 \
3  2 2 6  1 4 9  1 4 5  2 2 6  1 4 9  1 4 5  2 2 6  1 4 9  1 5 1  2 2 \
6  1 4 9  1 6 3  3 2  3 2  3 4  4 3  8 2  4 3  3 4  2 2 6  1 4 9  1 4 \
8  2 2 6  1 4 9  1 4 5  2 2 6  1 4 9  1 4 5  2 2 6  1 4 9  1 5 1  2 2 \
6  1 4 9  1 4 8  2 2 6  1 4 9  1 6 9  2 2 6  1 4 9  1 5 7  2 2 6  1 4 \
9  1 4 5  3 4  1 tegar_ID  1 1 2  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1\
 1 6  3 2  6 7  4 3  3 4  3 2  3 2  2 2 6  1 4 9  1 4 5  3 4  4 3  7 1\
  4 3  3 4  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 \
2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar\
_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 \
2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar\
_ID  1 4 6  3 4  4 3  6 7  4 3  3 4  2 2 6  1 4 9  1 4 5  3 2  3 2  3 \
2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 4  4 3  6 6  4 3  3 4  2 \
2 6  1 4 8  1 2 8  2 2 6  1 4 9  1 5 4  2 2 6  1 4 9  1 5 7  2 2 6  1 \
4 8  1 2 8  2 2 6  1 4 9  1 5 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 \
5 7  2 2 6  1 4 9  1 5 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 \
2 6  1 4 9  1 5 7  2 2 6  1 4 9  1 5 4  2 2 6  1 4 9  1 5 7  2 2 6  1 \
4 9  1 5 4  2 2 6  1 4 9  1 5 7  2 2 6  1 4 9  1 5 4  2 2 6  1 4 9  1 \
6 9  2 2 6  1 4 9  1 5 7  3 2  3 2  3 4  4 3  8 2  4 3  3 4  2 2 6  1 \
4 9  1 5 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 \
5 7  2 2 6  1 4 9  1 5 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 \
2 6  1 4 9  1 5 7  3 4  1 tegar_ID  1 1 2  1 1 4  1 tegar_ID 5  1 1 te\
gar_ID  1 1 6  3 2  6 7  4 3  3 4  3 2  3 2  2 2 6  1 4 9  1 4 5  3 4 \
 4 3  7 1  4 3  3 4  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  \
1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  \
1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  \
1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  1 5 tegar_ID  1 4 6  2 2 6  \
1 5 tegar_ID  1 4 6  3 4  4 3  6 7  4 3  3 4  2 2 6  1 4 9  1 4 5  3 4\
  1 tegar_ID  1 1 2  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2  6 \
7  4 3  3 4  3 2  2 2 6  1 4 9  1 4 8  2 2 6  1 4 9  1 4 4  2 2 6  1 4\
 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4\
 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2\
 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4\
 9  1 4 4  2 2 6  1 4 9  1 5 1  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2\
  3 2  3 2  3 2  3 2  3 2  3 2  3 4  4 3  8 9  4 3  3 4  9 1  3 4  4 3\
  8 2  4 3  3 4  3 3  3 4  4 3  8 9  4 3  3 4  9 3  3 2  3 4  4 3  8 7\
  4 3  3 4  8 3  1 2 1  1 1 5  1 1 6  1 tegar_ID 1  1 tegar_ID 9  3 2 \
 6 8  1 1 1  1 1 9  1 1 tegar_ID  3 2  3 4  4 3  8 9  4 3  3 4  9 1  3\
 4  4 3  8 2  4 3  3 4  3 3  3 4  4 3  8 9  4 3  3 4  9 3  3 4  1 tega\
r_ID  1 1 2  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2  6 7  4 3  \
3 4  3 2  2 2 6  1 4 9  1 5 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 \
4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 \
6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 \
9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 \
4  2 2 6  1 4 9  1 5 7  3 4  1 tegar_ID  1 1 2  1 1 4  1 tegar_ID 5  1\
 1 tegar_ID  1 1 6  3 2  6 7  4 3  3 4  3 2  3 2  2 2 6  1 4 9  1 4 5 \
 3 4  4 3  8 9  4 3  3 4  2 2 6  1 5 tegar_ID  1 3 6  2 2 6  1 5 tegar\
_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6  2 \
2 6  1 5 tegar_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6  2 2 6  1 5 tegar\
_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6  2 \
2 6  1 5 tegar_ID  1 3 6  3 4  4 3  6 7  4 3  3 4  2 2 6  1 4 9  1 5 4\
  2 2 6  1 4 9  1 5 1  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 \
2  3 2  3 2  3 4  4 3  8 2  4 3  3 4  8 7  1 tegar_ID 4  9 7  1 1 6  1\
 1 5  6 5  1 1 2  1 1 2  3 2  3 4  4 3  8 9  4 3  3 4  5 8  3 2  3 4  \
4 3  7 1  4 3  3 4  4 8  5 6  5 tegar_ID  4 9  5 tegar_ID  5 3  4 8  5\
 4  5 6  5 4  5 4  5 3  3 4  1 tegar_ID  1 1 2  1 1 4  1 tegar_ID 5  1\
 1 tegar_ID  1 1 6  3 2  6 7  4 3  3 4  3 2  3 2  2 2 6  1 4 9  1 4 5 \
 3 4  4 3  8 9  4 3  3 4  2 2 6  1 5 tegar_ID  1 3 6  2 2 6  1 5 tegar\
_ID  1 3 6  3 4  4 3  6 7  4 3  3 4  2 2 6  1 4 9  1 4 8  2 2 6  1 4 9\
  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 5 1  3 4  4 3  8 9  4 3 \
 3 4  2 2 6  1 5 tegar_ID  1 3 6  3 4  4 3  6 7  4 3  3 4  2 2 6  1 4 \
9  1 4 8  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 5 1  3 4  4 3  8 9  4 3\
  3 4  2 2 6  1 5 tegar_ID  1 3 6  3 4  4 3  6 7  4 3  3 4  2 2 6  1 4\
 9  1 4 5  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2 \
 3 4  4 3  8 2  4 3  3 4  7 tegar_ID  9 7  9 9  1 tegar_ID 1  9 8  1 1\
 1  1 1 1  1 tegar_ID 7  3 2  3 4  4 3  8 9  4 3  3 4  5 8  3 2  3 4  \
4 3  7 1  4 3  3 4  8 4  1 tegar_ID 1  1 tegar_ID 3  9 7  1 1 4  3 2  \
8 3  9 7  9 8  1 tegar_ID 5  1 tegar_ID 8  9 7  3 4  1 tegar_ID  1 1 2\
  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2  6 7  4 3  3 4  3 2  3\
 2  2 2 6  1 4 9  1 4 5  3 4  4 3  8 9  4 3  3 4  2 2 6  1 5 tegar_ID \
 1 3 6  2 2 6  1 5 tegar_ID  1 3 6  3 4  4 3  6 7  4 3  3 4  2 2 6  1 \
4 9  1 4 5  3 4  4 3  8 2  4 3  3 4  2 2 6  1 4 9  1 7 2  3 4  4 3  6 \
7  4 3  3 4  2 2 6  1 4 9  1 4 8  2 2 6  1 4 9  1 5 7  3 4  4 3  8 9  \
4 3  3 4  2 2 6  1 5 tegar_ID  1 3 6  3 4  4 3  6 7  4 3  3 4  2 2 6  \
1 4 9  1 5 4  2 2 6  1 4 9  1 5 1  3 4  4 3  6 7  4 3  3 4  2 2 6  1 4\
 9  1 4 5  3 4  4 3  8 9  4 3  3 4  2 2 6  1 5 tegar_ID  1 3 6  3 4  4\
 3  6 7  4 3  3 4  2 2 6  1 4 9  1 4 5  3 4  1 tegar_ID  1 1 2  1 1 4 \
 1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2  6 7  4 3  3 4  3 2  3 2  2 2 \
6  1 4 9  1 4 5  3 4  4 3  8 9  4 3  3 4  2 2 6  1 5 tegar_ID  1 3 6  \
2 2 6  1 5 tegar_ID  1 3 6  3 4  4 3  6 7  4 3  3 4  2 2 6  1 4 9  1 5\
 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 5 7  3 4  4 3  8 9  4 3  3 4 \
 2 2 6  1 5 tegar_ID  1 3 6  3 4  4 3  6 7  4 3  3 4  2 2 6  1 4 9  1 \
4 5  3 4  4 3  8 9  4 3  3 4  2 2 6  1 5 tegar_ID  1 3 6  3 4  4 3  6 \
7  4 3  3 4  2 2 6  1 4 9  1 5 4  2 2 6  1 4 9  1 5 7  3 4  4 3  8 9  \
4 3  3 4  2 2 6  1 5 tegar_ID  1 3 6  3 4  4 3  6 7  4 3  3 4  2 2 6  \
1 4 9  1 4 5  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 4  4\
 3  8 9  4 3  3 4  9 1  3 4  4 3  8 2  4 3  3 4  8 2  7 1  5 2  3 4  4\
 3  8 9  4 3  3 4  9 3  3 2  3 4  4 3  7 1  4 3  3 4  6 6  1 tegar_ID \
8  9 7  9 9  1 tegar_ID 7  9 5  6 7  1 1 1  1 tegar_ID tegar_ID  1 teg\
ar_ID 1  1 1 4  3 2  3 2  3 2  3 4  4 3  8 2  4 3  3 4  2 2 6  1 4 8  \
1 4 3  2 2 6  1 4 8  1 2 9  2 2 6  1 4 8  1 7 9  2 2 6  1 4 8  1 7 9  \
2 2 6  1 4 8  1 7 9  2 2 6  1 4 8  1 2 9  2 2 6  1 4 8  1 7 9  2 2 6  \
1 4 8  1 7 9  2 2 6  1 4 8  1 4 7  3 4  1 tegar_ID  1 1 2  1 1 4  1 te\
gar_ID 5  1 1 tegar_ID  1 1 6  3 2  6 7  4 3  3 4  3 2  3 2  2 2 6  1 \
4 9  1 5 4  2 2 6  1 4 9  1 5 1  3 4  4 3  8 9  4 3  3 4  2 2 6  1 5 t\
egar_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6\
  2 2 6  1 5 tegar_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6  2 2 6  1 5 t\
egar_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6\
  2 2 6  1 5 tegar_ID  1 3 6  3 4  4 3  6 7  4 3  3 4  2 2 6  1 4 9  1\
 4 4  2 2 6  1 4 9  1 5 7  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2\
  3 2  3 2  3 4  4 3  7 1  4 3  3 4  4 3  3 4  4 3  6 7  4 3  3 4  4 6\
  4 7  8 tegar_ID  5 1  8 2  5 3  4 8  7 8  3 2  7 1  5 2  7 8  5 3  3\
 2  3 2  3 2  3 2  3 2  3 4  4 3  8 2  4 3  3 4  2 2 6  1 4 8  1 3 1  \
2 2 6  1 4 8  1 2 9  2 2 6  1 4 8  1 7 1  2 2 6  1 4 8  1 3 1  2 2 6  \
1 4 8  1 3 1  2 2 6  1 4 8  1 4 3  2 2 6  1 4 8  1 7 1  2 2 6  1 4 8  \
1 2 9  2 2 6  1 4 8  1 7 1  2 2 6  1 4 8  1 4 3  2 2 6  1 4 8  1 4 7  \
3 4  1 tegar_ID  1 1 2  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2 \
 6 7  4 3  3 4  3 2  3 2  3 2  3 2  2 2 6  1 4 9  1 5 4  2 2 6  1 4 9 \
 1 5 1  2 2 6  1 4 9  1 4 5  3 4  4 3  8 7  4 3  3 4  2 2 6  1 4 9  1 \
6 tegar_ID  2 2 6  1 4 9  1 6 9  2 2 6  1 4 9  1 6 9  2 2 6  1 4 9  1 \
6 9  2 2 6  1 4 9  1 6 9  2 2 6  1 4 9  1 6 9  2 2 6  1 4 9  1 5 7  3 \
2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 4  4 3  7 \
1  4 3  3 4  4 3  3 4  4 3  6 7  4 3  3 4  7 7  1 1 4  3 2  8 8  7 2  \
9 7  1 tegar_ID 9  1 1 5  1 1 6  1 tegar_ID 1  1 1 4  3 2  3 2  3 2  3\
 2  3 2  3 2  3 2  3 4  4 3  8 2  4 3  3 4  2 2 6  1 4 8  1 3 1  2 2 6\
  1 4 8  1 4 3  2 2 6  1 4 8  1 7 1  2 2 6  1 4 8  1 3 1  2 2 6  1 4 8\
  1 3 1  2 2 6  1 4 8  1 5 1  2 2 6  1 4 8  1 7 1  2 2 6  1 4 8  1 3 1\
  2 2 6  1 4 8  1 3 1  2 2 6  1 4 8  1 3 1  2 2 6  1 4 8  1 3 1  3 4  \
1 tegar_ID  1 1 2  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2  6 7 \
 4 3  3 4  3 2  3 2  3 2  3 2  3 2  2 2 6  1 4 9  1 4 5  2 2 6  1 4 9 \
 1 4 5  2 2 6  1 4 8  1 3 6  2 2 6  1 4 8  1 3 6  2 2 6  1 4 8  1 3 6 \
 2 2 6  1 5 tegar_ID  1 3 6  3 4  4 3  8 9  8 9  4 3  3 4  2 2 6  1 5 \
tegar_ID  1 4 4  3 4  4 3  8 7  8 7  4 3  3 4  2 2 6  1 5 tegar_ID  1 \
3 6  2 2 6  1 5 tegar_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6  2 2 6  1 \
5 tegar_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6  3 4  4 3  8 2  4 3  3 4\
  2 2 6  1 5 tegar_ID  1 4 6  3 4  4 3  8 7  4 3  3 4  4 6  2 3 9  1 8\
 9  1 6 1  1 1 1  7 9  3 2  3 2  3 2  3 2  3 4  4 3  7 1  4 3  3 4  4 \
3  3 4  4 3  6 7  4 3  3 4  7 7  1 tegar_ID 1  8 9  1 1 1  1 1 7  8 3 \
 1 1 7  1 tegar_ID 1  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2\
  3 4  4 3  8 2  4 3  3 4  2 2 6  1 4 8  1 5 1  2 2 6  1 4 8  1 5 5  2\
 2 6  1 4 8  1 5 1  2 2 6  1 4 8  1 2 9  2 2 6  1 4 8  1 8 7  2 2 6  1\
 4 8  1 2 9  2 2 6  1 4 8  1 8 7  2 2 6  1 4 8  1 8 7  2 2 6  1 4 8  1\
 5 5  2 2 6  1 4 8  1 3 1  2 2 6  1 4 8  1 3 1  3 4  1 tegar_ID  1 1 2\
  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2  6 7  4 3  3 4  3 2  3\
 2  3 2  3 2  3 2  2 2 6  1 4 9  1 4 5  3 4  4 3  8 9  4 3  3 4  2 2 6\
  1 5 tegar_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6  3 4  4 3  8 7  4 3 \
 3 4  2 2 6  1 4 9  1 6 tegar_ID  2 2 6  1 4 9  1 6 6  2 2 6  1 4 9  1\
 6 6  2 2 6  1 4 9  1 6 6  2 2 6  1 4 9  1 5 1  3 2  3 2  3 2  3 2  3 \
2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 \
2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 \
4  4 3  8 7  4 3  3 4  2 2 6  1 4 8  1 4 3  2 2 6  1 4 8  1 7 9  2 2 6\
  1 4 8  1 7 9  2 2 6  1 4 8  1 2 9  2 2 6  1 4 8  1 7 9  2 2 6  1 4 8\
  1 7 9  2 2 6  1 4 8  1 7 9  2 2 6  1 4 8  1 4 7  2 2 6  1 4 8  1 4 3\
  2 2 6  1 4 8  1 7 1  2 2 6  1 4 8  1 6 3  2 2 6  1 4 8  1 7 9  2 2 6\
  1 4 8  1 4 7  3 4  1 tegar_ID  1 1 2  1 1 4  1 tegar_ID 5  1 1 tegar\
_ID  1 1 6  3 2  6 7  4 3  3 4  3 2  3 2  3 2  3 2  3 2  2 2 6  1 4 9 \
 1 5 4  2 2 6  1 4 9  1 5 1  3 4  4 3  8 9  4 3  3 4  2 2 6  1 5 tegar\
_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6  2 \
2 6  1 5 tegar_ID  1 3 6  2 2 6  1 5 tegar_ID  1 3 6  2 2 6  1 5 tegar\
_ID  1 3 6  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2\
  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2\
  3 2  3 2  3 2  3 2  3 2  3 2  3 4  4 3  8 7  4 3  3 4  2 2 6  1 4 8 \
 1 3 1  2 2 6  1 4 8  1 3 1  2 2 6  1 4 8  1 3 1  2 2 6  1 4 8  1 3 1 \
 2 2 6  1 4 8  1 3 1  2 2 6  1 4 8  1 3 1  2 2 6  1 4 8  1 3 1  2 2 6 \
 1 4 8  1 3 1  2 2 6  1 4 8  1 6 3  2 2 6  1 4 8  1 8 7  2 2 6  1 4 8 \
 1 7 1  2 2 6  1 4 8  1 3 1  2 2 6  1 4 8  1 3 1  3 4  1 tegar_ID  1 1\
 2  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2  6 7  4 3  3 4  3 2 \
 3 2  3 2  3 2  3 2  3 2  2 2 6  1 4 9  1 5 4  2 2 6  1 4 9  1 4 4  2 \
2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 4 9  1 4 4  2 2 6  1 \
4 9  1 5 7  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2\
  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2\
  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 4  4 3  8 7  4 3  3 4  2 2 6  1\
 4 8  1 6 3  2 2 6  1 4 8  1 4 7  2 2 6  1 4 8  1 3 1  2 2 6  1 4 8  1\
 3 1  2 2 6  1 4 8  1 3 1  2 2 6  1 4 8  1 3 1  2 2 6  1 4 8  1 6 3  2\
 2 6  1 4 8  1 7 1  2 2 6  1 4 8  1 3 1  2 2 6  1 4 8  1 4 3  2 2 6  1\
 4 8  1 8 7  2 2 6  1 4 8  1 8 7  2 2 6  1 4 8  1 7 1  3 4  1 tegar_ID\
  1 1 2  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 1 6  3 2  6 7  4 3  3 4 \
 3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2 \
 3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2 \
 3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2 \
 3 2  3 2  3 2  3 4  4 3  8 7  4 3  3 4  2 2 6  1 4 8  1 5 1  2 2 6  1\
 4 8  1 2 9  2 2 6  1 4 8  1 8 7  2 2 6  1 4 8  1 2 9  2 2 6  1 4 8  1\
 8 7  2 2 6  1 4 8  1 2 9  2 2 6  1 4 8  1 8 7  3 4  4 3  6 7  4 3  3 \
4  2 2 6  1 5 7  1 6 2  3 4  1 tegar_ID  1 1 2  1 1 4  1 tegar_ID 5  1\
 1 tegar_ID  1 1 6  3 2  3 4  3 2  3 4  1 tegar_ID  1 1 6  1 1 4  1 2 \
1  5 8  1 tegar_ID  3 2  3 2  3 2  3 2  1 1 4  9 7  1 1 tegar_ID  1 te\
gar_ID 3  1 tegar_ID 1  3 2  6 1  3 2  1 2 tegar_ID  1 1 4  9 7  1 1 t\
egar_ID  1 tegar_ID 3  1 tegar_ID 1  1 tegar_ID  1 tegar_ID 1  1 2 teg\
ar_ID  9 9  1 tegar_ID 1  1 1 2  1 1 6  3 2  7 8  9 7  1 tegar_ID 9  1\
 tegar_ID 1  6 9  1 1 4  1 1 4  1 1 1  1 1 4  5 8  1 tegar_ID  3 2  3 \
2  3 2  3 2  1 1 2  9 7  1 1 5  1 1 5  1 tegar_ID  1 tegar_ID  6 9  7 \
7  7 9  8 4  7 3  6 7  7 9  7 8  8 3  3 2  6 1  3 2  9 1  3 9  1 1 6  \
1 tegar_ID 1  1 tegar_ID 3  9 7  1 1 4  9 5  7 3  6 8  3 9  4 4  3 2  \
3 9  4 9  3 9  4 4  3 2  3 9  5 tegar_ID  3 9  4 4  3 2  3 9  5 1  3 9\
  4 4  3 2  3 9  5 2  3 9  4 4  3 2  3 9  5 3  3 9  4 4  3 2  3 9  5 4\
  3 9  4 4  3 2  3 9  5 5  3 9  4 4  3 2  3 9  5 6  3 9  4 4  3 2  3 9\
  5 7  3 9  9 3  1 tegar_ID  7 7  6 5  8 8  9 5  8 3  8 4  8 2  9 5  7\
 6  6 9  7 8  3 2  6 1  3 2  5 5  4 8  1 tegar_ID  1 tegar_ID  1 tegar\
_ID tegar_ID  1 tegar_ID 1  1 tegar_ID 2  3 2  1 1 4  1 1 7  1 1 tegar\
_ID  9 5  9 7  1 1 4  1 tegar_ID 3  1 1 2  9 7  1 1 4  1 1 5  1 tegar_\
ID 1  4 tegar_ID  4 1  5 8  1 tegar_ID  3 2  3 2  3 2  3 2  1 1 8  9 7\
  1 1 4  9 5  9 7  1 1 4  1 tegar_ID 3  1 1 5  3 2  6 1  3 2  9 7  1 1\
 4  1 tegar_ID 3  1 1 2  9 7  1 1 4  1 1 5  1 tegar_ID 1  4 6  6 5  1 \
1 4  1 tegar_ID 3  1 1 7  1 tegar_ID 9  1 tegar_ID 1  1 1 tegar_ID  1 \
1 6  8 tegar_ID  9 7  1 1 4  1 1 5  1 tegar_ID 1  1 1 4  4 tegar_ID  1\
 tegar_ID tegar_ID  1 tegar_ID 1  1 1 5  9 9  1 1 4  1 tegar_ID 5  1 1\
 2  1 1 6  1 tegar_ID 5  1 1 1  1 1 tegar_ID  6 1  3 9  9 2  1 1 tegar\
_ID  3 2  7 9  9 8  1 tegar_ID 2  1 1 7  1 1 5  9 9  9 7  1 1 6  1 teg\
ar_ID 1  3 2  1 2 1  1 1 1  1 1 7  1 1 4  3 2  1 1 2  1 2 1  1 1 6  1 \
tegar_ID 4  1 1 1  1 1 tegar_ID  3 2  1 1 5  9 9  1 1 4  1 tegar_ID 5 \
 1 1 2  1 1 6  3 2  9 8  1 2 1  3 2  9 9  1 1 1  1 1 tegar_ID  1 1 8  \
1 tegar_ID 1  1 1 4  1 1 6  1 tegar_ID 5  1 1 tegar_ID  1 tegar_ID 3  \
3 2  9 7  1 1 tegar_ID  3 2  1 tegar_ID 5  1 1 tegar_ID  1 1 2  1 1 7 \
 1 1 6  3 2  1 1 5  9 9  1 1 4  1 tegar_ID 5  1 1 2  1 1 6  3 2  1 1 6\
  1 1 1  3 2  9 7  1 1 tegar_ID  3 2  1 1 1  1 1 7  1 1 6  1 1 2  1 1 \
7  1 1 6  3 2  1 1 5  9 9  1 1 4  1 tegar_ID 5  1 1 2  1 1 6  9 2  1 1\
 tegar_ID  3 2  6 7  1 1 4  1 tegar_ID 1  9 7  1 1 6  1 tegar_ID 1  1 \
tegar_ID tegar_ID  3 2  6 6  1 2 1  3 2  5 8  3 2  8 4  1 tegar_ID 1  \
1 tegar_ID 3  9 7  1 1 4  4 5  7 3  6 8  3 9  4 1  1 tegar_ID  3 2  3 \
2  3 2  3 2  1 1 8  9 7  1 1 4  9 5  9 7  1 1 4  1 tegar_ID 3  1 1 5  \
4 6  9 7  1 tegar_ID tegar_ID  1 tegar_ID tegar_ID  9 5  9 7  1 1 4  1\
 tegar_ID 3  1 1 7  1 tegar_ID 9  1 tegar_ID 1  1 1 tegar_ID  1 1 6  4\
 tegar_ID  3 9  4 5  1 tegar_ID 5  3 9  4 4  3 2  3 9  4 5  4 5  1 teg\
ar_ID 5  1 1 tegar_ID  1 1 2  1 1 7  1 1 6  3 9  4 4  3 2  1 1 4  1 te\
gar_ID 1  1 1 3  1 1 7  1 tegar_ID 5  1 1 4  1 tegar_ID 1  1 tegar_ID \
tegar_ID  6 1  8 4  1 1 4  1 1 7  1 tegar_ID 1  4 4  3 2  1 tegar_ID 4\
  1 tegar_ID 1  1 tegar_ID 8  1 1 2  6 1  3 9  1 tegar_ID 5  1 1 tegar\
_ID  1 1 2  1 1 7  1 1 6  3 2  1 1 2  1 2 1  1 1 6  1 tegar_ID 4  1 1 \
1  1 1 tegar_ID  3 2  1 1 5  9 9  1 1 4  1 tegar_ID 5  1 1 2  1 1 6  3\
 2  1 1 tegar_ID  9 7  1 tegar_ID 9  1 tegar_ID 1  3 9  4 1  1 tegar_I\
D  3 2  3 2  3 2  3 2  1 1 8  9 7  1 1 4  9 5  9 7  1 1 4  1 tegar_ID \
3  1 1 5  4 6  9 7  1 tegar_ID tegar_ID  1 tegar_ID tegar_ID  9 5  9 7\
  1 1 4  1 tegar_ID 3  1 1 7  1 tegar_ID 9  1 tegar_ID 1  1 1 tegar_ID\
  1 1 6  4 tegar_ID  3 9  4 5  1 1 1  3 9  4 4  3 2  3 9  4 5  4 5  1 \
1 1  1 1 7  1 1 6  1 1 2  1 1 7  1 1 6  3 9  4 4  3 2  1 1 4  1 tegar_\
ID 1  1 1 3  1 1 7  1 tegar_ID 5  1 1 4  1 tegar_ID 1  1 tegar_ID tega\
r_ID  6 1  8 4  1 1 4  1 1 7  1 tegar_ID 1  4 4  3 2  1 tegar_ID 4  1 \
tegar_ID 1  1 tegar_ID 8  1 1 2  6 1  3 9  1 1 1  1 1 7  1 1 6  1 1 2 \
 1 1 7  1 1 6  3 2  1 1 2  1 2 1  1 1 6  1 tegar_ID 4  1 1 1  1 1 tega\
r_ID  3 2  1 1 5  9 9  1 1 4  1 tegar_ID 5  1 1 2  1 1 6  3 2  1 1 teg\
ar_ID  9 7  1 tegar_ID 9  1 tegar_ID 1  3 9  4 1  1 tegar_ID  3 2  3 2\
  3 2  3 2  1 1 4  1 tegar_ID 1  1 1 6  1 1 7  1 1 4  1 1 tegar_ID  3 \
2  1 1 8  9 7  1 1 4  9 5  9 7  1 1 4  1 tegar_ID 3  1 1 5  4 6  1 1 2\
  9 7  1 1 4  1 1 5  1 tegar_ID 1  9 5  9 7  1 1 4  1 tegar_ID 3  1 1 \
5  4 tegar_ID  4 1  1 tegar_ID  1 tegar_ID  1 tegar_ID  1 tegar_ID teg\
ar_ID  1 tegar_ID 1  1 tegar_ID 2  3 2  9 9  1 tegar_ID 4  1 1 7  1 1 \
tegar_ID  1 tegar_ID 7  9 5  1 1 5  1 1 6  1 1 4  1 tegar_ID 5  1 1 te\
gar_ID  1 tegar_ID 3  4 tegar_ID  1 1 2  9 7  1 1 4  9 5  9 7  4 4  3 \
2  1 1 2  9 7  1 1 4  9 5  9 8  4 1  5 8  1 tegar_ID  3 2  3 2  3 2  3\
 2  1 1 4  1 tegar_ID 1  1 1 6  1 1 7  1 1 4  1 1 tegar_ID  3 2  4 teg\
ar_ID  3 9  9 2  1 1 tegar_ID  3 9  4 1  4 6  1 tegar_ID 6  1 1 1  1 t\
egar_ID 5  1 1 tegar_ID  4 tegar_ID  4 tegar_ID  3 9  1 2 3  1 2 5  9 \
2  9 2  3 9  4 1  4 6  1 tegar_ID 2  1 1 1  1 1 4  1 tegar_ID 9  9 7  \
1 1 6  4 tegar_ID  1 1 2  9 7  1 1 4  9 5  9 7  9 1  1 1 8  9 7  1 1 4\
  9 5  1 2 tegar_ID  5 8  1 1 8  9 7  1 1 4  9 5  1 2 tegar_ID  3 2  4\
 3  3 2  1 1 2  9 7  1 1 4  9 5  9 8  9 3  4 1  3 2  1 tegar_ID 2  1 1\
 1  1 1 4  3 2  1 1 8  9 7  1 1 4  9 5  1 2 tegar_ID  3 2  1 tegar_ID \
5  1 1 tegar_ID  3 2  1 1 4  9 7  1 1 tegar_ID  1 tegar_ID 3  1 tegar_\
ID 1  4 tegar_ID  4 8  4 4  3 2  1 tegar_ID 8  1 tegar_ID 1  1 1 tegar\
_ID  4 tegar_ID  1 1 2  9 7  1 1 4  9 5  9 7  4 1  4 4  3 2  1 1 2  9 \
7  1 1 4  9 5  9 8  4 1  4 1  4 6  1 1 4  1 1 5  1 1 6  1 1 4  1 tegar\
_ID 5  1 1 2  4 tegar_ID  3 9  9 2  9 2  3 9  4 1  1 tegar_ID  1 tegar\
_ID  1 tegar_ID  1 tegar_ID tegar_ID  1 tegar_ID 1  1 tegar_ID 2  3 2 \
 1 tegar_ID 1  1 1 tegar_ID  9 9  1 1 1  1 tegar_ID tegar_ID  1 tegar_\
ID 1  9 5  1 1 5  1 1 6  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1 tegar_ID\
 3  4 tegar_ID  1 1 2  9 7  1 1 4  9 5  4 9  4 4  3 2  1 1 2  9 7  1 1\
 4  9 5  5 tegar_ID  4 1  5 8  1 tegar_ID  3 2  3 2  3 2  3 2  3 4  3 \
4  3 4  3 4  3 4  3 4  1 tegar_ID  3 2  3 2  3 2  3 2  1 1 8  9 7  1 1\
 4  9 5  1 tegar_ID tegar_ID  1 tegar_ID 5  9 9  1 1 6  3 2  6 1  3 2 \
 7 9  1 1 4  1 tegar_ID tegar_ID  1 tegar_ID 1  1 1 4  1 tegar_ID 1  1\
 tegar_ID tegar_ID  6 8  1 tegar_ID 5  9 9  1 1 6  4 tegar_ID  1 tegar\
_ID 1  1 1 tegar_ID  1 1 7  1 tegar_ID 9  1 tegar_ID 1  1 1 4  9 7  1 \
1 6  1 tegar_ID 1  4 tegar_ID  1 1 2  9 7  1 1 4  9 5  5 tegar_ID  4 1\
  4 1  1 tegar_ID  3 2  3 2  3 2  3 2  1 1 8  9 7  1 1 4  9 5  1 1 9  \
1 tegar_ID 4  9 7  1 1 6  3 2  6 1  3 2  7 9  1 1 4  1 tegar_ID tegar_\
ID  1 tegar_ID 1  1 1 4  1 tegar_ID 1  1 tegar_ID tegar_ID  6 8  1 teg\
ar_ID 5  9 9  1 1 6  4 tegar_ID  4 tegar_ID  1 1 8  9 7  1 1 4  9 5  1\
 tegar_ID 5  4 4  3 2  1 1 8  9 7  1 1 4  9 5  1 tegar_ID 6  4 1  3 2 \
 1 tegar_ID 2  1 1 1  1 1 4  3 2  1 1 8  9 7  1 1 4  9 5  1 tegar_ID 6\
  4 4  3 2  1 1 8  9 7  1 1 4  9 5  1 tegar_ID 5  3 2  1 tegar_ID 5  1\
 1 tegar_ID  3 2  1 1 8  9 7  1 1 4  9 5  1 tegar_ID tegar_ID  1 tegar\
_ID 5  9 9  1 1 6  4 6  1 tegar_ID 5  1 1 6  1 tegar_ID 1  1 tegar_ID \
9  1 1 5  4 tegar_ID  4 1  4 1  1 tegar_ID  3 2  3 2  3 2  3 2  1 1 4 \
 1 tegar_ID 1  1 1 6  1 1 7  1 1 4  1 1 tegar_ID  3 2  4 tegar_ID  3 9\
  3 5  6 9  1 1 tegar_ID  9 9  1 1 4  1 2 1  1 1 2  1 1 6  1 tegar_ID \
1  1 tegar_ID tegar_ID  3 2  6 6  1 2 1  3 2  8 4  1 tegar_ID 1  1 teg\
ar_ID 3  9 7  1 1 4  4 5  7 3  6 8  9 2  1 1 tegar_ID  3 5  7 1  1 teg\
ar_ID 5  1 1 6  1 tegar_ID 4  1 1 7  9 8  3 2  5 8  3 2  1 tegar_ID 4 \
 1 1 6  1 1 6  1 1 2  1 1 5  5 8  4 7  4 7  1 tegar_ID 3  1 tegar_ID 5\
  1 1 6  1 tegar_ID 4  1 1 7  9 8  4 6  9 9  1 1 1  1 tegar_ID 9  4 7 \
 8 4  1 tegar_ID 1  1 tegar_ID 3  9 7  1 1 4  4 5  7 3  6 8  4 7  9 2 \
 1 1 tegar_ID  3 5  7 4  9 7  1 1 tegar_ID  1 tegar_ID 3  9 7  1 1 teg\
ar_ID  3 2  1 tegar_ID tegar_ID  1 tegar_ID 5  3 2  1 tegar_ID 1  1 te\
gar_ID tegar_ID  1 tegar_ID 5  1 1 6  3 2  1 1 6  1 1 1  1 tegar_ID 8 \
 1 1 1  1 tegar_ID 8  3 2  1 1 tegar_ID  9 7  1 1 tegar_ID  1 1 6  1 t\
egar_ID 5  3 2  1 tegar_ID 1  1 1 4  1 1 4  1 1 1  1 1 4  9 2  1 1 teg\
ar_ID  1 tegar_ID 2  1 1 4  1 1 1  1 tegar_ID 9  3 2  9 9  1 1 1  1 te\
gar_ID 8  1 tegar_ID 8  1 tegar_ID 1  9 9  1 1 6  1 tegar_ID 5  1 1 1 \
 1 1 tegar_ID  1 1 5  3 2  1 tegar_ID 5  1 tegar_ID 9  1 1 2  1 1 1  1\
 1 4  1 1 6  3 2  7 9  1 1 4  1 tegar_ID tegar_ID  1 tegar_ID 1  1 1 4\
  1 tegar_ID 1  1 tegar_ID tegar_ID  6 8  1 tegar_ID 5  9 9  1 1 6  9 \
2  1 1 tegar_ID  1 tegar_ID 1  1 2 tegar_ID  1 tegar_ID 1  9 9  4 tega\
r_ID  3 4  3 4  4 6  1 tegar_ID 6  1 1 1  1 tegar_ID 5  1 1 tegar_ID  \
4 tegar_ID  1 tegar_ID 9  9 7  1 1 2  4 tegar_ID  9 9  1 tegar_ID 4  1\
 1 4  4 4  9 1  1 tegar_ID 5  1 1 tegar_ID  1 1 6  4 tegar_ID  3 4  3 \
4  4 6  1 tegar_ID 6  1 1 1  1 tegar_ID 5  1 1 tegar_ID  4 tegar_ID  1\
 1 5  1 1 6  1 1 4  4 tegar_ID  1 2 3  1 2 5  9 1  1 tegar_ID 5  9 3  \
4 1  3 2  1 tegar_ID 2  1 1 1  1 1 4  3 2  1 tegar_ID 5  3 2  1 tegar_\
ID 5  1 1 tegar_ID  3 2  1 2 tegar_ID  4 6  1 1 5  1 1 2  1 tegar_ID 8\
  1 tegar_ID 5  1 1 6  4 tegar_ID  4 1  4 1  4 1  3 2  1 tegar_ID 2  1\
 1 1  1 1 4  3 2  1 2 tegar_ID  3 2  1 tegar_ID 5  1 1 tegar_ID  9 2  \
1 1 tegar_ID  3 4  1 2 3  1 2 5  3 4  9 2  1 1 tegar_ID  4 6  1 1 5  1\
 1 2  1 tegar_ID 8  1 tegar_ID 5  1 1 6  4 tegar_ID  3 4  3 2  3 2  3 \
4  4 1  9 3  4 1  4 1  4 1  9 2  1 1 tegar_ID  3 9  4 1  4 6  1 tegar_\
ID 2  1 1 1  1 1 4  1 tegar_ID 9  9 7  1 1 6  4 tegar_ID  1 1 2  1 teg\
ar_ID 2  1 1 1  1 1 4  1 tegar_ID 9  9 7  1 1 6  4 tegar_ID  1 1 8  9 \
7  1 1 4  9 5  1 1 9  1 tegar_ID 4  9 7  1 1 6  4 1  4 4  3 2  9 9  1 \
tegar_ID 4  1 1 7  1 1 tegar_ID  1 tegar_ID 7  9 5  1 1 5  1 1 6  1 1 \
4  1 tegar_ID 5  1 1 tegar_ID  1 tegar_ID 3  4 tegar_ID  4 tegar_ID  3\
 9  3 2  3 2  3 9  4 1  4 6  1 tegar_ID 6  1 1 1  1 tegar_ID 5  1 1 te\
gar_ID  4 tegar_ID  4 tegar_ID  3 9  3 2  3 9  4 1  4 6  1 tegar_ID 6 \
 1 1 1  1 tegar_ID 5  1 1 tegar_ID  4 tegar_ID  1 1 8  9 7  1 1 4  9 5\
  1 tegar_ID tegar_ID  1 tegar_ID 5  9 9  1 1 6  9 1  1 tegar_ID 5  1 \
1 tegar_ID  1 1 6  4 tegar_ID  1 1 8  9 7  1 1 4  9 5  1 2 1  4 1  9 3\
  3 2  1 tegar_ID 2  1 1 1  1 1 4  3 2  1 1 8  9 7  1 1 4  9 5  1 2 1 \
 3 2  1 tegar_ID 5  1 1 tegar_ID  3 2  1 1 5  1 1 6  1 1 4  4 tegar_ID\
  1 1 1  1 1 4  1 tegar_ID tegar_ID  4 tegar_ID  1 1 8  9 7  1 1 4  9 \
5  1 2 2  4 1  4 1  4 1  3 2  1 tegar_ID 2  1 1 1  1 1 4  3 2  1 1 8  \
9 7  1 1 4  9 5  1 2 2  3 2  1 tegar_ID 5  1 1 tegar_ID  3 2  1 1 2  9\
 7  1 1 4  9 5  4 9  4 1  4 4  3 2  7 7  6 5  8 8  9 5  8 3  8 4  8 2 \
 9 5  7 6  6 9  7 8  4 1  4 1  1 tegar_ID  1 tegar_ID  1 tegar_ID  1 t\
egar_ID tegar_ID  1 tegar_ID 1  1 tegar_ID 2  3 2  1 tegar_ID 9  9 7  \
1 tegar_ID 5  1 1 tegar_ID  4 tegar_ID  1 1 2  9 7  1 1 4  9 5  5 1  4\
 4  3 2  1 1 2  9 7  1 1 4  9 5  5 2  4 1  5 8  1 tegar_ID  3 2  3 2  \
3 2  3 2  3 4  3 4  3 4  3 4  3 4  3 4  1 tegar_ID  3 2  3 2  3 2  3 2\
  1 1 9  1 tegar_ID 5  1 1 6  1 tegar_ID 4  3 2  1 1 1  1 1 2  1 tegar\
_ID 1  1 1 tegar_ID  4 tegar_ID  1 1 2  9 7  1 1 4  9 5  5 1  4 1  3 2\
  9 7  1 1 5  3 2  4 tegar_ID  1 1 8  9 7  1 1 4  9 5  1 tegar_ID 2  1\
 1 5  1 1 4  9 9  4 1  5 8  1 tegar_ID  3 2  3 2  3 2  3 2  3 2  3 2  \
3 2  3 2  1 1 9  1 tegar_ID 5  1 1 6  1 tegar_ID 4  3 2  1 1 1  1 1 2 \
 1 tegar_ID 1  1 1 tegar_ID  4 tegar_ID  1 1 2  9 7  1 1 4  9 5  5 2  \
4 4  3 2  3 9  1 1 9  3 9  4 1  3 2  9 7  1 1 5  3 2  4 tegar_ID  1 1 \
8  9 7  1 1 4  9 5  1 tegar_ID 2  1 tegar_ID tegar_ID  1 1 5  1 1 6  4\
 1  5 8  1 tegar_ID  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2  3 2 \
 3 2  3 2  1 1 8  9 7  1 1 4  9 5  1 tegar_ID 2  1 tegar_ID tegar_ID  \
1 1 5  1 1 6  4 6  1 1 9  1 1 4  1 tegar_ID 5  1 1 6  1 tegar_ID 1  4 \
tegar_ID  1 tegar_ID 1  1 1 tegar_ID  9 9  1 1 1  1 tegar_ID tegar_ID \
 1 tegar_ID 1  9 5  1 1 5  1 1 6  1 1 4  1 tegar_ID 5  1 1 tegar_ID  1\
 tegar_ID 3  4 tegar_ID  1 1 8  9 7  1 1 4  9 5  1 tegar_ID 2  1 1 5  \
1 1 4  9 9  4 6  1 1 4  1 tegar_ID 1  9 7  1 tegar_ID tegar_ID  4 tega\
r_ID  4 1  4 4  3 2  6 9  7 7  7 9  8 4  7 3  6 7  7 9  7 8  8 3  4 1 \
 4 1  1 tegar_ID  1 tegar_ID  1 tegar_ID  1 tegar_ID 5  1 tegar_ID 2  \
3 2  9 5  9 5  1 1 tegar_ID  9 7  1 tegar_ID 9  1 tegar_ID 1  9 5  9 5\
  3 2  6 1  6 1  3 2  3 9  9 5  9 5  1 tegar_ID 9  9 7  1 tegar_ID 5  \
1 1 tegar_ID  9 5  9 5  3 9  5 8  1 tegar_ID  3 2  3 2  3 2  3 2  9 7 \
 1 1 4  1 tegar_ID 3  1 1 5  3 2  6 1  3 2  1 1 4  1 1 7  1 1 tegar_ID\
  9 5  9 7  1 1 4  1 tegar_ID 3  1 1 2  9 7  1 1 4  1 1 5  1 tegar_ID \
1  4 tegar_ID  4 1  1 tegar_ID  3 2  3 2  3 2  3 2  1 tegar_ID 9  9 7 \
 1 tegar_ID 5  1 1 tegar_ID  4 tegar_ID  9 7  1 1 4  1 tegar_ID 3  1 1\
 5  4 6  1 tegar_ID 5  1 1 tegar_ID  1 1 2  1 1 7  1 1 6  4 4  3 2  9 \
7  1 1 4  1 tegar_ID 3  1 1 5  4 6  1 1 1  1 1 7  1 1 6  1 1 2  1 1 7 \
 1 1 6  4 1  1 tegar_ID"
.split("  ")])))
