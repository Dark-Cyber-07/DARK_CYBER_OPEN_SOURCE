If You Get Error Decompile, Error code saved to code.py
FB-BOT-enc.py: No Compile Module given !!
