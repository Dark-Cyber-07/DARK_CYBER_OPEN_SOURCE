If You Get Error Decompile, Error code saved to code.py
4MBF.py: No Compile Module given !!
