import os

try:
    import requests
except ImportError:
    print '\n [!] \x1b[0;91mmodule requests belum terinstall \x1b[0;97m'
    os.system('pip2 install requests')


try:
    import concurrent.futures as concurrent
except ImportError:
    print '\n [!] \x1b[0;91mmodule futures belum terinstall\x1b[0;97m'
    os.system('pip2 install futures')


try:
    import bs4
except ImportError:
    print '\n [!] \x1b[0;91mmodule futures belum terinstall\x1b[0;97m'
    os.system('pip2 install bs4')


try:
    import mechanize
except ImportError:
    print '\n [!] \x1b[0;91mmodule futures belum terinstall\x1b[0;97m'
    os.system('pip2 install mechanize')

terapapaalamgir = '\n\x1b[1;32\n\n\x1b[1;33m Fb : FUCK BOY TERA PAPA ALAMGIR \n\x1b[1;32m TEAM :-THE DARK WORLD TEAM \n\x1b[1;32m WHATS APPS  :- +8801712034653 \n\x1b[1;32m FACEBOOK :- FUCK BOY ALAMGIR \n\x1b[1;33m NEED HELP GO AND SUB THANKS \n__________________________________\n'
import os
import sys
import time
import requests
import random
from concurrent.futures import ThreadPoolExecutor
os.system('clear')

def alamgirallinone():
    print terapapaalamgir
    os.system('echo -e 1.  MAFIA CMND CLNING | lolcat')
    os.system('echo -e 2.  MR BETA VERSION CMND CLNING| lolcat')
    os.system('echo -e 3.  QADIR KING CMND CLNING| lolcat')
    os.system('echo -e 4.  HAMI KING CLNING CMND| lolcat')
    os.system('echo -e 5.  RANA MZ ZESHI CMND CLNING| lolcat')
    os.system('echo -e 6.  FILE CREATE TECHQAISER| lolcat')
    os.system('echo -e 7.  SARFARAZ CRACK_FB CMND| lolcat')
    os.system('echo -e 8.  BILALKHAN BSN CLNING CMND| lolcat')
    os.system('echo -e 9.  BD HACKER CLONE1 CMND CLNING| lolcat')
    os.system('echo -e 10. DARWESH66 DX CLNING CMND| lolcat')
    os.system('echo -e 11. ALON3RISHU NEW| lolcat')
    os.system('echo -e 12. TECHQAISER FUCK CLNING CMND| lolcat')
    os.system('echo -e 13. AHSAN TECHQ CLNING CMND| lolcat')
    os.system('echo -e 14. KHAN CLNING CMND| lolcat')
    os.system('echo -e 15. NO LOGIN TQ CMND CLNING| lolcat')
    os.system('echo -e 16. QAISER TQA CLNING CMND | lolcat')
    os.system('echo -e 17. HAMMI-KING06 CLNING CMND| lolcat')
    os.system('echo -e 18. ABDULLAHDADA ELITE CLNING CMND| lolcat')
    os.system('echo -e 19. SASIYABA SASI2 CLNING CMND| lolcat')
    os.system('echo -e 20. RANAMZ SP3D| lolcat')
    os.system('echo -e 21. RANAMZ ZESHI| lolcat')
    os.system('echo -e 22. SYEDZADA LEGEND CLNING CMND| lolcat')
    os.system('echo -e 23. TECHABM FBC CLNING CMND| lolcat')
    os.system('echo -e 24. MARKZUCK ROM CLNING CMND| lolcat')
    os.system('echo -e 25. SHINZY24 XZY CMND CLNING| lolcat')
    os.system('echo -e 26. MRJEEK SIMBF CLNING CMND| lolcat')
    os.system('echo -e 27. FARITRICKER FK CLNING CMND| lolcat')
    os.system('echo -e 28. DEMONANNOS APRO CLNING CMND| lolcat')
    os.system('echo -e 29. BYPASS AHMADALICLNING CMND| lolcat')
    os.system('echo -e 30. DAPUNTA SBF CLNING CMND| lolcat')
    os.system('echo -e 31. ZKWORLD ZMBF CMND CLNING| lolcat')
    os.system('echo -e 32. KANGPROF MASSALL CLNING CMND | lolcat')
    os.system('echo -e 33. AIJAZ HARI CLNING CMND| lolcat')
    os.system('echo -e 34. ANGCYBER CRACK CLNING CMND| lolcat')
    os.system('echo -e 35. BLACK19114 MBF3.0 CLNING CMND| lolcat')
    os.system('echo -e 36. NIKILPATEL NICK CLNING CMND| lolcat')
    os.system('echo -e 37. KABIR SINGH CLNING CMND| lolcat')
    os.system('echo -e 38. MAFIAXD ELGA CLNING CMND| lolcat')
    os.system('echo -e 39. W1BU-CR4CK ZEROTWO CLNING CMND| lolcat')
    os.system('echo -e 40.  ---- CREDITS -----| lolcat')
    pepek = raw_input('\n [>] menu : ')
    if pepek == '':
        print '\n Please ! Fill Correctly!'
        time.sleep(2)
        tqa_abbas()
    elif pepek in ('1', '01'):
        os.system('git clone https://github.com/Mafia-XD/MANDA27')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd MANDA27 && python2 manda27.py')
        
    elif pepek in ('2', '02'):
        os.system('git clone https://github.com/Mr-Beta-Version/BetaPaid')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd BetaPaid && python2 Start.py')
        
    elif pepek in ('3', '03'):
        os.system('git clone https://github.com/Qadirking/Mahar.git')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Mahar && python2 Qadir.py')
        
    elif pepek in ('4', '04'):
        os.system('git clone https://github.com/Hamii-king-06/Pro')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Pro && python2 Pro.py')
        
    elif pepek in ('5', '05'):
        os.system('git clone https://github.com/RANAMZ-zeshi/mz-zeshii.git')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd mz-zeeshii && python2 Rana.MZ')
        
    elif pepek in ('6', '06'):
        os.system('git clone https://github.com/TechQaiser/Run')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Run && python2 run.py')
        
    elif pepek in ('7', '07'):
        os.system('git clone https://github.com/Sarfraz-Baloch/Crack_fb')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Crack_fb && python2 Ok.py')
        
    elif pepek in ('8', '08'):
        os.system('git clone https://github.com/BIL4L-KH4N/BSN')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('pkg install bash')
            os.system('ls && cd BSN && chmod 777 bsn && ./bsn')
        
    elif pepek in ('9', '09'):
        os.system('git clone https://github.com/dark-hacker-bd/dark-clone1')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd dark-clone1 && python2 dark-clone1.py')
        
    elif pepek in ('10', '000'):
        os.system('git clone https://github.com/darwesh66/Dx')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Dx && python2 DX.py')
        
    elif pepek in ('11', '011'):
        os.system('git clone https://github.com/Alon3-Rishu/new')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd new && python2 run.py')
        
    elif pepek in ('12', '012'):
        os.system('git clone https://github.com/TechQaiser/Fuck')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Fuck && python2 Fuck')
        
    elif pepek in ('13', '013'):
        os.system('git clone https://github.com/TechQaiser/Ahsan')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Ahsan && python2 Ahsan.py ')
        
    elif pepek in ('14', '014'):
        os.system('git clone https://github.com/TechQaiser/Khan')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Khan && python2 Khan.py')
        
    elif pepek in ('15', '015'):
        print 'username Is : Boss '
        time.sleep(2)
        os.system('git clone https://github.com/TechQaiser/Boss')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Boss && python2 Boss')
        
    elif pepek in ('16', '016'):
        os.system('git clone https://github.com/TechQaiser/TQA')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd TQA && python2 TQA')
        
    elif pepek in ('17', '017'):
        os.system('git clone https://github.com/Hamii-king-06/Pro.git')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Pro && python2 Pro.py')
        
    elif pepek in ('18', '018'):
        os.system('git clone https://github.com/AbdullahDada420/elite')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd elite && python2 elite.py')
        
    elif pepek in ('19', '019'):
        os.system('git clone https://github.com/sasiYabba/SASIY2')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd SASIY2 && python2 SASI2.py')
        
    elif pepek in ('20', '020'):
        os.system('git clone https://github.com/RANAMZ-zeshi/FAST-SP3D.git')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd FAST-SP3D && python2 FAST-SP3D')
        
    elif pepek in ('21', '021'):
        os.system('git clone https://github.com/RANAMZ-zeshi/Z3SHI')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Z3SHI && python2 Z3SHI')
        
    elif pepek in ('22', '022'):
        print 'Username & Pass Is : LEGEND-SYED'
        time.sleep(2)
        os.system('git clone https://github.com/syedzada1100/LEGEND ')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd LEGEND && python2 Syed.py')
        
    elif pepek in ('23', '023'):
        os.system('git clone https://github.com/Tech-abm/fbc')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd fbc && python2 shell.py')
        
    elif pepek in ('24', '024'):
        os.system('git clone https://github.com/Mark-Zuck/romz')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd romz && python2 romz.py')
        
    elif pepek in ('25', '025'):
        os.system('git clone https://github.com/Shinzy24/Xzy')
        inpp = raw_input('Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Xzy && python2 ShinxZy.py')
        
    elif pepek in ('26', '026'):
        os.system('git clone https://github.com/mrjeeck/SIMBF')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd SIMBF && python2 SIMBF.py')
        
    elif pepek in ('27', '027'):
        os.system('git clone https://github.com/Faritricker/FK')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd FK && python2 FK.so')
        
    elif pepek in ('28', '028'):
        os.system('git clone https://github.com/THE-DEMON-ANNOS/APRO.git')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd APRO && python2 APRO.py')
        
    elif pepek in ('29', '029'):
        os.system('git clone https://github.com/bypass07/Ahmadali')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Ahmadali && python2 Ahmadali.py')
        
    elif pepek in ('30', '030'):
        os.system('git clone https://github.com/Dapunta/sbf')
        inpp = raw_input('Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd sbf && python sbf.py')
        
    elif pepek in ('31', '031'):
        os.system('git clone https://github.com/ZKWorld/Zmbf')
        inpp = raw_input('Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Zmbf && python2 zmbf.py')
        
    elif pepek in ('32', '032'):
        print 'username Is : Boss '
        time.sleep(2)
        os.system('git clone https://github.com/KangProf/massall')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd massall && python2 proff.py')
        
    elif pepek in ('33', '033'):
        os.system('git clone https://github.com/Aijaz-Muhmand/HARI.git')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd HARI && python2 MOON.pyc')
        
    elif pepek in ('34', '034'):
        os.system('git clone https://github.com/AngCyber/Crack')
        inpp = raw_input(' Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd Crack && python2 Multi_BF.py')
        
    elif pepek in ('35', '035'):
        os.system('git clone https://github.com/Black19114/MBF3.0')
        inpp = raw_input('Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd MBF3.0 && python2 Azezal.py')
        
    elif pepek in ('36', '036'):
        os.system('git clone https://github.com/nikhilpatel4/nick')
        inpp = raw_input('Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd nick && python2 nick.so')
        
    elif pepek in ('37', '037'):
        os.system('git clone https://github.com/Kabirsingh11/KABIR-SINGH')
        inpp = raw_input('Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd KABIR-SINGH  && python2 run.py')
        
    elif pepek in ('38', '038'):
        os.system('git clone https://github.com/Mafia-XD/elga')
        inpp = raw_input('Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd elga && python2 elga.py')
        
    elif pepek in ('39', '039'):
        print 'Username & Pass Is : LEGEND-SYED'
        time.sleep(2)
        os.system('git clone https://github.com/W1bu-Cr4ck/ZeroTwo ')
        inpp = raw_input('Do you want to Start Tool? [y] ')
        if inpp == 'y':
            os.system('ls && cd ZeroTwo && python2 ZeroTwo.py')
        
    elif pepek in ('40', '40'):
        print '1. Credit To All The Commands Author'
        time.sleep(4)
        print "2. SPECIAL THANKS TO PRIYA'Oo For\n Providing Me A List Of Commands "
        time.sleep(5)
        print '3. SPECIALLY IDEA & CREADTED BY FUCK BOY ALAMGIR'
        time.sleep(5)
        os.system('xdg-open https://m.me/Tera.Papa.Alamgir.441')
        alamgirallinone()

if __name__ == '__main__':
    alamgirallinone()
