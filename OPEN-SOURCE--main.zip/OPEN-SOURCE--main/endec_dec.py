
# Decompiled by HTR-TECH | TAHMID RAYAT
# Github : https://github.com/htr-tech
#---------------------------------------
# Auto Dis Parser 2.2.0
# Source File : patched.pyc
# Bytecode Version : 2.7
# Time : Sun Aug  9 12:24:34 2020
#---------------------------------------

import os
import sys
import fileinput
import time
N = '\x1b[0m'
D = '\x1b[90m'
W = '\x1b[1;37m'
B = '\x1b[1;34m'
R = '\x1b[1;31m'
G = '\x1b[1;32m'
Y = '\x1b[1;33m'
C = '\x1b[1;36m'
wd = '\x1b[90;1m'
GL = '\x1b[96;1m'
BB = '\x1b[34;1m'
GG = '\x1b[32;1m'
RR = '\x1b[31;1m'
B = '\x1b[34m'
G = '\x1b[32m'
R = '\x1b[31m'
ask = G + '[' + W + '?' + G + '] '
sukses = G + '[' + W + '\xe2\x88\x9a' + G + '] '
eror = R + '[' + W + '!' + R + ']'

def runntxt(s):
    for noobs in s + '\n':
        sys.stdout.write(noobs)
        sys.stdout.flush()
        time.sleep(10 / 2100)
    


def banner():
    os.system('clear')
    print ' '
    runntxt(GL + '              \xf0\x9f\x94\xb0 WELCOME \xf0\x9f\x94\xb0')
    time.sleep(1.5)
    runntxt(G + '  Baca Bismillah Dulu Agar Terhindar\n     Dari Perbuatan Kejahatan\n       ' + Y + 'Bismillahirohmanirohi')
    time.sleep(5)
    print G + '[RG4] Black_Coder Team' + Y + '<<<' + GL + '\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x97'
    print R + 'Remaja berkarya            \xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92' + GL + '\xe2\x95\x91'
    print R + 'Bukan Bergaya     ' + Y + 'Facebook ' + R + '\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92' + GL + '\xe2\x95\x91'
    print W + 'Author : Tegar ID          \xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92' + GL + '\xe2\x95\x91'
    print W + 'Kontak : 08212506xxxx      \xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92\xe2\x96\x92' + GL + '\xe2\x95\x91'
    print Y + 'Github : Https://github.com/Tegar-ID     ' + GL + '\xe2\x95\x91'
    print '\xe2\x95\x91' + B + '-\xe2\x96\xba ' + R + '{' + W + '01' + R + '}' + W + './P3R50N G4N5           ' + GL + '\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x9d'
    print '\xe2\x95\x91' + B + '-\xe2\x96\xba ' + R + '{' + W + '02' + R + '}' + W + 'Mr XHamster         ' + GL + '\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x97'
    print '\xe2\x95\x91' + B + '-\xe2\x96\xba ' + R + '{' + W + '03' + R + '}' + W + 'MeYouSue            ' + GL + '\xe2\x95\x91 ' + R + 'Tegar ' + GL + '\xe2\x95\x91]\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x97'
    print '\xe2\x95\x91' + B + '-\xe2\x96\xba ' + R + '{' + W + '04' + R + '}' + W + 'Lucky Know          ' + GL + '\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x9d    \xe2\x95\x91'
    print '\xe2\x95\x91' + B + '-\xe2\x96\xba ' + R + '{' + W + '05' + R + '}' + W + 'XGanz                            ' + GL + '\xe2\x95\x91'
    print '\xe2\x95\x91' + B + '-\xe2\x96\xba ' + R + '{' + W + '06' + R + '}' + W + 'Mr.Cekliz                        ' + GL + '\xe2\x95\x91'
    print '\xe2\x95\x91' + B + '-\xe2\x96\xba ' + R + '{' + W + '07' + R + '}' + W + 'Bidadari Viee                    ' + GL + '\xe2\x95\x91'
    print '\xe2\x95\x91' + B + '-\xe2\x96\xba ' + R + '{' + W + '08' + R + '}' + W + 'Rice                             ' + GL + '\xe2\x95\x91'
    print '\xe2\x95\x91' + B + '-\xe2\x96\xba ' + R + '{' + W + '09' + R + '}' + W + './Nahrun Ganz                    ' + GL + '\xe2\x95\x91'
    print '\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90[' + R + 'Encrypt Decrypt bash' + GL + ']\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x9d'
    print ' '

banner2 = '\n1.encrypt bash\n2.decrypt bash\n\n'
banner()
print banner2

def dekrip():
    
    try:
        sc = raw_input(ask + W + 'Script ' + G + '> ' + W)
        f = open(sc, 'r')
        filedata = f.read()
        f.close()
        newdata = filedata.replace('eval', 'echo')
        out = raw_input(ask + W + 'Output' + G + ' > ' + W)
        f = open(out, 'w')
        f.write(newdata)
        f.close()
        os.system('touch tes.sh')
        os.system('bash ' + out + ' > tes.sh')
        os.remove(out)
        os.system('mv -f tes.sh ' + out)
        print sukses + 'Done..'
    except KeyboardInterrupt:
        print eror + ' Stopped!'
    except IOError:
        print eror + ' File Not Found!'



def enkrip():
    
    try:
        script = raw_input(ask + W + 'Script ' + G + '> ' + W)
        output = raw_input(ask + W + 'Output ' + G + '> ' + W)
        os.system('bash-obfuscate ' + script + ' -o ' + output)
        print sukses + 'Done..'
    except KeyboardInterrupt:
        print eror + ' Stopped!'
    except IOError:
        print eror + ' File Not Found!'


takok = raw_input(W + 'Choose' + G + ' > ')
if takok == '1' or takok == '01':
    enkrip()
elif takok == '2' or takok == '02':
    dekrip()
else:
    print eror + ' Wrong input'
    print banner
    print banner2
    print takok
