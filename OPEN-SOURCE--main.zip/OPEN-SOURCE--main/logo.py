#!/usr/bin/env python3

import os

print("")
os.system("cat tools/addons/banner.txt")
print("")
