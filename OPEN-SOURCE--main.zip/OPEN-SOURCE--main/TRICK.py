
import TRICK

