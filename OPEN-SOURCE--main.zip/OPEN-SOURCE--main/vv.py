
▄▄▄   ▌ ▐·▄▄▄  
▀▄ █·▪█·█▌▀▄ █·
▐▀▀▄ ▐█▐█•▐▀▀▄ 
▐█•█▌ ███ ▐█•█▌
.▀  ▀. ▀  .▀  ▀
By : Putra-XD
[?25l[!] Reverse nmbf.py will begin. Please wait...
I don't know about Python version '3.10.8' yet.
Python versions 3.9 and greater are not supported.
I don't know about Python version '3.10.8' yet.
Python versions 3.9 and greater are not supported.
I don't know about Python version '3.10.8' yet.
Python versions 3.9 and greater are not supported.
I don't know about Python version '3.10.8' yet.
Python versions 3.9 and greater are not supported.
I don't know about Python version '3.10.8' yet.
Python versions 3.9 and greater are not supported.
I don't know about Python version '3.10.8' yet.
Python versions 3.9 and greater are not supported.
