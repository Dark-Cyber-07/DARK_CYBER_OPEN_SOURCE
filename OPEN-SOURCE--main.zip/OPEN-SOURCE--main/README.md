</i></b></h3>
<h3 align="center">
<img align="center" alt="line" src="https://raw.githubusercontent.com/DEADH4X/DEADH4X/main/20221006_224841.gif">
<img src="https://emoji.discord.st/emojis/768b108d-274f-4f44-a634-8477b16efce7.gif" width="25">
&nbsp; OPEN SOURCE FREE &nbsp;
<img src="https://emoji.discord.st/emojis/768b108d-274f-4f44-a634-8477b16efce7.gif" width="25">
<img align="center" alt="line" src="https://raw.githubusercontent.com/DEADH4X/DEADH4X/main/20221006_224841.gif">
<img align ='left' src='https://github.com/DEADH4X/DEADH4X/blob/main/20220731_105425.png' width = '200px' height="20"></h2>

<p><img align="right" alt="gif" src="https://github.com/DEADH4X/DEADH4X/blob/main/20220728_223728.gif" width="270" height="150" /></p>

<p align="center"><a href="https://t.me/DEADH4X"><img title="Telegram" src="https://img.shields.io/badge/Telegram-%23000000.svg?&style=for-the-badge&logo=telegram&logoColor=61DAFB"></a>

<h3> 𝙂𝙄𝙏𝙃𝙐𝘽 𝙎𝙏𝘼𝙏𝙐𝙎 : <img align ='center' src='https://github.com/DEADH4X/DEADH4X/blob/main/43bf277e2f8620f3ffa874fbaec55a3c.gif' width = '50px'></h2>

<p align="left"> <img src="https://komarev.com/ghpvc/?username=deadh4x&label=Profile%20views&color=0e75b6&style=flat" alt="deadh4x" /> </p>

>VISITORS :
![Visitor Count](https://profile-counter.glitch.me/deadh4x/count.svg)

<h2> 𝙎𝙏𝘼𝙏𝙄𝙎𝙏𝙄𝘾𝙎 :</h2>

<a href="https://github.com/DEADH4X"><img width=550 src="https://github-profile-trophy.vercel.app/?username=DEADH4X&theme=dracula&no-frame=true&title=Followers,Stars,Commit,Repository,Issues"/></a>

<h3> 𝘼𝙉𝘼𝙇𝙔𝙏𝙄𝘾𝙎 : <img align ='center' src='https://github.com/DEADH4X/DEADH4X/blob/main/Comp_13.gif' width = '60px'></h2>

 ![sajjad's 𝚐𝚒𝚝𝚑𝚞𝚋 graph](https://activity-graph.herokuapp.com/graph?username=deadh4x&theme=redical&hide_border=true&area=true)
| ![sajjad's github stats](https://github-readme-stats.vercel.app/api?username=deadh4x&show_icons=true&theme=radical)             | ![Aditya GitHub Streak](https://github-readme-streak-stats.herokuapp.com/?user=deadh4x&theme=radical)                                                                                                           |
| --------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=deadh4x&langs_count=8&theme=radical&layout=compact) | ![Github Stars](https://github-readme-stats.vercel.app/api?username=deadh4x&show_icons=true&locale=en&count_private=true&hide_rank=true&custom_title=My%20GitHub%20Stats&disable_animations=true&theme=radical) |

<h3> 𝘾𝙊𝙉𝙏𝘼𝘾𝙏 𝙈𝙀 : <img align ='center' src='https://github.com/DEADH4X/DEADH4X/blob/main/contact-us1.gif' width = '40px'></h2>

<p align="left">
<a href="https://twitter.com/deadh4x" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/twitter.svg" alt="deadh4x" height="30" width="40" /></a>
<a href="https://fb.com/deadh4x" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/facebook.svg" alt="deadh4x" height="30" width="40" /></a>
<a href="https://m.me/DEADH4X"><img align="left" title="Messenger" alt="Messenger" width="30px" src="https://i.ibb.co/Cn8FHym/messenger.png" /></a>
<a href="https://instagram.com/deadh4x" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="deadh4x" height="30" width="40" /></a>
<a href="https://discord.gg/https://discord.gg/rBREVagaRs" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/discord.svg" alt="https://discord.gg/rBREVagaRs" height="30" width="40" /></a>
</p>

<h3> 𝘼𝘽𝙊𝙐𝙏 𝙈𝙀 : 

<img align="center" alt="line" src="https://raw.githubusercontent.com/DEADH4X/DEADH4X/main/20221006_224841.gif">

- 𝗡𝗔𝗠𝗘 : 𝗡𝗔𝗬𝗘𝗠 𝗛𝗢𝗦𝗦𝗔𝗜𝗡
 
<img align="center" alt="line" src="https://raw.githubusercontent.com/DEADH4X/DEADH4X/main/20221006_224841.gif">
 
- 𝗖𝗢𝗨𝗡𝗧𝗥𝗬 : 𝗕𝗔𝗡𝗚𝗟𝗔𝗗𝗘𝗦𝗛
 
<img align="center" alt="line" src="https://raw.githubusercontent.com/DEADH4X/DEADH4X/main/20221006_224841.gif">
 
- 𝗥𝗘𝗟𝗜𝗚𝗜𝗢𝗡 : 𝗜𝗦𝗟𝗔𝗠
 
<img align="center" alt="line" src="https://raw.githubusercontent.com/DEADH4X/DEADH4X/main/20221006_224841.gif">
 
- 𝗜𝗠 𝗡𝗢𝗥𝗠𝗔𝗟 𝗨𝗦𝗘𝗥 
 
<img align="center" alt="line" src="https://raw.githubusercontent.com/DEADH4X/DEADH4X/main/20221006_224841.gif">
 
<h3> 𝙇𝙀𝘼𝙍𝙉𝙄𝙉𝙂 : <img src = "https://media2.giphy.com/media/QssGEmpkyEOhBCb7e1/giphy.gif?cid=ecf05e47a0n3gi1bfqntqmob8g9aid1oyj2wr3ds3mg700bl&rid=giphy.gif" width = 32px> </h2>

<p align="left"> <a href="https://developer.android.com" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/android/android-original-wordmark.svg" alt="android" width="40" height="40"/> </a> <a href="https://www.w3schools.com/cpp/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/cplusplus/cplusplus-original.svg" alt="cplusplus" width="40" height="40"/> </a> <a href="https://www.w3.org/html/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="40" height="40"/> </a> <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> </a> <a href="https://www.linux.org/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/linux/linux-original.svg" alt="linux" width="40" height="40"/> </a> <a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> </p>

<p><img align="right" alt="gif" src="https://github.com/DEADH4X/DEADH4X/blob/main/d2e58b5a43b7f21bb9f06167e3980224.gif" width="270" height="130" /></p>
