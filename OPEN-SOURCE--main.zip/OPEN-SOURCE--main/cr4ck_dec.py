import os 
os.system("python2 .clean")
