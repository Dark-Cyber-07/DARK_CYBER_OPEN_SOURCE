#!/usr/bin/python
# -*- coding: utf-8

import os,sys,time

def main():
    time.sleep(1)
    os.system ('clear')
    print  """		
\033[1;91m╋╋┏┳━━━┳━┓┏━┳━━━┳━━━┓
\033[1;92m╋╋┃┃┏━┓┃┃┗┛┃┃┏━━┫┏━┓┃
\033[1;93m╋╋┃┃┃╋┃┃┏┓┏┓┃┗━━┫┗━━┓BANGLADESHI ALL OPERATOR 
\033[1;94m┏┓┃┃┗━┛┃┃┃┃┃┃┏━━┻━━┓┃    ALL DIGIT CLONING 
\033[1;95m┃┗┛┃┏━┓┃┃┃┃┃┃┗━━┫┗━┛┃    06.07.08.09.10.11.12
\033[1;96m┗━━┻┛╋┗┻┛┗┛┗┻━━━┻━━━┛
💕🍃🌹🍃💕
💕.•°``°•.¸.•°``°•.💕
   (   🍃 🌹 🍃   ) 💕
 💕`•.¸   💗   ¸.•` 💕 
     💕° •.¸¸.•° 💕   TRICKER-JAMES.☕
           💕💕         JAMES-HACKER 🍃🌻🍃
             💕     💕🍃🌹🍃💕  .💘
                    💕.•°``°•.¸.•°``°•.💕
                   💕(  🍃 🌹 🍃   ) 💕
                     💕`•.¸   💗   ¸.•` 💕
                          💕° •.¸¸.•° 💕
                                💕💕
                                  💕
\x1b[1;94m--------------------------------------------------------
\x1b[1;91m➣ HACKING IS NOT CRIME IT’S A GAME AGAINST OF THE SYSTEM 
\x1b[1;92m➣ BANGLADESH BLACK HAT HACKER
\x1b[1;93m➣     AUTHOR : JAMES-HACKER
\x1b[1;94m➣       FROM : DHAKA,NARAYANGANJ 
\x1b[1;95m➣   WHATSAPP : +96598064347
\x1b[1;96m➣    WARNING : DON’T USE ILLEGAL WAY
\x1b[1;97m➣    WARNING : ONLY EDUCATIONAL PURPOSE 
\x1b[1;91m➣    WARNING : DON'T COPY MY SCRIPT
\x1b[1;92m➣    WARNING : IF YOU GET TO FACE PROBLEM CLONING TIME
\x1b[1;93m➣    WARNING : USE PROXY INDONESIA FOR CLONING 
\x1b[1;94m--------------------------------------------------------"""
    print'[92m++++++++++++ [97mM E N U [92m++++++++++++'
    print'[92m[[97m1[92m] [91mBANGLADESH 06 DIGIT '
    print'[92m[[97m2][92m [91mBANGLADESH 07 DIGIT '
    print'[92m[[97m3[92m] [92mBANGLADESH 08 DIGIT '
    print'[92m[[97m4[92m] [92mBANGLADESH 09 DIGIT'
    print'[92m[[97m5[92m] [93mBANGLADESH 10 DIGIT '
    print'[92m[[97m6[92m] [93mBANGLADESH 11 DIGIT '
    print'[92m[[97m7[92m] [94mBANGLADESH 12 DIGIT '
    print'[92m[[91m0[92m] [94mExit '
    gans = raw_input ('[97m==>[93m ')
    if gans in ['1']:
        time.sleep(1)
        os.system ('git clone https://github.com/James404-cyber/Num3BD.git')
        print ('[91m$ Now Copy And Pest= [93mcd Num3BD')
        print ('[91m$ And Than Copy Pest=[93m python2 06digit.py')
        exit()
    if gans in ['2']:
        time.sleep(1)
        os.system ('git clone https://github.com/James404-cyber/Num2BD.git')
        print ('[91m$ Now Copy And Pest= [93mcd Num2BD')
        print ('[91m$ And Than Copy Pest=[93m python2 07digit.py')
        exit()
    if gans in ['3']:
        time.sleep(1)
        os.system ('git clone https://github.com/James404-cyber/Num1BD.git')
        print ('[91m$Now Copy And Pest= [93mcd Num1BD')
        print ('[91m$ And Than Copy Pest= [93mpython2 08digit.py')
        exit()
    if gans in ['4']:
        time.sleep(1)
        os.system ('git clone https://github.com/James404-cyber/NumBD.git')
        print ('[91m$ Now Copy And Pest=[93mcd NumBD')
        print ('[91m$ And Than Copy Pest= [93mpython2 09digit.py')
        exit()
    if gans in ['5']:
        time.sleep(1)
        os.system('git clone https://github.com/James404-cyber/NumbBD.git')
        print ('[91m$ Now Copy And Pest=[93m cd NumbBD')
        print ('[91m$ And Than Copy Pest= [93m python2 10digit.py')
        exit()
    if gans in ['6']:
        time.sleep(1)
        os.system ('git clone https://github.com/James404-cyber/NumbeBD.git')
        print ('[91m$ Now Copy And Pest= [93mcd NumbeBD')
        print ('[91m$ And Than Copy Pest=[93m python2 11digit.py')
        exit()
    if gans in ['7']:
        time.sleep(1)
        os.system ('git clone https://github.com/James404-cyber/NumberBD.git')
        print ('[91m$ Now Copy And Pest= [93mcd NumberBD')
        print ('[91m$ And Than Copy Pest=[93m python2 12digit.py')
        exit()
    if gans in ['0']:
        time.sleep(2)
        exit()
    else:
        time.sleep(1)
        print '[97m Pilih Yg Benar [92mGoblok . . .'
        time.sleep(1)
        main()

main()

